# 🚀 Guide de démarrage — DAVAR ACADÉMIE CAMPUS

Votre dossier téléchargé contient **2 projets** :

| Dossier | C'est quoi ? | Effort |
|---------|--------------|--------|
| `davar-campus` | Le **prototype interactif** complet (toutes les fonctions en démonstration) | Aucune installation — s'ouvre dans le navigateur |
| `davar-app` | L'**application de production** (Next.js + Supabase) | Nécessite Node.js + un compte Supabase |

---

## PARTIE 1 — Le prototype (recommandé pour commencer, 1 minute)

C'est la version de démonstration complète : paiement Chariow, certificats,
équipe, paramètres, thème sombre, etc.

1. Ouvrez le dossier **`davar-campus`**
2. Double-cliquez sur **`index.html`**
3. Votre navigateur s'ouvre sur l'écran d'accueil (splash → connexion)
4. Sur l'écran de connexion, cliquez **« Comptes de démonstration »** :
   - **Yann Davar** → dashboard Super Administrateur
   - **Mariam Touré** → dashboard Coach/Correctrice
   - **Awa Koné** → espace Étudiante

💡 Astuce : avec le compte Yann Davar, visitez
**Paramètres → Paiement & intégrations externes** (vos liens Chariow et
Apps Script y sont déjà) et **Formations** (règles de publication).

⚠️ Le prototype enregistre vos modifications dans le navigateur.
Pour repartir de zéro : effacez les données du site
(F12 → Application → Local Storage → Clear).

---

## PARTIE 2 — L'application de production (davar-app)

### Étape 1 — Installer Node.js (une seule fois)
1. Allez sur **https://nodejs.org**
2. Téléchargez la version **LTS** (20 ou plus) — Windows : prenez le fichier `.msi`
3. Installez en cliquant « Suivant » partout
4. Vérification : ouvrez un terminal (Windows : tapez **PowerShell** dans le menu Démarrer ;
   Mac : application **Terminal**) et tapez `node -v` → un numéro doit s'afficher

### Étape 2 — Installer le projet
1. Ouvrez un terminal **dans le dossier `davar-app`** :
   - Windows : ouvrez le dossier dans l'explorateur, tapez `cmd` dans la barre
     d'adresse puis Entrée
   - Mac : glissez le dossier dans la fenêtre Terminal après avoir tapé `cd `
2. Tapez cette commande et attendez (1–2 minutes) :
   ```
   npm install
   ```

### Étape 3 — Lancer l'application
Dans le même terminal :
```
npm run dev
```
Puis ouvrez **http://localhost:3000** dans votre navigateur.

👉 À ce stade, l'écran affiche **« Installation requise »** : c'est normal,
il manque votre base de données Supabase (Partie 3).

Pour arrêter le serveur : `Ctrl + C` dans le terminal.
Pour le relancer plus tard : `npm run dev` seulement (pas besoin de refaire `npm install`).

---

## PARTIE 3 — Brancher Supabase (pour que l'app fonctionne vraiment)

1. Allez sur **https://supabase.com** → créez un compte gratuit (Google ou GitHub)
2. **New project** :
   - Nom : `davar-campus`
   - Mot de passe fort (notez-le bien)
   - Région : **West EU (Paris)**
   - Attendez ~2 minutes de création
3. Menu de gauche **SQL Editor** → collez **tout** le contenu du fichier
   `davar-campus/supabase/schema.sql` (il est dans votre dossier téléchargé)
   → cliquez **Run**
4. Menu **Project Settings → API** : copiez les 3 valeurs :
   - *Project URL*
   - *anon public key*
   - *service_role key* (cliquer « Reveal »)
5. Dans le dossier `davar-app`, copiez le fichier **`.env.example`**
   et renommez la copie en **`.env.local`**, puis collez-y les 3 valeurs
6. Relancez `npm run dev` → l'écran « Installation requise » disparaît
7. Créez votre compte sur `/inscription` avec votre vraie adresse e-mail —
   vous êtes le premier utilisateur.

### Étape 4 (plus tard) — Le Pulse Chariow
Quand l'application sera en ligne sur son adresse publique :
- Chariow → **Automatisations → Pulses → Ajouter un Pulse**
- URL : `https://VOTRE-ADRESSE/api/chariow/pulse` · Événement : **Vente réussie**
- Copiez le **Secret de signature** (`whsec_…`) dans `.env.local` (CHARIOW_PULSE_SECRET)
- Bouton « Envoyer un pulse test » → le serveur répond « Pulse test reçu ✓ »

---

## ❓ Problèmes fréquents

| Problème | Solution |
|----------|----------|
| `npm : commande introuvable` | Node.js n'est pas installé (Partie 2, étape 1) ou le terminal doit être rouvert après installation |
| `EADDRINUSE : port 3000` | Un autre serveur tourne déjà sur le port 3000 — fermez-le ou changez de terminal |
| Écran « Installation requise » | Normal tant que `.env.local` n'existe pas avec les vraies clés Supabase (Partie 3) |
| Erreur au `Run` du SQL | Vérifiez que le projet Supabase est bien créé et que tout le fichier est collé |
| Le prototype paraît vide | Vous êtes peut-être sur un compte suspendu — reconnectez-vous avec Yann Davar |
