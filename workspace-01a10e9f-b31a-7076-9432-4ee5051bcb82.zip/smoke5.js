const fs=require('fs'),vm=require('vm');
function mkEl(id){return{id,innerHTML:'',style:{},value:'',files:[],checked:false,className:'',textContent:'',disabled:false,addEventListener(){},appendChild(){},remove(){},querySelector:()=>null,querySelectorAll:()=>[],getBoundingClientRect:()=>({left:0,width:100}),scrollTop:0,scrollHeight:0,closest:()=>null,dataset:{}};}
const els={};
const ctx={document:{title:'',documentElement:{setAttribute(){},getAttribute:()=>'light'},getElementById:id=>els[id]||(els[id]=mkEl(id)),querySelector:()=>null,querySelectorAll:()=>[],addEventListener(){},createElement:t=>mkEl(t),body:{appendChild(){},style:{},overflow:''}},
window:{addEventListener(){},scrollTo(){},matchMedia:()=>({matches:false}),open(){},PublicKeyCredential:{}},
matchMedia:()=>({matches:false}),
location:{hash:'#/'},localStorage:{getItem:()=>null,setItem(){},removeItem(){}},
setTimeout:(f)=>{f&&f();return 0},clearTimeout(){},setInterval:()=>1,clearInterval(){},requestAnimationFrame:f=>f&&0,
fetch:()=>Promise.resolve({json:()=>Promise.resolve({}),ok:true,status:200}),
Date,Math,JSON,console,URLSearchParams,Number,String,Object,Array,parseInt,parseFloat,FileReader:function(){this.readAsDataURL=()=>this.onload&&this.onload({target:{result:'data:x'}})}};
vm.createContext(ctx);
for(const f of['js/icons.js','js/data.js','js/ui.js','js/views-student.js','js/views-admin.js','js/app.js']){try{vm.runInContext(fs.readFileSync(f,'utf8'),ctx);}catch(e){console.error('LOAD FAIL',f,e.message);process.exit(1);}}
let fails=0;
function go(hash,sess){ctx.location.hash=hash;try{vm.runInContext(sess?`S.session={userId:'${sess}'};render()`:'render()',ctx);}catch(e){fails++;console.error('RENDER FAIL',hash,'→',e.message);}}
go('#/login');go('#/inscription');
['#/','#/formations','#/formation/t-orateur','#/catalogue','#/profil'].forEach(h=>go(h,'u-awa'));
['#/admin','#/admin/formations','#/admin/formations/t-orateur','#/admin/etudiants','#/admin/equipe','#/admin/certifications','#/admin/parametres','#/admin/ia','#/admin/conversations','#/admin/ventes'].forEach(h=>go(h,'u-yann'));
try{vm.runInContext("togglePublish('t-orateur')",ctx);const t=vm.runInContext("getTraining('t-orateur')",ctx);if(t.published){fails++;console.error('PUBLISH GATE FAIL');}else console.log('✓ gate publication OK');}catch(e){fails++;console.error('togglePublish',e.message);}
console.log(fails?'❌ '+fails+' erreurs':'✅ PROTOTYPE OK');
process.exit(fails?1:0);
