const crypto = require('crypto');
const SECRET = 'whsec_dev_test_secret_a_remplacer';

const payload = {
  event: 'successful.sale',
  sale: { id: 'sal_test12345', status: 'completed', amount: { value: 45000, currency: 'XOF', formatted: '45 000 FCFA' }, custom_metadata: null, completed_at: '2026-09-25T10:00:00+00:00' },
  product: { id: 'prd_6wx1czzp', name: 'Devenir un excellent orateur', url: 'https://d-ueo.mychariow.co/p/orateur', price: { value: 45000, currency: 'XOF' } },
  customer: { id: 'cus_test1', name: 'Awa Koné', first_name: 'Awa', last_name: 'Koné', email: 'awa.kone@exemple.ci', country: 'CI' },
  store: { id: 'str_davar', name: 'DAVAR Académie', url: 'https://d-ueo.mychariow.co' },
  checkout: { url: 'https://d-ueo.mychariow.co/checkout/sal_test12345' }
};
const body = JSON.stringify(payload);
const sig = 'sha256=' + crypto.createHmac('sha256', SECRET).update(body, 'utf8').digest('hex');
console.log('SIG=' + sig);
console.log('BODY=' + body);
