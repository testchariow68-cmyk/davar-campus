# Flutterwave — fournisseur de paiement optionnel

> Statut : **actif par défaut en mode « voie universelle ».**
> Le **1ᵉʳ achat se fait EN DEHORS de l'application** (Chariow) : c'est lui qui donne accès à la plateforme. Dans l'app, tous les achats sont donc des achats supplémentaires et passent par **Flutterwave, universel pour tout le monde** (mobile money Afrique de l'Ouest dont Wave + cartes internationales). Ajustable depuis **Admin → Réglages → Paiement & intégrations externes**.

## Pourquoi Flutterwave ?

Un seul agrégateur qui couvre **les deux périmètres** du combo actuel (vérifié sur la documentation officielle) :

| Périmètre | Money Fusion + Chariow | Flutterwave |
|---|---|---|
| Mobile money Côte d'Ivoire | MTN, Orange, Moov, Wave | ✅ MTN, Orange, Moov, **Wave** |
| Sénégal | ✅ | ✅ Orange, Free Money, Wave |
| Cartes internationales | ✅ (Chariow) | ✅ |
| Webhooks + vérification | ✅ | ✅ (`verifi-hash` + `/v3/transactions/:id/verify`) |
| Liens de paiement | ✅ | ✅ (checkout hébergé) |

**Contreparties** : point de défaillance unique (KYC strict, gel de compte possible), frais carte internationale ≈ 3,8 % vs ≈ 1,4 % mobile money local (à confirmer sur la grille tarifaire Flutterwave).

## Les 3 modes (Admin → Réglages)

| Mode | Effet | Quand |
|---|---|---|
| `all` (défaut) | **Voie universelle** : tous les achats dans l'app (mobile money + cartes internationales) | **Recommandé** : un seul prestataire pour tous les pays |
| `cards` | Cartes seulement ; Money Fusion garde le mobile money | Si vous voulez garder MF pour le mobile money local |
| `fallback` | Simple alternative proposée dans les modales Money Fusion / Chariow | Phase de comparaison des frais |

Dans tous les modes : **le 1ᵉʳ achat se fait en dehors de l'app** (Chariow, il crée l'accès à la plateforme). Si Flutterwave est **désactivé**, l'app retombe sur le routage historique (Money Fusion Afrique de l'Ouest / Chariow autres pays).

## Contrat API v3 (implémenté dans `js/views-student.js`)

1. **Initiation** — `POST https://api.flutterwave.com/v3/payments`
   `{ tx_ref, amount, currency:'XOF', redirect_url, customer:{email,name}, customizations:{title,description} }`
   → `{ status:'success', data:{ link } }` → l'étudiant est redirigé vers le checkout hébergé.
2. **Webhook** — `POST /api/flutterwave/webhook`, en-tête `verifi-hash` = secret ;
   payload `{ event:'charge.completed', data:{ id, tx_ref, flw_ref, status:'successful', amount, currency, customer } }`.
3. **Vérification serveur** — `GET /v3/transactions/:id/verify` (Bearer clé secrète) → `data.status === 'successful'`.

**Règles (identiques à Money Fusion)** : jamais confiance au webhook seul ; dédoublonnage par `tx_ref` (1 transaction = 1 crédit, jamais 2 comptes) ; événement non payable acquitté sans crédit.

## Worker de production

`security/workers/flutterwave-webhook.mjs` : vérification `verifi-hash` à temps constant, filtre `charge.completed`+`successful`, dédoublonnage, re-vérification `/verify`, puis crédit.

```bash
wrangler deploy security/workers/flutterwave-webhook.mjs \
  --var FLW_WEBHOOK_SECRET:<secret-hash-du-dashboard> \
  --var FLW_SECRET_KEY:<FLWSECK-…>
```

Variables : `FLW_WEBHOOK_SECRET` (verifi-hash) et `FLW_SECRET_KEY` (clé secrète, côté serveur uniquement). Dédoublonnage persistant : KV ou Durable Object (`SEEN_TX`).

## Procédure d'activation (15 min)

1. Créer le compte marchand sur flutterwave.com (KYC : pièce d'identité + infos entreprise).
2. **Dashboard → Settings → API** : copier la **clé secrète** (`FLWSECK-…`) — ne jamais l'exposer côté client.
3. Renseigner l'URL du webhook `https://VOTRE-DOMAINE/api/flutterwave/webhook` et copier le **secret hash**.
4. Dans **Admin → Réglages → Paiement & intégrations externes** : coller clé + secret, choisir le mode, cocher **Activer Flutterwave**, enregistrer.
5. Faire un achat test de 200 FCFA (minimum XOF) en Wave, vérifier : e-mail `purchase_ok` (support@), notification push, vente dans le tableau de bord, méthode « Mobile Money » sur la facture.

## Facturation & frais

- Frais indicatifs : mobile money XOF ≈ 1,4 % · carte internationale ≈ 3,8 % — **à vérifier sur la grille** avant tout changement de mode.
- Le client ne voit jamais la passerelle : la facture affiche « Mobile Money » ou « Carte bancaire » (`payMethodLabel`).
- Reçus/settlements : Dashboard → Transactions (export CSV).

## Tests

`tests/smoke54.js` : désactivé par défaut (norme MF+Chariow intacte), routage des 3 modes, worker (hash/événement/dédup), achat de bout en bout (déblocage + vente + e-mail support@), dédoublonnage `tx_ref`, rejet `verifi-hash` invalide.
