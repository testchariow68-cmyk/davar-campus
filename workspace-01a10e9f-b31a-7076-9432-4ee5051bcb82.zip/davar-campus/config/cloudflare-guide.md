# ☁️ Guide Cloudflare 100 % gratuit — davarcampus.co (app + e-mails)

Objectif : **un seul domaine, davarcampus.co**, pour l'application ET les 4 e-mails professionnels — 0 FCFA/mois.
Seul coût inévitable : l'achat du domaine lui-même (~10 $/an, prix coûtant chez Cloudflare Registrar).

Site et e-mails cohabitent sans conflit sur le même domaine : le site utilise l'enregistrement **CNAME/A** (géré par Pages), les e-mails utilisent les enregistrements **MX** (gérés par Email Routing).

Tout se passe sur **dash.cloudflare.com** (compte gratuit = plan Free, suffisant pour tout ce qui suit).

---

## Phase 1 — Le domaine sur Cloudflare (10 min)

1. Acheter **davarcampus.co** :
   - soit chez Cloudflare : *Domain Registration → Register Domains* (prix coûtant, sans marge) ;
   - soit chez votre registrar habituel (OVH, Gandi, Namecheap…).
2. *Home → Add a domain* → saisir `davarcampus.co` → choisir le plan **Free (0 $)**.
3. Si le domaine vient d'ailleurs : Cloudflare affiche **2 serveurs de noms** (ex. `xxx.ns.cloudflare.com`) → les copier chez votre registrar (rubrique « DNS » ou « Nameservers ») → attendre l'activation (quelques minutes à 24 h, statut « Active »).

---

## Phase 2 — Recevoir les 4 e-mails (Email Routing, gratuit)

Cloudflare Email Routing = **réception gratuite** (redirection vers votre boîte réelle). Il ne fait PAS l'envoi (voir Phase 3).

1. Zone **davarcampus.co** → menu **Email → Email Routing → Get started**.
2. Cloudflare propose d'ajouter les enregistrements **MX + TXT (SPF)** automatiquement → **Accepter** (ne pas les modifier à la main).
3. **Destination addresses → Add** : votre Gmail personnel (ex. `support.davaracademie@gmail.com`) → Gmail reçoit un code/e-mail de vérification → confirmer.
4. **Routing rules → Create** (4 règles, action « Send to » vers la destination vérifiée) :

   | Adresse | Redirigée vers |
   |---|---|
   | support@davarcampus.co | votre Gmail |
   | contact@davarcampus.co | votre Gmail |
   | infos@davarcampus.co | votre Gmail |
   | direction@davarcampus.co | votre Gmail |

5. Optionnel mais recommandé : **Catch-all → Enable** (toute autre adresse @davarcampus.co arrive aussi chez vous — pratique pour repérer les fautes de frappe).
6. Test : depuis un autre compte, envoyer un e-mail à `support@davarcampus.co` → il doit arriver dans votre Gmail.

---

## Phase 3 — ENVOYER en tant que @davarcampus.co (alias Gmail, gratuit)

C'est l'astuce qui complète Email Routing : vos réponses et les e-mails automatiques partent **de** support@davarcampus.co etc., sans payer de serveur mail.

1. Gmail → ⚙️ **Voir tous les paramètres → Comptes et importation → « Envoyer des e-mails en tant que » → Ajouter une autre adresse**.
2. Adresse : `support@davarcampus.co` · Nom : `Davar Académie — Support` · **Décocher** « Traiter comme un alias » → Suivant → **« Envoyer via les serveurs Gmail »** (pas de SMTP à configurer) → Ajouter.
3. Gmail envoie un **code de confirmation à support@davarcampus.co** → il arrive dans votre boîte grâce à la Phase 2 → saisir le code → c'est activé.
4. Répéter pour `contact@davarcampus.co` (Nom : `Davar Académie — Commercial`), `infos@davarcampus.co` (`Davar Académie`), `direction@davarcampus.co` (`Davar Académie — Direction`).
5. **Améliorer la délivrabilité (SPF)** : zone davarcampus.co → **DNS → TXT** → modifier l'enregistrement SPF créé par Email Routing pour inclure Google :
   ```
   v=spf1 include:_spf.google.com include:_spf.mx.cloudflare.net ~all
   ```
6. **Automatisation (déjà câblée dans l'app)** : l'app envoie via `S.settings.appscript.mailUrl` avec `from` + `body`. Dans votre Apps Script, utilisez :
   ```js
   GmailApp.sendEmail(to, subject, body, { name: nom, from: from });
   ```
   `from` ne fonctionne que si l'alias est vérifié (étapes 1-4) sur le compte Gmail qui exécute le script.

> Plus tard, si le volume grossit : **Resend** (gratuit 100 e-mails/jour) avec SPF+DKIM complets sur davarcampus.co — se branche sur le même `mailUrl`. Non nécessaire au démarrage.

---

## Phase 4 — DEUX sites, DEUX domaines (Cloudflare Pages, gratuit)

Pages gratuit = bande passante illimitée, HTTPS automatique, et chaque projet reçoit une URL `*.pages.dev` gratuite (on peut y brancher un domaine personnalisé plus tard).

**Projet 1 — Site vitrine** (dossier `site/`) :
1. *Workers & Pages → Create → Pages → Upload assets* → nom du projet : `davar-academie` → glisser-déposer le contenu de `site/` → **Deploy**.
2. Le site est en ligne sur `https://davar-academie.pages.dev` (URL gratuite).
3. Quand vous achèterez son domaine (ex. davaracademypage.co) : *Custom domains → Set up* → le domaine ; puis **remplacer le placeholder `davar-academie.pages.dev`** dans `site/index.html`, `robots.txt` et `sitemap.xml` par le domaine définitif.

**Projet 2 — Application web** (dossier `davar-campus/`) :
1. *Workers & Pages → Create → Pages → Upload assets* → nom du projet : `davar-campus` → glisser-déposer le contenu de `davar-campus/` (index.html à la racine) → **Deploy**.
2. *Custom domains* → **davarcampus.co** (+ www) → HTTPS automatique. **Les MX des e-mails ne bougent pas** : e-mails et application cohabitent sur davarcampus.co (MX vs CNAME).

Les deux projets sont **totalement indépendants** : la vitrine n'a aucun lien vers l'app ; on entre dans l'app uniquement après achat (accès envoyés par e-mail).

**Vérifications après déploiement :**
- Vitrine : boutons « Acheter » → checkout Chariow « Devenir un excellent orateur » ;
- `https://davarcampus.co` affiche l'application (écran de connexion) ;
- Search Console : soumettre le sitemap de la vitrine (voir `SEO.md`).

> Les workers (Phase 5) montés sur les routes `davarcampus.co/api/*` restent prioritaires sur Pages.

## Phase 5 — Workers gratuits (quand vous passerez au réel)

Plan Free : 100 000 requêtes/jour — largement suffisant.

| Worker | Rôle | Déploiement |
|---|---|---|
| `security/workers/flutterwave-webhook.mjs` | Webhook paiement vérifié | `wrangler deploy` + variables `FLW_WEBHOOK_SECRET`, `FLW_SECRET_KEY` ; route `davarcampus.co/api/flutterwave/*` |
| `security/workers/r2-signed-url.mjs` | URLs vidéo signées (R2) | idem, avec bucket R2 (10 Go gratuits) |
| `layer1`…`layer11` | Couches sécurité | selon `SECURITY.md` |

---

## Récapitulatif des coûts

| Poste | Coût |
|---|---|
| DNS + Email Routing + Pages + Workers + R2 (10 Go) | **0 FCFA/mois** |
| davarcampus.co (enregistrement annuel) | ~10 $/an (seul poste payant) |
| Envoi des e-mails (alias Gmail) | 0 (puis Resend gratuit si volume) |

## Checklist finale

- [ ] Domaine davarcampus.co « Active » sur Cloudflare (plan Free)
- [ ] Email Routing : MX/SPF auto + destination vérifiée + 4 règles + catch-all
- [ ] Test réception : support@davarcampus.co → Gmail ✓
- [ ] 4 alias Gmail « Envoyer en tant que » vérifiés + SPF mis à jour
- [ ] Apps Script : `GmailApp.sendEmail(..., { from })` avec alias vérifiés
- [ ] Pages : app déployée + custom domain davarcampus.co (+ www) + HTTPS
- [ ] Search Console : sitemap soumis (voir SEO.md)
- [ ] (Plus tard) Workers Flutterwave + R2 déployés avec leurs variables
