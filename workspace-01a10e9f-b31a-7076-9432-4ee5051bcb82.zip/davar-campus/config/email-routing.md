# 📧 Routage e-mail professionnel — 4 adresses (Cloudflare Email Routing, 0 FCFA)

> 📘 **Guide pas à pas complet** (domaines, réception, envoi alias Gmail, déploiement Pages) : voir `config/cloudflare-guide.md`.

Domaine unique : **davarcampus.co** (application + e-mails professionnels). Adresses configurables dans `S.settings.emails`.

| # | Adresse | Rôle | Ton | Délai | Fréquence |
|---|---|---|---|---|---|
| 1 | support@davarcampus.co | Aide étudiants, technique, réclamations, remboursements, mot de passe, confirmations d'achat | Chaleureux, patient | 24-48 h | Quotidien |
| 2 | contact@davarcampus.co | Partenariats, entreprises, presse, instructeurs, investisseurs | Pro, structuré | 24-48 h | Hebdo |
| 3 | infos@davarcampus.co | Informations pédagogiques, nouveautés, événements, newsletter — **canal hybride web push + e-mail** | Utile, pas publicitaire | — | ≤ 2/mois, désinscription obligatoire |
| 4 | direction@davarcampus.co | Certificats, fins de formation, décisions, avertissements, transferts de propriété, légal | Solennel, officiel | 48-72 h | Rare (10-30/an) |

## Tableau de routage des flux (implémenté dans `js/emails.js` → `sendFlow`)

| Flux | Adresse | Déclencheur | Double canal |
|---|---|---|---|
| Bienvenue | infos@ | création de compte | ✅ push |
| Nouveau cours / événement | infos@ | publication | ✅ push |
| Newsletter mensuelle | infos@ | manuel | — |
| Récompense / badge | infos@ | obtention | — |
| Confirmation d'achat + facture | support@ | vente confirmée (MF ou Chariow) | — |
| Accès ouvert | support@ | déblocage formation | — |
| Mot de passe oublié | support@ | demande | — |
| Accusé demande de certificat | support@ | demande étudiant | — |
| Enquête de satisfaction | support@ | manuel | — |
| Certificat émis | direction@ | émission | — |
| Demande de certificat (staff) | direction@ | fin de parcours 100 % | — |
| Invitation staff / accès offert | direction@ | invitation admin | — |
| Suspension / réactivation | direction@ | décision admin | — |
| Transfert de propriété | direction@ | initiation | — |
| Partenariat / entreprise / presse | contact@ | formulaire ou e-mail reçu | — |

**Scission intelligente** : aucune 5ᵉ adresse nécessaire — le transactionnel se répartit
naturellement entre support@ (étudiants, rassurant) et direction@ (officiel). Créer
`facturation@davarcampus.co` uniquement si le volume de réclamations paiement dépasse ~50/mois.

## Signatures (appliquées automatiquement par rôle)
Toutes : « Cordialement, [L'équipe Support / Commerciale / L'équipe / La Direction] Davar Académie »,
adresse physique **Yopougon, Abidjan — Côte d'Ivoire**, adresse émettrice, https://davarcampus.co.
infos@ ajoute en pied : motif de réception, rappel que le destinataire **a des droits sur ses données** (accès, correction, suppression — sans citer de loi) + **lien de désinscription**.

## Configuration Cloudflare Email Routing (réception, gratuite)
1. DNS de davarcampus.co sur Cloudflare → Email → Email Routing → Enable (MX/TX auto).
2. Add destination : votre boîte personnelle → vérifier.
3. Routing rules : support@, contact@, infos@, direction@ → Send to destination vérifiée.
4. Limites Cloudflare : redirection seulement, ≤ 1 000 e-mails/jour ; **l'envoi transactionnel passe par Resend ou Brevo (gratuits)** branchés sur `S.settings.appscript.mailUrl` (le même appel `sendMailSim` envoie déjà `from` + `body`).
5. **Contrat complet du POST** (texte brut JSON) : `{ to, subject, from, body }` et, pour l'envoi d'un export CSV par e-mail, deux champs supplémentaires `{ csvName, csvContent }` — votre Apps Script les joint en fichier `.csv` :
   `GmailApp.sendEmail(to, subject, body, { name: nom, from: from, attachments: [Utilities.newBlob(csvContent, 'text/csv', csvName)] });`
5. Envoi « en tant que » depuis Gmail possible (SMTP smtp.gmail.com, port 587, mot de passe d'application, alias décoché).

## Double canal (web push VAPID + e-mail)
- Push seul : rappels urgents/éphémères (live imminent, formation en cours).
- E-mail seul : newsletter, traces écrites.
- Les deux : nouvelle formation majeure, événement important, changement de politique.
- Implémenté : flux marqués `dual: true` (welcome, new_course, event) → `notify()` push si `pushEnabled`.

## Checklist
- [ ] Email Routing activé + destination vérifiée · [ ] 4 règles créées · [ ] Resend/Brevo branché
- [ ] Signatures + désinscription infos@ · [ ] VAPID en variables d'environnement · [ ] tests smoke53 verts
