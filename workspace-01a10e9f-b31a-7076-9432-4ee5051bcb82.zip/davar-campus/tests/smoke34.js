const { boot, log, done } = require('./_boot');
const { w, q, body, fs, ROOT } = boot();
const css = fs.readFileSync(ROOT + '/style.css', 'utf8');
w.eval("__setSession({userId:'u-awa',token:'x'});render();");

// --- A. Quiz d'évaluation : plus d'animation ---
q("(function(){ S.evAttempts['u-awa']=S.evAttempts['u-awa']||{}; const t=getTraining('t-marketing'); t.chapters[1].modules.forEach(m=>{S.progress['u-awa'][m.id]={viewed:true,pct:100}}); const t2=getTraining('t-marketing'); t2.chapters[0].modules.forEach(m=>{S.progress['u-awa'][m.id]={viewed:true,pct:100}}); const ev1=t2.chapters[0].assessment; if(ev1&&ev1.type==='quiz')(S.evAttempts['u-awa'][ev1.id]=S.evAttempts['u-awa'][ev1.id]||[]).push({pct:100,passed:true}); })()");
w.eval("location.hash='#/formation/t-marketing/evaluation/c2';render();");
const card = w.document.getElementById('eqCard');
log('1. Évaluation quiz : plus d’animation (classe eq-in retirée)', card && !card.className.includes('eq-in'));
log('2. CSS : keyframes eqIn supprimées', !css.includes('eqIn'));

// --- B. Évaluation par soumission de fichier ---
// débloque tout jusqu'à ev-c3 (soumission)
q("(function(){ S.evAttempts['u-awa']=S.evAttempts['u-awa']||{}; S.progress['u-awa']=S.progress['u-awa']||{}; const t=getTraining('t-marketing'); const steps=stepsOf(t); const i=steps.findIndex(s=>s.id==='ev-c3'&&s.kind==='assessment'); for(let j=0;j<i;j++){const s=steps[j]; if(s.kind==='module')S.progress['u-awa'][s.id]={viewed:true,pct:100}; if(s.kind==='assessment'&&s.ref.type==='quiz')(S.evAttempts['u-awa'][s.id]=S.evAttempts['u-awa'][s.id]||[]).push({pct:100,passed:true});} })()");
w.eval("location.hash='#/quiz';render();");
log('3. Mes évaluations : la soumission apparaît avec « Soumettre mon travail »', body().includes('Travail final — Calendrier éditorial') && body().includes('Soumettre mon travail'));
const evHref = q("(function(){const t=getTraining('t-marketing');const ev=t.chapters[2].assessment;return stepHref(t,{kind:'assessment',id:ev.id,ref:ev,chRef:t.chapters[2]})})()");
w.eval(`location.hash='${evHref.replace('#','')}';render();`);
log('4. Page évaluation : formulaire de soumission présent', !!w.document.getElementById('subFile'));
// soumission (simulation du record produit par submitWork)
q("(function(){ S.submissions.push({id:'sd-test',userId:'u-awa',trainingId:'t-marketing',evId:'ev-c3',file:'calendrier.pdf',size:'1 Mo',status:'pending',at:Date.now(),feedback:null}); })()");
w.eval("render();");
log('5. Après soumission : attente + chapitre suivant verrouillé annoncé', body().includes('reste verrouillé') && body().includes('en cours de correction') && !w.document.getElementById('subFile'));
log('6. Non validée : chapitre non terminé, formation incomplète', !q("stepDone('u-awa',getTraining('t-marketing'),{kind:'assessment',id:'ev-c3',ref:getTraining('t-marketing').chapters[2].assessment})") && !q("trainingCompleted('u-awa',getTraining('t-marketing'))"));
// coach demande une nouvelle tentative
q("(function(){ const x=S.submissions.find(s=>s.id==='sd-test'); x.status='retry'; x.feedback='Le calendrier doit couvrir 30 jours.'; x.decidedAt=Date.now(); })()");
w.eval("render();");
log('7. Nouvelle tentative demandée : bannière + formulaire pour resoumettre', body().includes('Nouvelle tentative demandée') && body().includes('30 jours') && !!w.document.getElementById('subFile'));
// resoumission
q("(function(){ const o=S.submissions.find(s=>s.id==='sd-test'); o.status='replaced'; S.submissions.push({id:'sd-test2',userId:'u-awa',trainingId:'t-marketing',evId:'ev-c3',file:'calendrier-v2.pdf',size:'1 Mo',status:'pending',at:Date.now(),feedback:null}); })()");
w.eval("render();");
log('8. Resoumission possible jusqu’à validation (retour en correction)', body().includes('calendrier-v2.pdf') && body().includes('en cours de correction'));
// coach valide (via applyDecision avec modal ouverte)
q("openModal({title:'Valider',body:'<textarea id=\\\"decFb\\\">Bravo</textarea>',foot:''})");
q("applyDecision('sd-test2','approved')");
w.eval("location.hash='#/quiz';render();");
log('9. Validation coach : évaluation validée ✓ partout', body().includes('Validé ✓') && q("stepDone('u-awa',getTraining('t-marketing'),{kind:'assessment',id:'ev-c3',ref:getTraining('t-marketing').chapters[2].assessment})") && q("trainingCompleted('u-awa',getTraining('t-marketing'))"));
log('10. Certificat émis après validation de la dernière évaluation', (q("(S.certs||[]).filter(c=>c.userId==='u-awa'&&c.trainingId==='t-marketing')") || []).length > 0);
w.eval(`location.hash='${evHref.replace('#','')}';render();`);
log('11. Page évaluation : « Travail validé » + plus de formulaire', body().includes('Travail validé') && !w.document.getElementById('subFile'));
log('12. Notification de validation envoyée à l’étudiant', q("(S.notifs||[]).some(n=>n.title.includes('validée'))"));
done('SMOKE34');
