/* SMOKE55 — Corrections : support réservé, appareil, pays, profil, audios,
   stickers in-place, S'abonner (redirection + contrôle horodaté), Assistant virtuel, purge. */
const fs = require('fs');
const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();

w.eval("__setSession({userId:'u-awa',token:'x'});");

/* ---- 1. Chat support réservé aux membres « support » (Yann exclu) ---- */
log('1. Compte test support présent → discussion attribuée au support (jamais Yann)',
  q("supportStaff().length") >= 1 && q("supportStaff().every(u=>u.id!=='u-yann')") === true &&
  q("(function(){ S.supportThreads=[]; const t=supportThread(); return t ? t.staffId : 'null' })()") === 'u-test-support');

/* ---- 2. Sans AUCUN membre support : la discussion ne passe pas ---- */
const th = q("(function(){ const keep=S.team; S.supportThreads=[]; S.team=S.team.filter(m=>!m.roles.includes('support')); openSupportChat(); const v=SUP.popView; const t=supportThread(); S.team=keep; return v+'|'+t })()");
log('2. Aucun membre support → vue « indisponibilité » + aucun fil créé (jamais Yann)',
  th === 'nosup|null');

/* ---- 3. Report : notifie le support en priorité ---- */
log('3. Support prioritaire pour les reports (membre support présent)',
  q("(function(){ const sup=supportStaff()[0]; return sup ? sup.id : 'aucun' })()") === 'u-test-support');

/* ---- 4. Pays : sélecteur drapeaux + recherche + validation ---- */
q("location.hash='#/parametres';render();");
const iCI = q("COUNTRIES.findIndex(c=>c.n==='Côte d’Ivoire')");
q(`ctryPick(${iCI})`);
log('4. Paramètres : sélecteur drapeaux avec recherche, pays + indicatif enregistrés',
  !!w.document.getElementById('ctryBtn') && !!w.document.getElementById('ctrySearch') &&
  q("getUser('u-awa').dial") === '+225' && body().includes('🇨🇮'));

/* ---- 5. Validation du numéro par pays (règle d'or : jamais de numéro invalide) ---- */
log('5. Validation téléphone : CI 10 chiffres OK, 3 chiffres KO, préfixe +225 accepté',
  q("phoneValid(COUNTRIES.find(c=>c.n==='Côte d’Ivoire'),'0759000000')") === true &&
  q("phoneValid(COUNTRIES.find(c=>c.n==='Côte d’Ivoire'),'123')") === false &&
  q("phoneValid(COUNTRIES.find(c=>c.n==='Côte d’Ivoire'),'+225 07 59 00 00 00')") === true &&
  q("COUNTRIES.length") >= 40);

/* ---- 6. Profil : Annuler avec modifications → « Toutes vos modifications seront perdues » ---- */
q("location.hash='#/profil';render();");
q("(function(){ const n=document.getElementById('pfName'); if(n) n.value='Nouveau Nom'; })()");
q("pfCancel()");
log('6. Profil : Annuler après modification → « Voulez-vous vraiment annuler ? / modifications perdues »',
  body().includes('Voulez-vous vraiment annuler') && body().includes('Toutes les modifications seront perdues'));
q("closeModal()");

/* ---- 7. Messages biométrie : « appareil » + OS détecté, jamais « téléphone » ---- */
const msg = q("fpUnavailableMsg({api:true,auth:false})") + ' ' + q("deviceInfo()");
log('7. Empreinte : messages parlent de l’« appareil » avec OS détecté (jamais « téléphone »)',
  msg.includes('appareil') && !msg.includes('téléphone') && /Windows|Apple|Linux|Android|iOS/.test(q("deviceInfo()")));

/* ---- 8. Stickers : mise à jour in-place (la vidéo ne repart pas de zéro) ---- */
q("location.hash='#/formation/t-marketing/module/m2-2';render();");
log('8. Module : la rangée de stickers est rendue via reactRowHTML + contexte mémorisé',
  !!w.document.querySelector('.react-row') && q("!!CP.lastModule && CP.lastModule.id==='m2-2'"));
q("(function(){ S.reactions=[]; toggleReact('m2-2','🔥'); })()");
log('9. Sticker : compteur mis à jour dans le DOM sans re-render complet',
  q("(S.reactions||[]).filter(r=>r.mid==='m2-2'&&r.emoji==='🔥').length") === 1 &&
  !!w.document.querySelector('.react-row .react-bub.on'));

/* ---- 10. Audios : couverture cercle + clic → playlist + lecture réelle (preload none) ---- */
q("CP.audioList=false;location.hash='#/audios';render();");
const cardOK = w.document.querySelectorAll('audio').length === 0 && !!w.document.querySelector('.au-cover .au-ov');
q("openAudioList()");
const au = w.document.querySelector('audio');
log('10. Audios : cartes sans préchargement (quota), puis playlist avec lecteur réel',
  cardOK && !!au && au.getAttribute('preload') === 'none' && (au.getAttribute('src') || '').includes('assets/au-ora.wav'));

/* ---- 11. S'abonner : vraie page + confirmation horodatée (contrôle) ---- */
q("location.hash='#/accueil';render();");
q("subSocial('soc-1')");
log('11. S’abonner : ouvre la page réelle + modale de confirmation (rien n’est marqué avant)',
  body().includes('Avez-vous rejoint Instagram') && body().includes('horodatée') &&
  q("!(S.socialSubs['u-awa'] || {})['soc-1']") === true);
q("closeModal();subSocialConfirm('soc-1')");
log('12. Contrôle : confirmation horodatée enregistrée + visible par l’admin',
  q("!!((S.socialSubs['u-awa']||{})['soc-1']||{}).at") === true &&
  q("(function(){ S.session.userId='u-yann'; const h=adminSubsRows(); S.session.userId='u-awa'; return h })()").includes('Confirmé le'));

/* ---- 13. « Assistant virtuel » partout, plus jamais « Assistant IA » ---- */
const src = ['js/views-student.js', 'js/views-admin.js'].map(f => fs.readFileSync(f, 'utf8')).join('');
log('13. Assistant renommé « Assistant virtuel » (plus aucun « Assistant IA »)',
  src.includes('Assistant virtuel') && !src.includes('Assistant IA'));

/* ---- 14. Vidéo complémentaire de test (art oratoire, YouTube) ---- */
log('14. Vidéo complémentaire de test en place sur « Vaincre le trac »',
  q("(function(){ const t=S.trainings.find(x=>x.id==='t-orateur'); const m=t.chapters[0].modules.find(x=>x.id==='m1-1'); return m.extraVideos[0].url })()").includes('youtube.com/watch?v=EohCLg3dqeI'));

/* ---- 15. CSS : cercle audio, logo +4px desktop, espaces dashboard, support sombre, menu mobile ---- */
const css = fs.readFileSync('style.css', 'utf8');
log('15. CSS : couverture circulaire + casque, logo +4 px (≥768px), espaces « coup d’œil », fab sombre, menu mobile',
  css.includes('.au-cover{position:relative;border-radius:50%}') && css.includes('.au-cover .au-ov') &&
  css.includes('@media(min-width:768px){.lg-logo{width:174px;height:174px}}') &&
  css.includes('.cp-grid2{gap:34px}') && css.includes('[data-theme="dark"] .fab-sup{color:#d9d5e6}') &&
  css.includes('.vset-grid{grid-template-columns:1fr !important'));

/* ---- 16. Purge : plateforme entièrement vierge ---- */
q("__setSession({userId:'u-yann',token:'x'});doPurgeDemo();");
log('16. Purge démo : contenus et comptes démo supprimés — comptes test (un par rôle) conservés',
  q("S.trainings.length") === 0 && q("S.resources.length") === 0 &&
  q("S.users.filter(u=>u.id!=='u-yann').every(u=>u.id.indexOf('u-test-')===0)") === true && q("S.users.length") === 9 &&
  q("S.sales.length") === 0 && q("S.enrollments.length") === 0 && q("!!S.settings.chariow"));

done('SMOKE55');
