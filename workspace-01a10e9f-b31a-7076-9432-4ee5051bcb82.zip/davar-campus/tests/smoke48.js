const { log, done } = require('./_boot');
(async () => {
const L6 = await import('../security/workers/layer6-amtd.mjs');
const L8 = await import('../security/workers/layer8-honeypots.mjs');
const L9 = await import('../security/workers/layer9-agents.mjs');

let t0 = 1000000;
const m = new L6.RouteMutator({ routes: ['/api/paiement', '/api/connexion'], intervalMs: 3600000, now: () => t0 });
const a1 = L6.aliasOf('/api/paiement', m.epoch);
const r1 = m.resolve(a1);
log('1. Couche 6 : alias courant résout vers la vraie route', r1 && r1.route === '/api/paiement');
m.mutate('attaque détectée');
const r2 = m.resolve(a1);
log('2. Couche 6 : après mutation, l’ancienne route ne résout plus (→ pot de miel)', r2 === null);
const a2 = L6.aliasOf('/api/paiement', m.epoch);
log('3. Couche 6 : nouvel alias actif', m.resolve(a2).route === '/api/paiement');
t0 += 2 * 3600000; m.tick();
log('4. Couche 6 : mutation planifiée après l’intervalle', m.epoch === 3 && m.log.length === 2);

log('5. Couche 8 : sondages reconnus, chemin légitime ignoré', L8.isProbe('/wp-admin/setup.php') === true && L8.isProbe('/.env') === true && L8.isProbe('/formation/oratoire') === false);
log('6. Couche 8 : score pondéré → bannissement auto au seuil', L8.attackerScore([{ type: 'probe' }, { type: 'payload' }, { type: 'probe' }]) >= L8.BAN_THRESHOLD && L8.shouldBan(L8.BAN_THRESHOLD) === true && L8.shouldBan(2) === false);

log('7. Couche 9 : commande dangereuse bloquée sans unanimité', L9.swarmDecide('rm -rf /var/data', { recon: 'allow', defense: 'block', validation: 'allow' }).decision === 'block');
log('8. Couche 9 : dangereuse/sensible = unanimité exigée ; safe = majorité', L9.swarmDecide('rm -rf /tmp/x', { recon: 'allow', defense: 'allow', validation: 'allow' }).decision === 'allow' && L9.swarmDecide('delete from avis', { recon: 'allow', defense: 'allow', validation: 'block' }).decision === 'block' && L9.swarmDecide('delete from avis', { recon: 'allow', defense: 'allow', validation: 'allow' }).decision === 'allow' && L9.swarmDecide('ls -la', { recon: 'block', defense: 'allow', validation: 'allow' }).decision === 'allow');
done('SMOKE48');
})();
