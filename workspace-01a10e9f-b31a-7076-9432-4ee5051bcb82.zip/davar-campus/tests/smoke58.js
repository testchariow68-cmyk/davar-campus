/* SMOKE 58 — Vue test & profil : comptes test uniquement, layout plein écran, annuler confirmé. */
const fs = require('fs');
const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const tick = () => new Promise(r => setImmediate(r));

(async () => {
  /* 1. « Tester une vue » : uniquement des comptes test, jamais une vraie personne */
  const ids = JSON.parse(q("JSON.stringify(viewAsList().map(x => x.id))"));
  log('1. Vue test : comptes test seulement (étudiant test inclus, Awa absente)',
    ids.length === 8 && ids.includes('u-test-etudiant') && ids.every(i => i.indexOf('u-test-') === 0) && !ids.includes('u-awa'));

  /* 2. Compte test étudiant : inscrit + progression réaliste */
  log('2. Étudiant (test) : 2 formations + progression > 0',
    q("getUser('u-test-etudiant') ? getUser('u-test-etudiant').name : ''") === 'Étudiant (test)' &&
    q("myTrainings('u-test-etudiant').length") === 2 &&
    q("trainingProgress('u-test-etudiant', getTraining('t-marketing')).pct") > 0);

  /* 3. Vue test étudiant : dashboard PLEINE largeur (bannière dans la colonne principale) */
  const lay = JSON.parse(q("(function(){ S.session={userId:'u-test-etudiant',token:'x',viewAsReal:'u-yann'}; location.hash='#/'; render(); const b=document.querySelector('.viewas-bar'); return JSON.stringify({present:!!b, inMain:!!(b&&b.closest('.cp-main')), directApp:!!(b&&b.parentElement&&b.parentElement.classList.contains('cp-app')), quit:!!(b&&b.querySelector('.viewas-quit'))}) })()"));
  log('3. Vue test étudiant : bannière dans cp-main (plus de colonne qui écrase), bouton Quitter présent',
    lay.present && lay.inMain && !lay.directApp && lay.quit);

  /* 4. Comptes de démonstration : visibles en pré-production, masqués en mode production */
  q("S.session=null; S.settings.productionMode=false; location.hash='#/login'; render();");
  const demoPre = body().includes('Comptes de démonstration');
  q("S.settings.productionMode=true; render();");
  const demoProd = body().includes('Comptes de démonstration');
  q("S.settings.productionMode=false;");
  log('4. Démo visibles maintenant (pré-prod) ; masquées automatiquement en mode production', demoPre && !demoProd);

  /* 5. Dashboards staff : sous-titre sans la mention inutile */
  const sub = q("(function(){ S.session={userId:'u-test-coach',token:'x'}; location.hash='#/admin'; render(); return document.getElementById('adPage').textContent })()");
log('5. Staff : « votre espace de travail complet. » sans l’ancienne mention',
  sub.includes('votre espace de travail complet') && !sub.includes('uniquement vos indicateurs'));

  /* 6. Profil : Annuler avec modifications → confirmation ; NON = reste + conserve ; OUI = reset + sortie */
  q("S.session={userId:'u-awa',token:'x'}; location.hash='#/profil'; render();");
  q("document.getElementById('pfName').value='Nom Modifié';");
  const dirty = q("pfDirty()") === true;
  q("pfCancel();");
  const modalTxt = q("document.querySelector('.modal') ? document.querySelector('.modal').textContent : ''");
  const askOk = modalTxt.includes('Voulez-vous vraiment annuler') && modalTxt.includes('Toutes les modifications seront perdues');
  q("closeModal(); window.__cres(false);");   /* choix NON */
  const stayVal = q("document.getElementById('pfName') ? document.getElementById('pfName').value : 'SORTI'");
  const stayModalGone = q("!document.querySelector('.modal')");
  q("pfCancel();");
  q("try { window.history.back = function(){ location.hash='#/'; render(); }; } catch(e) {}");
  q("closeModal(); window.__cres(true);");    /* choix OUI */
  await tick();                               /* laisse le .then s'exécuter */
  const outAfterYes = q("document.getElementById('pfName') ? 'ENCORE' : 'SORTI'");
  log('6. Profil : Annuler demande confirmation ; NON = reste avec saisies ; OUI = reset + sortie',
    dirty && askOk && stayVal === 'Nom Modifié' && stayModalGone && outAfterYes === 'SORTI');

  /* 7. Sans modification : Annuler sort directement, sans confirmation */
  q("S.session={userId:'u-awa',token:'x'}; location.hash='#/profil'; render();");
  q("try { window.history.back = function(){ location.hash='#/'; render(); }; } catch(e) {}");
  q("pfCancel();");
  log('7. Profil sans modification : Annuler sort directement (pas de modale)', !q("!!document.querySelector('.modal')"));

  /* 8. « S’abonner » : ouvre VRAIMENT un nouvel onglet vers la page du réseau */
  const op = q("(function(){ window.open=function(u,t){ window.__op=(u||'')+'|'+(t||''); return null; }; const s=S.settings.socials[0]; subSocial(s.id); return window.__op })()");
  log('8. « S’abonner » : window.open en _blank vers la vraie page (' + String(op).slice(0, 26) + '…)',
    String(op).startsWith('http') && String(op).endsWith('|_blank'));

  done('SMOKE58');
})();
