/* SMOKE 61 — Batch 66 : Home 1×/2× pendant édition profil, logo cliquable partout, menu staff (mot de passe), renommage « Analyse assistants virtuels ». */
const { boot, log, done } = require('./_boot');
const { q } = boot();
const fs = require('fs');
const wait = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  /* 1. Home 1× pendant une modification de profil = confirmation (comme Annuler) */
  q("(function(){ S.session={userId:'u-awa',token:'x'}; location.hash='#/profil'; render(); document.getElementById('pfName').value='Nom Modifié'; return pfEditingDirty() })()");
  const dirty1 = q("pfEditingDirty()");
  log('1. Profil modifié détecté comme « en cours de modification »', dirty1 === true);
  q("fabHomeTap();");
  await wait(450);
  const modalTxt = q("document.body.textContent");
  log('1b. 1 seul appui sur Home = demande de confirmation (comme Annuler)', modalTxt.includes('Quitter le profil ?') && modalTxt.includes('Quitter sans enregistrer'));
  q("closeModal(); window.__cres(true);");
  await wait(50);
  const afterYes = q("location.hash + '|' + (document.getElementById('pfName') ? document.getElementById('pfName').value : 'parti')");
  log('1c. Oui → sortie vers l’accueil + saisies remises à zéro', afterYes.startsWith('#/') && !afterYes.includes('Nom Modifié'));

  /* 2. Home 2× = sortie forcée, la modification n’a PAS lieu, sans confirmation */
  q("location.hash='#/profil'; render(); document.getElementById('pfName').value='Nom Forcé'; document.getElementById('pfPwd').value='SECRET@99'; document.getElementById('pfPwd2').value='SECRET@99';");
  q("fabHomeTap(); fabHomeTap();");
  await wait(50);
  const forced = q("location.hash");
  const noModal = q("!document.body.textContent.includes('Quitter le profil ?')");
  log('2. 2 appuis sur Home = sortie forcée immédiate sans confirmation', forced === '#/' && noModal);
  q("location.hash='#/profil'; render();");
  const reset = q("document.getElementById('pfName').value + '|' + document.getElementById('pfPwd').value");
  log('2b. Modification abandonnée : nom inchangé, code secret vidé', reset === 'Awa Koné|');
  const pwdKept = q("JSON.stringify((getUser('u-awa').password || 'aucun'))");
  log('2c. Aucun code secret enregistré par la sortie forcée', pwdKept === '"aucun"');

  /* 3. Profil SANS modification : Home 1× = simple retour (comportement normal) */
  q("location.hash='#/parametres'; render(); location.hash='#/profil'; render();");
  q("fabHomeTap();");
  await wait(450);
  const noConfirm = q("!document.body.textContent.includes('Quitter le profil ?')");
  log('3. Sans modification : Home 1× = retour normal, aucune confirmation', noConfirm);

  /* 4. Menu utilisateur staff : accès au profil et au code secret depuis le dashboard */
  const foot = q("(function(){ S.session={userId:'u-yann',token:'x'}; location.hash='#/admin'; render(); return document.querySelector('.sb-foot').getAttribute('onclick') || '' })()");
  log('4. Pied de sidebar staff cliquable (menu compte)', foot.includes('adminUserPop'));
  const pop = q("(function(){ adminUserPop({stopPropagation(){}}, document.querySelector('.sb-foot')); return document.getElementById('adUserPop').textContent })()");
  log('4b. Menu staff : Mon profil (nom & code secret) + Paramètres + Déconnexion', pop.includes('Mon profil') && pop.includes('code secret') && pop.includes('Paramètres') && pop.includes('Se déconnecter'));
  const staffPwd = q("(function(){ location.hash='#/profil'; render(); const p=document.getElementById('pfPwd'); if(!p) return 'absent'; p.value='STAFF@2026'; document.getElementById('pfPwd2').value='STAFF@2026'; document.getElementById('pfName').value=getUser('u-yann').name; saveProfile(); return getUser('u-yann').password })()");
  log('4c. Staff modifie son mot de passe via le profil — enregistré dans les données', staffPwd === 'STAFF@2026');

  /* 5. Logo cliquable sur TOUS les dashboards (aperçu agrandi) */
  const logoAdm = q("brandDarkHTML()");
  const logoStud = q("brandHTML()");
  log('5. Logo cliquable : dashboard staff ET étudiant → aperçu agrandi', logoAdm.includes('openLogoZoom()') && logoStud.includes('openLogoZoom()'));
  const zoom = q("(function(){ openLogoZoom(); const z=document.getElementById('logoZoom'); const img=!!(z && z.querySelector('img')); closeLogoZoom(); return img && !document.getElementById('logoZoom') })()");
  log('5b. Aperçu du logo s’affiche et se replie', zoom === true);

  /* 6. Renommage : l’entrée analyste devient « Analyse assistants virtuels » (vs la configuration IA) */
  const nav = q("(function(){ S.session={userId:'u-test-analyste',token:'x'}; location.hash='#/admin'; render(); return document.querySelector('.sidebar').textContent })()");
  log('6. Entrée analyste renommée « Analyse assistants virtuels » (distincte de la configuration)', nav.includes('Analyse assistants virtuels'));
  const src = fs.readFileSync('js/views-admin.js', 'utf8');
  log('6b. Titre de page synchronisé', src.includes("assistants: 'Analyse assistants virtuels'"));

  done('SMOKE61');
})();
