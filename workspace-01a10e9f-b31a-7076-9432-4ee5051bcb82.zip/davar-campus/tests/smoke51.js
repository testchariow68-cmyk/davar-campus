const { boot, log, done } = require('./_boot');
const { w, q } = boot();
(async () => {
const R2 = await import('../security/workers/r2-signed-url.mjs');
const c = require('crypto');
const te = s => new TextEncoder().encode(s);

/* 1. Le HMAC-SHA256 JS pur est identique à node:crypto (RFC 4231 vivant) */
const ref = c.createHmac('sha256', 'cle-secrete').update('videos/m1.mp4|1700000000000').digest('hex');
const ours = Buffer.from(R2.hmacSha256(te('cle-secrete'), te('videos/m1.mp4|1700000000000'))).toString('hex');
log('1. HMAC-SHA256 JS pur == node:crypto', ref === ours);

/* 2. URL signée : round-trip, expiration, falsification */
const now = 1700000000000;
const url = R2.signVideoUrl('videos/m1.mp4', { secret: 's3cret', now });
const ok1 = R2.verifyVideoUrl(url, { secret: 's3cret', now: now + 1000 });
const exp = R2.verifyVideoUrl(url, { secret: 's3cret', now: now + 2 * 3600000 });
const tam = R2.verifyVideoUrl(url.slice(0, -2) + '00', { secret: 's3cret', now });
log('2. URL signée : valide 1 h, expirée rejetée, falsifiée rejetée', ok1.ok === true && ok1.key === 'videos/m1.mp4' && exp.ok === false && tam.ok === false);

/* 3. Lecteur : TikTok lu gratuitement via embed officiel */
w.eval("window.SEC=null");
const tk = q("embedHTML('https://www.tiktok.com/@davaracademie/video/7301234567890123456','16:9')");
log('3. Lecteur TikTok : iframe embed v2', tk.includes('tiktok.com/embed/v2/7301234567890123456'));

/* 4. Lecteur : YouTube non répertoriée toujours supporté (nocookie) */
const yt = q("embedHTML('https://youtu.be/abc123def45','16:9')");
log('4. Lecteur YouTube : iframe nocookie', yt.includes('youtube-nocookie.com/embed/abc123def45'));

/* 5. Lecteur : source r2: → <video> avec URL signée réelle */
w.__r2 = R2; q("window.SEC = { R2: window.__r2 }");
const rv = q("embedHTML('r2:videos/oratoire-m1.mp4','16:9')");
const sigOk = rv.includes('<video') && rv.includes('/v/videos%2Foratoire-m1.mp4?exp=') && rv.includes('sig=') && rv.includes('vidwrap') && rv.includes('vidbar');
const m2 = rv.match(/src="([^"]+)"/);
const verif = m2 ? R2.verifyVideoUrl(m2[1].replace(/&amp;/g, '&'), { secret: 'davar-demo' }).ok : false;
log('5. Lecteur r2: : URL signée vérifiable, AUCUN contrôle natif → aucun bouton télécharger', sigOk === true && verif === true && !/ controls/.test(rv) && !rv.includes('controlsList') && !rv.includes('download'));
log('6. Jauge budget vidéo : catalogue mesuré, ~55 h possibles dans le gratuit', q("videoBudget().gb") > 1 && q("videoBudget().hours") >= 6.5 && q("videoBudget().hoursCap") === 55);
done('SMOKE51');
})();
