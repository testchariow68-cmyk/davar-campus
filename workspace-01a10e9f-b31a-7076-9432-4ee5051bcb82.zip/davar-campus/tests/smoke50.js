const { boot, log, done } = require('./_boot');
const { w, q } = boot();
(async () => {
const L7 = await import('../security/workers/layer7-botdetection.mjs');
const L9 = await import('../security/workers/layer9-agents.mjs');
const BOT = Array.from({ length: 20 }, (_, i) => ({ t: i * 16, x: i * 10, y: 0, p: 0.5 }));
const HUM = Array.from({ length: 20 }, (_, i) => ({ t: i * 17 + (i % 3) * 7, x: i * 9 + (i % 4), y: Math.sin(i) * 3, p: 0.4 + (i % 5) / 20 }));

/* sans modules chargés : le prototype reste utilisable (environnement de test) */
q("S.session=null"); w.SEC_TELEMETRY.samples = BOT.slice();
q("doLogin('u-awa')");
log('1. Sans modules : connexion normale possible', q("S.session.userId") === 'u-awa');

/* modules réels branchés (comme le <script type="module"> du navigateur) */
w.__sec = { L7, L9 };
q("window.SEC = window.__sec");
q("S.session=null"); w.SEC_TELEMETRY.samples = BOT.slice();
q("doLogin('u-awa')");
log('2. Couche 7 branchée : télémétrie automate → connexion refusée', q("!S.session") === true);

w.SEC_TELEMETRY.samples = HUM.slice();
q("doLogin('u-awa')");
log('3. Couche 7 branchée : télémétrie humaine → connexion acceptée', q("S.session.userId") === 'u-awa');

/* couche 9 branchée : l'essaim vote avant purge immédiate */
q("__setSession({userId:'u-yann',token:'x'})");
q("S.users.push({id:'u-p1',role:'student',name:'PurgeMe',email:'p1@davarcampus.co'})");
q("S.purgePending.push({userId:'u-p1',at:Date.now()-8*86400000,reason:'test'})");
q("getUser('u-p1').hold=true");
const before = q("S.anonymStats.accountsPurged");
q("execPurge('u-p1')");
log('4. Couche 9 branchée : exception en cours → essaim bloque la purge', q("S.anonymStats.accountsPurged") === before && q("getUser('u-p1').name") === 'PurgeMe');

q("getUser('u-p1').hold=false");
q("execPurge('u-p1')");
log('5. Couche 9 branchée : quarantaine respectée + admin → essaim autorise, purge exécutée', q("S.anonymStats.accountsPurged") === before + 1);
log('6. Décisions de l’essaim journalisées (audit)', q("S.auditLog.some(a=>a.action==='swarm_decision')") === true);
done('SMOKE50');
})();
