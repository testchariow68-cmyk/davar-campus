/* SMOKE 60 — Batch 65 : compte réel planté + profil qui enregistre vraiment + horodatage #A020F0 + sections Analyste en navigation + fréquence bascules. */
const { boot, log, done } = require('./_boot');
const { q } = boot();
const fs = require('fs');
const css = fs.readFileSync('style.css', 'utf8');

/* 1. Compte réel planté : tresorsergeyapo2@gmail.com / YAPO SERGE TRÉSOR / DAVAR@2026 */
const owner = q("JSON.stringify(S.users.find(u => u.email === 'tresorsergeyapo2@gmail.com') || null)");
const o = JSON.parse(owner);
log('1. Compte réel planté : email, nom YAPO SERGE TRÉSOR, Super Admin', !!(o && o.name === 'YAPO SERGE TRÉSOR' && o.role === 'admin'));
const loginView = q("(function(){ S.session=null; location.hash='#/login'; render(); return document.body.innerHTML })()");
log('1b. Code secret planté DAVAR@2026 + écran de connexion affichant le compte', o.password === 'DAVAR@2026' && loginView.includes('YAPO SERGE TRÉSOR'));

/* 2. Profil : nom + code secret modifiables et ENREGISTRÉS dans les données */
q(`(function(){ S.session={userId:'u-yann',token:'x'}; location.hash='#/profil'; render();
  document.getElementById('pfName').value='YAPO S. Trésor';
  document.getElementById('pfPwd').value='NOUVEAU@2027'; document.getElementById('pfPwd2').value='NOUVEAU@2027';
  saveProfile(); })()`);
const u2 = q("JSON.stringify(getUser('u-yann'))");
const uu = JSON.parse(u2);
log('2. Profil enregistre vraiment : nouveau nom + nouveau code secret persistés dans les données', uu.name === 'YAPO S. Trésor' && uu.password === 'NOUVEAU@2027');
log('2b. E-mail conservé comme identifiant fixe', uu.email === 'tresorsergeyapo2@gmail.com');
q("S.session=null; location.hash='#/login'; render();");
q("loginEmail.value='tresorsergeyapo2@gmail.com'; loginPwd.value='DAVAR@2026'; tryLogin();");
const oldKey = q("S.session && S.session.userId");
log('2c. Ancien code secret refusé après modification', oldKey !== 'u-yann');
q("S.session=null; location.hash='#/login'; render();");
q("loginEmail.value='tresorsergeyapo2@gmail.com'; loginPwd.value='NOUVEAU@2027'; tryLogin();");
const newKey = q("S.session && S.session.userId");
log('2d. Nouveau code secret accepté + connexion journalisée (action login)', newKey === 'u-yann' && q("S.auditLog.some(a => a.action === 'login' && a.actor === 'u-yann')"));

/* 3. Horodatage staff : violet #A020F0 légèrement brillant */
const stamp = (css.match(/\.stamp\{[\s\S]*?\}/) || [''])[0];
log('3. Horodatage en #A020F0 avec brillance (text-shadow)', stamp.includes('#A020F0') && stamp.includes('text-shadow'));
const admStamp = q("(function(){ S.session={userId:'u-test-coach',token:'x'}; location.hash='#/admin'; render(); return document.getElementById('adPage').innerHTML.includes('class=\"xs stamp\"') })()");
log('3b. En-tête staff utilise la classe .stamp (violet brillant)', admStamp);

/* 4. Analyste : chaque donnée analysée = entrée de navigation + page dédiée */
const nav = q("(function(){ S.session={userId:'u-test-analyste',token:'x'}; location.hash='#/admin'; render(); return document.querySelector('.sidebar').textContent })()");
log('4. Navigation analyste : Vue d’ensemble, Analytics, Santé technique, Assistants virtuels, Badges, Activité étudiants',
  ['Vue d’ensemble', 'Analytics', 'Santé technique', 'Analyse assistants virtuels', 'Badges & distinctions', 'Activité étudiants'].every(s => nav.includes(s)));

const sante = q("(function(){ location.hash='#/admin/sante'; render(); return document.getElementById('adPage').textContent })()");
log('4a. Page Santé technique : passerelles + chronologie des bascules', sante.includes('Passerelles de paiement') && sante.includes('Chronologie des bascules'));

const ass = q("(function(){ location.hash='#/admin/assistants'; render(); return document.getElementById('adPage').textContent })()");
log('4b. Page Assistants : fréquence de bascule entre TOUS les assistants (0 si rien)', ass.includes('Fréquence des bascules') && ass.includes('Groq') && /0/.test(ass) && ass.includes('Journal des bascules'));

const bad = q("(function(){ location.hash='#/admin/badges'; render(); return document.getElementById('adPage').textContent })()");
log('4c. Page Badges : qui a reçu quel badge et quand', bad.includes('Badge') && bad.includes('Date & heure'));

const act = q("(function(){ location.hash='#/admin/activite'; render(); return document.getElementById('adPage').textContent })()");
log('4d. Page Activité : fréquence de connexion (30 j) + dernière activité, staff exclu', act.includes('Connexions (30 j)') && act.includes('Dernière activité') && !act.includes('YAPO') && !act.includes('Coach'));

/* 5. Le Super Admin voit aussi les sections analyste */
const admNav = q("(function(){ S.session={userId:'u-yann',token:'x'}; location.hash='#/admin'; render(); return document.querySelector('.sidebar').textContent })()");
log('5. Sections analyste visibles aussi pour le Super Admin', admNav.includes('Santé technique') && admNav.includes('Analyse assistants virtuels') && admNav.includes('Activité étudiants'));

done('SMOKE60');
