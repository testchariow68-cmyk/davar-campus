const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
w.eval("__setSession({userId:'u-awa',token:'x'});");
// certificat : jamais téléchargeable, e-mail seulement
q("showCert(S.certs.find(c=>c.userId==='u-awa').id)");
const modal = w.document.body.innerHTML;
log('1. Certificat : plus AUCUN bouton « Télécharger le PDF »', !modal.includes('Télécharger le PDF'));
log('2. Certificat : nuance affichée (jamais téléchargeable, envoyé par e-mail)', modal.includes('jamais') && modal.includes('e-mail'));
log('3. Certificat : renvoi par e-mail (Gmail) proposé', modal.includes('Renvoyer par e-mail'));
q("closeModal()");
// facture : téléchargeable en PDF après achat
q("S.settings.flutterwave.enabled=false;location.hash='#/checkout/t-anglais';render();CHECKOUT.step=2;CHECKOUT.method='wave';render();");
q("payViaMoneyFusion('t-anglais')");
await sleep(2600);
log('4. Facture : bouton de téléchargement PDF sur l’écran de succès', body().includes('Facture PDF'));
const pdf = q("makeSmallPDF([['test',10,0]])");
log('5. Facture : fichier PDF valide', pdf.startsWith('data:application/pdf;base64,') && q("decodeURIComponent(escape(atob('" + pdf.split(',')[1] + "')))").startsWith('%PDF'));
done('SMOKE44');
})();
