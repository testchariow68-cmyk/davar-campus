// Diagnostic de l'ouverture sur de vrais moteurs Chromium, exécuté séparément des tests jsdom.
const { chromium } = require('/home/user/node_modules/playwright');
const assert = require('node:assert/strict');
(async()=>{
  const browser = await chromium.launch({ headless:true, args:['--no-sandbox'] });
  const cases = [[320,480],[320,568],[360,640],[375,667],[390,844],[414,896],[768,1024],[1440,900]];
  for(const [w,h] of cases){
    const page = await browser.newPage({viewport:{width:w,height:h},deviceScaleFactor:1, isMobile:w<768,hasTouch:w<768});
    await page.goto('http://127.0.0.1:8080/#/login',{waitUntil:'domcontentloaded'});
    await page.waitForTimeout(1300);
    const dims=await page.evaluate(()=>{
      const pick=s=>{const e=document.querySelector(s),r=e.getBoundingClientRect();return {x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height),bottom:Math.round(r.bottom)}};
      const logo=pick('#splash img:not(.sp-maker)'),tag=pick('#splash .sp-slogan'),bar=pick('#splash .bar'),maker=pick('#splash img.sp-maker');
      return {screen:[innerWidth,innerHeight],logo,tag,bar,maker,gapLogoTag:tag.y-logo.bottom,gapBarMaker:maker.y-bar.bottom,hOverflow:document.documentElement.scrollWidth>innerWidth};
    });
    assert.equal(dims.hOverflow,false, `${w}x${h}: débordement horizontal`);
    assert.ok(dims.logo.x>=12 && dims.logo.x+dims.logo.w<=w-12, `${w}x${h}: logo rogné`);
    assert.ok(dims.logo.w/w<=0.66, `${w}x${h}: logo trop large`);
    assert.ok(dims.gapLogoTag>=0 && dims.gapLogoTag<=12, `${w}x${h}: slogan trop éloigné`);
    assert.ok(dims.gapBarMaker>=10 && dims.maker.bottom<=h, `${w}x${h}: signature superposée`);
    console.log(`${w}x${h}: OK (logo ${dims.logo.w}px, écart slogan ${dims.gapLogoTag}px)`);
    if(w===320&&h===568 || w===390&&h===844 || w===1440&&h===900) await page.screenshot({path:`/home/user/.cache/splash-${w}x${h}.png`});
    await page.close();
  }
  await browser.close();
  console.log('Ouverture mobile/desktop : 8 formats OK');
})().catch(e=>{console.error(e);process.exit(1)});
