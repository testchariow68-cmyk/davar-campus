const { boot, log, done } = require('./_boot');
const { w, q, body, fs, ROOT } = boot();
w.eval("__setSession({userId:'u-awa',token:'x'});location.hash='#/';render();");
log('1. Tableau de bord : plus de cartes empilées (sections ouvertes)', w.document.querySelectorAll('.cp-sec').length >= 2 && !w.document.querySelector('.cp-sec.card'));
log('2. Formation active : panneau à filet doré, plus une carte', !!w.document.querySelector('.cp-active') && !w.document.querySelector('.cp-active.card'));
log('3. Prochaine action : bandeau à accent, plus une carte', !w.document.querySelector('.cp-next.card'));
log('4. Chiffres nus « En un coup d’œil »', !!w.document.querySelector('.cp-stats') && !w.document.querySelector('.cp-stats').closest('.card'));
log('5. Parcours : chapitre en cours correctement détecté (bug ch.steps corrigé)', !!w.document.querySelector('.j-step.cur'));
// vocabulaire
w.eval("location.hash='#/formation/t-marketing/module/m1-1';render();");
log('6. « tous les étudiants » partout, plus « la classe »', body().includes('tous les étudiants') && !body().includes('la classe'));
const all = ['views-student.js','views-campus.js','views-admin.js','ui.js','data.js'].map(f => fs.readFileSync(ROOT + '/js/' + f, 'utf8')).join('');
log('7. Aucune occurrence de « la classe » dans le code', !/la classe/i.test(all));
done('SMOKE37');
