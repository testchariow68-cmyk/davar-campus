const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
w.eval("__setSession({userId:'u-yann',token:'x'});location.hash='#/admin';render();");

// --- A. Création : choix du type + formats + consignes ---
q("evalModal('t-marketing','c3')");
const sub = w.document.getElementById('evSub'), quiz = w.document.getElementById('evQuiz'), minW = w.document.getElementById('evMinWrap');
log('1. Éval fichier : consignes + formats visibles, QCM masqué', sub.style.display !== 'none' && quiz.style.display === 'none' && minW.style.display === 'none');
log('2. Titre prérempli pour une soumission existante', w.document.getElementById('evTitle').value === 'Travail final — Calendrier éditorial');
q("document.getElementById('evType').value='quiz';evTypeToggle()");
log('3. Bascule vers QCM : questions visibles, formats masqués', quiz.style.display !== 'none' && sub.style.display === 'none' && minW.style.display !== 'none');
q("document.getElementById('evType').value='submission';evTypeToggle()");
q("document.getElementById('evTitle').value='Discours filmé';document.getElementById('evIntro').value='Envoyez une vidéo de 3 minutes.'");
q("[...document.querySelectorAll('.evFmt')].forEach(x=>x.checked=(x.value==='video'||x.value==='image'))");
q("saveEval('t-marketing','c3')");
const a3 = q("getTraining('t-marketing').chapters[2].assessment");
log('4. Enregistrement : formats Vidéo+Photo, consignes, type soumission', a3.type === 'submission' && a3.formats.join() === 'video,image' && a3.accepts === 'Vidéo · Photo' && a3.intro === 'Envoyez une vidéo de 3 minutes.');
const stPage = q("evalSubmissionPage(getUser('u-awa'),getTraining('t-marketing'),getTraining('t-marketing').chapters[2],getTraining('t-marketing').chapters[2].assessment)");
log('5. L’étudiant voit les formats et consignes choisis par le coach', stPage.includes('Vidéo · Photo') && stPage.includes('Envoyez une vidéo de 3 minutes'));

// --- B. Correction : le coach regarde vraiment le fichier ---
q("(function(){ S.submissions.push({id:'sd-v',userId:'u-awa',trainingId:'t-marketing',evId:'ev-c3',file:'discours.mp4',size:'4 Mo',status:'pending',at:Date.now(),feedback:null}); lcStoreFile({kind:'video',owner:'u-awa',reason:'test',refType:'submission',refId:'sd-v',mime:'video/mp4',sizeBytes:4000000,name:'discours.mp4',dataUrl:'data:video/mp4;base64,AAAA',status:'active'}); })()");
q("openSubFile('sd-v')");
const html = w.document.body.innerHTML;
log('6. Le coach regarde la vidéo soumise (lecteur réel)', html.includes('Corriger : discours.mp4') && html.includes('<video') && html.includes('controls'));
log('7. Décision possible depuis le lecteur (Valider / Non conforme)', html.includes("decideSubmission('sd-v','approved')") && html.includes("decideSubmission('sd-v','retry')"));
const card = q("aEvaluations(getUser('u-yann'))");
log('8. Carte de correction : bouton Regarder + Non conforme', card.includes('Regarder / lire') && card.includes('Non conforme — à refaire'));
// --- C. Non conforme → explication obligatoire → à refaire ---
q("openSubFile('sd-v')");
q("closeModal();decideSubmission('sd-v','retry')");
log('9. Non conforme : titre du modal + explication obligatoire', w.document.body.innerHTML.includes('Déclarer non conforme') && !!w.document.getElementById('decFb'));
q("document.getElementById('decFb').value='Vidéo trop sombre, refaites-la.'");
q("applyDecision('sd-v','retry')");
const sv = q("S.submissions.find(s=>s.id==='sd-v')");
log('10. Retour envoyé à l’étudiant, statut à refaire', sv.status === 'retry' && sv.feedback.includes('trop sombre'));
done('SMOKE35');
