const { log, done } = require('./_boot');
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
const L10 = await import('../security/workers/layer10-fhe.mjs');
const L11 = await import('../security/workers/layer11-silicon.mjs');
const CH = await import('../security/workers/audit-chain.mjs');
const DO = await import('../security/workers/ephemeral-window-do.mjs');
const c = require('crypto');

/* ---------- Phase 4 : couche 10 (FHE) ---------- */
const kp = L10.keygen(512);
const e3 = L10.encrypt(3, kp.pub), e4 = L10.encrypt(4, kp.pub);
log('1. Couche 10 : Paillier round-trip', L10.decrypt(e3, kp.priv) === 3n);
const s7 = L10.cAdd(e3, e4, kp.pub);
const s17 = L10.cAddPlain(s7, 10, kp.pub);
log('2. Couche 10 : somme SUR chiffrés sans déchiffrement (3+4 puis +10 = 17)', L10.decrypt(s7, kp.priv) === 7n && L10.decrypt(s17, kp.priv) === 17n);

/* ---------- Phase 4 : couche 11 (silicium) ---------- */
const a1 = await L11.buildSiliconPrint({ cryptoTiming: 102, gpu: 'Adreno 740', cores: 8, mem: 8 });
const a2 = await L11.buildSiliconPrint({ cryptoTiming: 104, gpu: 'Adreno 740', cores: 8, mem: 8 });
const b1 = await L11.buildSiliconPrint({ cryptoTiming: 103, gpu: 'Apple M2', cores: 4, mem: 8 });
log('3. Couche 11 : même silicium, lectures différentes → empreinte stable', L11.samePrint(a1, a2));
log('4. Couche 11 : autre machine → empreinte différente', !L11.samePrint(a1, b1));

/* ---------- Phase 5 : fenêtre éphémère en Durable Object + chaîne d'audit ---------- */
const ek = c.generateKeyPairSync('ed25519');
const pubB64 = ek.publicKey.export({ type: 'spki', format: 'der' }).slice(-32).toString('base64');
const fromRaw = b64 => c.createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), Buffer.from(b64, 'base64')]), format: 'der', type: 'spki' });
const ed = { verify: async (b64, d, s) => c.verify(null, Buffer.from(d), fromRaw(b64), Buffer.from(s)), sign: async d => new Uint8Array(c.sign(null, Buffer.from(d), ek.privateKey)) };
let t0 = Date.now();
const alarms = [];
const state = { storage: { m: new Map(), async put(k, v) { this.m.set(k, v); }, async setAlarm(t) { alarms.push(t); } } };
const env = { VERIFY: ed.verify, NOW: () => t0, SECURITY_EVENTS: [] };
const dObj = new DO.EphemeralWindowDO(state, env);
const fReq = o => ({ json: async () => o });
const nonce = 'n-' + Math.random().toString(36).slice(2);
const sig = await ed.sign(nonce + '|' + t0);
const open = await (await dObj.fetch(fReq({ op: 'open', body: { nonce, ts: t0, signature: sig, pub: pubB64 } }))).json();
const auth = await (await dObj.fetch(fReq({ op: 'authorize', body: { action: 'purge_controle' } }))).json();
log('5. Phase 5 : DO ouvre la fenêtre signée + autorise l’action + alarme programmée', open.ok === true && auth.ok === true && alarms.length === 1);
t0 += 6 * 60 * 1000;
await dObj.alarm();
const late = await (await dObj.fetch(fReq({ op: 'authorize', body: { action: 'export' } }))).json();
log('6. Phase 5 : alarme → fenêtre fermée, action refusée', late.ok === false);
await sleep(60);
log('7. Règle 4 : chaîne d’audit immuable vérifiée', (await CH.verifyChain(env.SECURITY_EVENTS)).ok === true && env.SECURITY_EVENTS.length >= 3);
env.SECURITY_EVENTS[0].hash = 'f'.repeat(64);
log('8. Règle 4 : toute altération du journal est détectée', (await CH.verifyChain(env.SECURITY_EVENTS)).ok === false);
done('SMOKE49');
})();
