const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
w.eval("__setSession({userId:'u-awa',token:'x'});location.hash='#/formation/t-marketing/module/m1-2';render();");
q("(function(){ const m=getTraining('t-marketing').chapters[0].modules[1]; m.extraVideos=[{title:'Interview verticale',duration:'8:12',ratio:'9:16',url:'https://youtu.be/abcdefghijk'},{title:'Bonus sans URL',duration:'3:00',ratio:'16:9'}]; m.resources.push({name:'Démo vidéo',type:'video',size:'4 Mo',url:'https://youtu.be/zzzzzzzzzzz',ratio:'16:9'}); })()");
w.eval("render();");
log('1. Vidéos complémentaires cliquables (jouées dans le lecteur)', w.document.body.innerHTML.includes('playExtra(0)'));
q("playExtra(0)");
log('2. Le lecteur adopte le format soumis : cadre entier en 9:16', w.document.getElementById('playerBox').classList.contains('r-916') && w.document.querySelector('.card.fit-916'));
const altBack = w.document.querySelector('.alt-back');
log('3. Bouton « Revenir à la vidéo principale » petit et HORS du cadre, juste en bas', !!altBack && altBack.textContent.includes('Revenir à la vidéo principale') && !altBack.closest('.card') && !w.document.querySelector('.player-ui button[onclick="backToMain()"]'));
log('4. Vidéo en cours mise en évidence dans la liste', !!w.document.querySelector('.vid-card.on'));
q("backToMain()");
log('5. Retour : format du module repris, bouton disparu, cadre pleine largeur', w.document.getElementById('playerBox').classList.contains('r-169') && !w.document.querySelector('.alt-back') && !w.document.querySelector('.card.fit-916'));
q("playResVideo(1)");
log('6. Ressource vidéo : bouton Lire → chargée dans le lecteur', !!w.document.querySelector('.alt-back') && body().includes('Démo vidéo'));
// progression : vidéo complémentaire jamais comptée
q("backToMain()");
q("delete S.progress['u-awa']['m1-2']");
q("playExtra(1)");
q("PLAYER.pct=99;playToggle()");
await sleep(500);
log('7. Vidéo complémentaire terminée : module NON marqué comme vu', q("(S.progress['u-awa']['m1-2']||{}).viewed") !== true);
// leçon principale : toujours bloquante
q("backToMain()");
q("PLAYER.pct=99;playToggle()");
await sleep(500);
log('8. Leçon principale terminée : module marqué comme vu', q("(S.progress['u-awa']['m1-2']||{}).viewed") === true);
done('SMOKE39');
})();
