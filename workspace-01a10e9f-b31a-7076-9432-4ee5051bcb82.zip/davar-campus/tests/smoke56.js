/* SMOKE56 — Lot dashboard admin : comptes test & vues, menu, étudiants, notifications,
   activités, IA (bascule quotas), palettes, e-mails, exports, motivations, réseaux sociaux. */
const fs = require('fs');
const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();

w.eval("__setSession({userId:'u-yann',token:'x'});");

/* 1. Comptes test : exactement un par rôle, une seule combinaison */
log('1. Comptes test : 7 rôles staff × 1 compte + 1 compte étudiant test (jamais de vraie personne)',
  q("S.users.filter(u=>u.id.indexOf('u-test-')===0).length") === 8 &&
  q("S.users.filter(u=>u.id.indexOf('u-test-')===0 && u.role==='staff').length") === 7 &&
  q("S.users.filter(u=>u.id==='u-test-etudiant'&&u.role==='student'&&u.test)") !== undefined &&
  q("S.team.filter(m=>m.test).every(m=>m.roles.length===1)") === true &&
  q("S.team.filter(m=>m.test).length") === 7);

/* 2. Vues test : bascule + retour (Manager avec activation — le fondateur a le test de vue en permanence) */
q("S.session={userId:'u-test-manager',token:'x'}; S.settings.managerViewAs=true");
q("viewAs('u-test-coach')");
log('2. « Tester une vue » (Manager) : session basculée, compte réel mémorisé, retour possible',
  q("S.session.userId") === 'u-test-coach' && q("S.session.viewAsReal") === 'u-test-manager');
q("quitViewAs()");
const quitOK = q("S.session.userId") === 'u-test-manager' && q("S.session.viewAsReal") === undefined;
log('3. Quitter (bouton/Échap) : retour au compte réel + bannière avec bouton Quitter',
  quitOK && q("viewAsBannerHTML()") === '' &&
  fs.readFileSync('js/app.js', 'utf8').includes("e.key === 'Escape'") &&
  fs.readFileSync('style.css', 'utf8').includes('.viewas-quit'));

/* 4. Liste étudiants : Dernière connexion + Terminée le */
q("location.hash='#/admin/etudiants';render();");
const th = w.document.querySelector('table.tbl thead').textContent;
log('4. Étudiants : colonnes « Dernière connexion » (jour+heure) et « Terminée le » présentes',
  th.includes('Dernière connexion') && th.includes('Terminée le') && th.includes('Inscrit le') &&
  body().includes('jamais') === false && q("!!getUser('u-awa').lastLogin"));

/* 5. Notifications cliquables : redirection intelligente, informatives = simples */
log('5. Notifications : coach→questions, eval→évaluations (staff), info→aucune route',
  q("(function(){ S.session={userId:'u-awa',token:'x'}; const a=notifRoute({type:'coach'}); const b=notifRoute({type:'cert'}); S.session={userId:'u-yann',token:'x'}; const c=notifRoute({type:'eval'}); const d=notifRoute({type:'info'}); return a+'|'+b+'|'+c+'|'+d })()") === '#/questions|#/certificats|#/admin/evaluations|null');

/* 6. Déconnexion : impossible pour le Super Admin sans Manager présent */
const noMgr = q("(function(){ S.session={userId:'u-yann',token:'x'}; logout(); const still=!!S.session; return still })()");
const withMgr = q("(function(){ S.users.push({id:'u-vrai-mgr',name:'Vrai Manager',email:'vrai.mgr@davarcampus.co',role:'staff',joined:Date.now()}); S.team.push({id:'tm-vrai',name:'Vrai Manager',email:'vrai.mgr@davarcampus.co',roles:['manager']}); S.session={userId:'u-yann',token:'x'}; logout(); const out=!S.session; S.session={userId:'u-yann',token:'x'}; return out })()");
log('6. Super Admin : compte test ≠ Manager (déconnexion refusée) ; avec un VRAI Manager, elle marche',
  noMgr === true && withMgr === true);

/* 7. IA : chaîne de secours par quota journalier + retour automatique le lendemain */
q("S.aiUsage={}");
log('7a. IA : Groq actif en tête de chaîne', q("aiActiveProvider()") === 'groq');
q("aiMarkExhausted('groq')");
const relay = q("aiActiveProvider()");
q("(function(){ S.aiUsage.groq.day='2000-01-01' })()");   /* simule le lendemain : quota réinitialisé */
log('7. IA : quota atteint → Gemini prend le relais ; le lendemain Groq reprend la main',
  relay === 'gemini' && q("aiActiveProvider()") === 'groq');

/* 8. Transcription open source + vraie photo de l'assistant */
const aaiHTML = q("(function(){ location.hash='#/admin/ia'; render(); return 1 })()") && body();
log('8. Transcription Whisper (open source, sans VPS) + upload de vraie photo disponibles',
  body().includes('Whisper large-v3 via Groq') && body().includes('transformers.js') &&
  q("S.aiConfig.transcription") === 'groq-whisper' && 'photo' in q("S.aiConfig"));

/* 9. Palettes : brouillon jusqu’à « Enregistrer », puis appliquées partout + mode sombre noir (sauf signature) + palette au choix */
q("location.hash='#/admin/parametres'; render(); selectPal('foret')");
const draftNotApplied = q("document.documentElement.getAttribute('data-palette')") !== 'foret';
q("saveSettingsAll()");
const palOK = draftNotApplied && q("document.documentElement.getAttribute('data-palette')") === 'foret';
q("S.palette='custom';S.paletteCustom={p:'#00AA55',s:'#22CC77',a:'#FFCC00',grad:true};applyPalette();");
const customVar = w.document.documentElement.style.getPropertyValue('--violet');
log('9. Palettes : choix visuel appliqué + « Au choix » (couleurs libres) injecté en direct',
  palOK && customVar.toLowerCase() === '#00aa55' &&
  fs.readFileSync('style.css', 'utf8').includes('[data-theme="dark"][data-palette="custom"]') &&
  fs.readFileSync('style.css', 'utf8').includes('--bg:#0A0A0C'));

/* 10. Motivations : bouton Enregistrer, l'ancien termine puis s'écrase */
q("S.settings.motivations=['A','B','C'];S.settings.motivationsIndex=1;delete S.settings.motivationsNext");
q("location.hash='#/admin/parametres';render();");
q("(function(){ document.getElementById('motTxt').value='1. Nouvelle une.\\n2. Nouvelle deux.'; saveMotivationsReplace(); })()");
const queued = q("(S.settings.motivationsNext||[]).length") === 2 && q("S.settings.motivations[1]") === 'B';
q("sendMotivationNow();sendMotivationNow();sendMotivationNow();");
log('10. Motivations : la liste actuelle termine ses envois, puis la nouvelle enregistrée la remplace',
  queued && q("S.settings.motivations[0]") === 'Nouvelle une.' && q("S.settings.motivationsNext") === undefined);

/* 11. Réseaux sociaux : bouton modifier avant supprimer */
const socId = q("S.settings.socials[0].id");
q(`editSocialModal('${socId}')`);
w.document.getElementById('socEdLink').value = 'https://instagram.com/davaracademie_officiel';
q(`saveSocialEdit('${socId}')`);
log('11. Réseaux sociaux : lien modifiable (bic) puis enregistré',
  q("S.settings.socials[0].link") === 'https://instagram.com/davaracademie_officiel');

/* 12. Exports : jeu « Tout » + CSV réel + envoi par e-mail */
const rows = q("buildExportRows('etudiants','2020-01-01','2030-01-01').rows.length");
q("S.auditLog=[]");
q("(function(){ location.hash='#/admin/exports'; render(); S.session={userId:'u-yann',token:'x'}; document.getElementById('exData').value='etudiants'; document.getElementById('exPwd').value='DAVAR@2026'; runExport(); document.getElementById('exMailTo').value='test@exemple.com'; document.getElementById('exPwd').value='DAVAR@2026'; mailExport(); })()");
log('12. Exports : données bâtissables + envoi du CSV par e-mail APRÈS génération (journalisé, adresse de rôle)',
  rows > 1 && q("S.auditLog.some(a=>a.action==='mail')") === true &&
  fs.readFileSync('js/views-admin.js', 'utf8').includes("value=\"tout\""));

/* 13. Activités : journal + alertes push (importantes) pour Super Admin & Manager */
q("S.auditLog=[];S.notifs=[];");
q("(function(){ S.session={userId:'u-coach',token:'x'}; recordAudit('export',{data:'etudiants'}); S.session={userId:'u-yann',token:'x'}; })()");
log('13. Action importante → alerte au Super Admin (jamais au Manager test) + journal d’activités',
  q("S.notifs.filter(n=>n.userId==='u-yann'&&n.type==='staff').length") >= 1 &&
  q("S.notifs.filter(n=>n.userId==='u-test-manager').length") === 0 &&
  q("(function(){ location.hash='#/admin/activites'; render(); return document.body.textContent.includes('Export de données') })()"));

/* 14. Menu profil : « Profil » remplace « Centre de contrôle » ; home déplaçable partout */
const menu = q("UI.userMenu=true;userMenuHTML(getUser('u-yann'))");
log('14. Menu photo : « Profil » (plus de « Centre de contrôle ») + bouton Home déplaçable pour tous',
  menu.includes('Profil') && !menu.includes('Centre de contrôle') &&
  q("adminShell({parts:['admin','']},getUser('u-yann')).includes('fab-home')"));

/* 15. Intégrations : clés séparées Flutterwave / Money Fusion / Chariow API, CinetPay banni */
const conf = fs.readFileSync('js/views-admin.js', 'utf8');
log('15. Intégrations : sections Flutterwave, Money Fusion et API Chariow distinctes · CinetPay supprimé',
  conf.includes('asFwKey') && conf.includes('asMfKey') && conf.includes('asChariowKey') &&
  !conf.includes('CinetPay'));

/* 16. Combinaisons de rôles : Manager incombinable (dans les deux sens) */
q("S.session={userId:'u-yann',token:'x'};");
const comb1 = q("toggleRole('tm-t1','manager');(S.team.find(m=>m.id==='tm-t1').roles.includes('manager'))");
const comb2 = q("toggleRole('tm-t7','coach');(S.team.find(m=>m.id==='tm-t7').roles.length)");
const comb3 = q("toggleRole('tm-t1','correcteur');(S.team.find(m=>m.id==='tm-t1').roles.length)");
log('16. Rôles : Coach+Manager refusé, Manager+Coach refusé, Coach+Correcteur accepté',
  comb1 === false && comb2 === 1 && comb3 === 2);

/* 17. Équipe : comptes test identifiables, Yann sans mention « Coach principal » */
q("location.hash='#/admin/equipe';render();");
const teamTxt = body();
log('17. Équipe : badge « Compte test » visible ; plus aucune mention « Coach principal »',
  teamTxt.includes('Compte test') && !teamTxt.includes('Coach principal'));

/* 18. Paiement : plus aucun bouton « Confirmer le paiement » pour l'étudiant */
const vsrc = fs.readFileSync('js/views-student.js', 'utf8');
log('18. Paiement : bouton « Confirmer le paiement » supprimé, « Ouvrir le paiement sécurisé » conservé',
  !vsrc.includes('Confirmer le paiement (démo)</button>') && vsrc.includes('Ouvrir le paiement sécurisé'));

/* 19. Formations : les NOMS des étudiants sont affichés (le nombre seulement au-delà de 100) */
const csrc = fs.readFileSync('js/views-campus.js', 'utf8');
log('19. Formations : cartes sans mention d’inscrits (ni noms ni nombre), témoignages avec noms',
  csrc.includes('st ? esc(st.name)') && !vsrc.includes('tSocial') &&
  vsrc.includes('${t.code} · ⭐ ${t.rating}</div>') && !vsrc.includes('${t.students} étudiants') &&
  csrc.includes('class="btn btn-ghost btn-sm" href="#/catalogue"') && vsrc.includes('avec le coach principal'));

/* 20. Palettes : menu teinté, mode clair teinté, « Administration » en secondaire, webhook Money Fusion */
const css2 = fs.readFileSync('style.css', 'utf8');
const asrc = fs.readFileSync('js/views-admin.js', 'utf8');
log('20. Signature intacte + adaptations SCOPÉES aux autres palettes (menu, clair, Home, barres)',
  css2.includes('.sidebar{width:236px;background:var(--ink)') &&
  css2.includes('[data-palette]:not([data-palette="violet"]) .sidebar{background:var(--nav-bg,var(--violet))') &&
  css2.includes('--bg:#FFFFFF;--card:#FFFFFF') &&
  css2.includes('background:rgba(22,19,32,.55)') &&
  css2.includes('[data-palette]:not([data-palette="violet"]) .fab-home{background:var(--grad)') &&
  css2.includes('[data-palette]:not([data-palette="violet"])[data-theme="light"] .card{border-color:color-mix') &&
  css2.includes('.card{border-color:#EAE8F2}') &&
  css2.includes('[data-theme="dark"] .admin-top{background:rgba(13,11,20,.92)}') &&
  css2.includes('[data-palette]:not([data-palette="violet"])[data-theme="dark"] .admin-top{background:rgba(10,10,12,.92)}') &&
  css2.includes('color:var(--gold);margin-top:2px') &&
  asrc.includes("root.style.setProperty('--nav-bg'") && asrc.includes('asMfWebhook'));

/* 21. Identité : plus aucun violet/or figé sur avatars, badges et facture */
const dsrc = fs.readFileSync('js/data.js', 'utf8');
const rsrc = fs.readFileSync('js/rewards.js', 'utf8');
log('21. Identité : or/violets d’origine pour la signature, palette pour les autres (avatars, badges, facture)',
  css2.includes('--ava-sa:#C9A24B') && css2.includes('--lav:#C9B5F5') && css2.includes('--grad-mid:#5B21B6') &&
  css2.includes('[data-palette]:not([data-palette="violet"]){--lav:var(--violet2)') &&
  dsrc.includes("color: 'var(--ava-sa)'") && dsrc.includes("color: 'var(--ava-1)'") && dsrc.includes("color: 'var(--ava-2)'") &&
  dsrc.includes("'var(--violet-deep)'") && rsrc.includes("startsWith('var(')") &&
  vsrc.includes('const sig = (S.palette || \'violet\') === \'violet\'') &&
  asrc.includes("'b-gold' : 'b-violet'"));

/* 22. Menus déroulants : exclusifs + « Tester une vue » court et scrollable */
q("UI.viewMenu=false; UI.bellOpen=false; UI.userMenu=false; toggleBell();");
const bellOuvreFermeVues = q("UI.bellOpen") === true && q("UI.viewMenu") === false;
q("toggleViewMenu();");
const vuesFermeCloche = q("UI.viewMenu") === true && q("UI.bellOpen") === false;
q("toggleUserMenu();");
const profilFermeVues = q("UI.userMenu") === true && q("UI.viewMenu") === false;
const cssDD = fs.readFileSync('style.css', 'utf8');
log('22. Cloche/profil/vues exclusifs (jamais superposés) ; menu de vues scrollable (en-tête fixe)',
  bellOuvreFermeVues && vuesFermeCloche && profilFermeVues &&
  cssDD.includes('.dd-menu.view-dd{max-height:min(252px,70vh);overflow-y:auto}'));

done('SMOKE56');
