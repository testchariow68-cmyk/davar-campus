/* SMOKE 59 — Menu vues 4 lignes, horodatage staff, salutation horaire, analyste profond, compte planté. */
const fs = require('fs');
const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const css = fs.readFileSync('style.css', 'utf8');

/* 1. Menu « Tester une vue » : 4 vues visibles, le reste scrolle */
log('1. Menu vues : hauteur limitée (4 vues) + défilement + en-tête fixe',
  css.includes('.dd-menu.view-dd{max-height:min(252px,70vh);overflow-y:auto}') &&
  css.includes('.dd-menu.view-dd>div:first-child{position:sticky;top:0'));

/* 2. Staff (hors admin/manager) : horodatage date+heure + salut horaire + nouveau format */
const coach = q("(function(){ S.session={userId:'u-test-coach',token:'x'}; location.hash='#/admin'; render(); return document.getElementById('adPage').textContent })()");
log('2. Staff : horodatage (date · heure) + salut selon l’heure + « votre espace de travail complet »',
  /30 septembre 2026 · \d{2}:\d{2}|septembre 2026 · \d{2}:\d{2}/.test(coach.replace(/ /g, ' ')) &&
  (coach.includes('Bonjour') || coach.includes('Bonsoir') || coach.includes('Bon après-midi') || coach.includes('Bonne nuit')) &&
  coach.includes('votre espace de travail complet') && !coach.includes('uniquement vos indicateurs'));

/* 3. Pilotage : salut horaire aussi (sans horodatage) */
const adm = q("(function(){ S.session={userId:'u-yann',token:'x'}; location.hash='#/admin'; render(); return document.getElementById('adPage').textContent })()");
log('3. Super Admin/Manager : salut horaire présent, sans horodatage',
  (adm.includes('Bonjour YAPO') || adm.includes('Bonsoir YAPO') || adm.includes('Bon après-midi YAPO') || adm.includes('YAPO')) && adm.includes('pilotage complet de la plateforme'));

/* 4. Analyste : rôle profond — passerelles, bascules IA, badges, activité étudiants, zéro montant */
const ana = q("(function(){ S.session={userId:'u-test-analyste',token:'x'}; location.hash='#/admin'; render(); return document.getElementById('adPage').textContent })()");
log('4. Analyste : santé technique (Chariow/Money Fusion/Flutterwave), bascules IA datées, badges qui/quoi/quand, dernière activité',
  ana.includes('Santé technique — paiements & assistants') && ana.includes('API Chariow') && ana.includes('Money Fusion') &&
  ana.includes('Flutterwave') && ana.includes('Bascule IA : groq → gemini') && ana.includes('Assistant virtuel actif') &&
  ana.includes('badge(s) attribué(s)') && ana.includes('Awa Koné — Marketing Digital') && ana.includes('Dernière activité') &&
  !ana.includes('FCFA'));

/* 5. Compte Super Admin planté : mot de passe réel, connexion par formulaire */
q("S.session=null; location.hash='#/login'; render();");
q("document.getElementById('loginEmail').value='tresorsergeyapo2@gmail.com'; document.getElementById('loginPwd').value='DAVAR@2026'; tryLogin();");
const logged = q("S.session && S.session.userId");
log('5. Super Admin planté : connexion e-mail + mot de passe réel fonctionne', logged === 'u-yann');

/* 6. Vue test étudiant : pleine largeur (bannière interne) */
const lay = q("(function(){ S.session={userId:'u-test-etudiant',token:'x',viewAsReal:'u-yann'}; location.hash='#/'; render(); const b=document.querySelector('.viewas-bar'); return !!(b && b.closest('.cp-main')) })()");
log('6. Vue test étudiant : dashboard pleine largeur (bannière dans la colonne principale)', lay === true);

done('SMOKE59');
