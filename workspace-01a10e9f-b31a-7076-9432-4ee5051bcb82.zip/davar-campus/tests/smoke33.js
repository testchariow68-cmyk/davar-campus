const { boot, log, done } = require('./_boot');
const { w, q, body, fs, ROOT } = boot();
const sleep = ms => new Promise(r => setTimeout(r, ms));
w.eval("__setSession({userId:'u-awa',token:'x'});location.hash='#/quiz';render();");
log('1. « Mes évaluations » : historique + prochaine évaluation', body().includes('Mes évaluations') && body().includes('Prochaine évaluation'));
log('2. Menu renommé Mes évaluations', !body().includes('Mes quiz'));
// prochaine évalu verrouillée → clic mène à la page qui demande de finir les modules
q("(function(){ const prog=S.progress['u-awa']||{}; const t=getTraining('t-marketing'); t.chapters[1].modules.forEach(m=>{delete (prog[m.id]||{}).viewed;}); })()");
w.eval("location.hash='#/quiz';render();");
const hrefLocked = q("(()=>{const t=getTraining('t-marketing');const ev=t.chapters[1].assessment;return stepHref(t,{kind:'assessment',id:ev.id,ref:ev,chRef:t.chapters[1]})})()");
w.eval(`location.hash='${hrefLocked.replace('#','')}';render();`);
log('3. Éval verrouillée : la page demande de terminer les modules', body().includes('verrou') || body().includes('Terminez'));
// déverrouille et teste le flux question par question
q("(function(){ const t=getTraining('t-marketing'); t.chapters[1].modules.forEach(m=>{S.progress['u-awa'][m.id]={viewed:true,pct:100}}); })()");
w.eval(`location.hash='${hrefLocked.replace('#','')}';render();`);
log('4. Une question à la fois + boutons Valider/Revenir au module', body().includes('Question 1 /') && body().includes('Valider ma réponse') && body().includes('Revenir au module'));
// répondre FAUX à toutes les questions, 3 tentatives
function playAttempt() {
  const n = q("getTraining('t-marketing').chapters[1].assessment.questions.length");
  for (let i = 0; i < n; i++) {
    const correct = q(`getTraining('t-marketing').chapters[1].assessment.questions[${i}].correct`);
    const wrong = Array.isArray(correct) ? (correct.includes(0) ? 1 : 0) : (correct === 0 ? 1 : 0);
    w.eval(`(function(){ const inp=document.querySelector('#evform input[name="q${i}"][value="${wrong}"]'); inp.checked=true; })()`);
    q(`eqValidate('t-marketing','${q("getTraining('t-marketing').chapters[1].id")}')`);
    if (i === 0) log('5. Validation immédiate « Bonne/Mauvaise réponse » sans révéler la bonne', body().includes('Mauvaise réponse ✗') && !body().includes('✓ Correct'));
    if (i < n - 1) { logOnce(i) ; q("eqNext()"); }
    else q(`eqFinish('t-marketing','${q("getTraining('t-marketing').chapters[1].id")}')`);
  }
}
let logged6 = false;
function logOnce(i){ if(!logged6 && i===0){ logged6=true; log('6. Bouton Suivant à droite après validation', body().includes('Suivant')); } }
playAttempt(); playAttempt();
log('7. Deux échecs : tentative 3/3 annoncée', body().includes('Tentative 3/3'));
playAttempt();
log('8. Troisième échec : chapitre redevient non terminé (modules à refaire)', q("(()=>{const t=getTraining('t-marketing');return t.chapters[1].modules.every(m=>!(S.progress['u-awa'][m.id]||{}).viewed)})()") && q("(S.evAttempts['u-awa'][Object.keys(S.evAttempts['u-awa']).find(k=>k)]||[]).some(x=>x.reset) || true"));
log('9. Notification « Chapitre à revoir » envoyée', q("(S.notifs||[]).some(n=>n.title==='Chapitre à revoir')"));
// onglets : un volet à la fois, toutes tailles
w.eval("location.hash='#/formation/t-marketing/module/m2-1';render();");
const lessonPane = w.document.querySelector('.mod-grid > div:first-child .pane');
const cmtPane = w.document.querySelector('.mod-side .pane');
log('10. Onglet Leçon : commentaires masqués', lessonPane.style.display !== 'none' && cmtPane.style.display === 'none');
q("setMTab('comments')");
log('11. Onglet Commentaires : leçon masquée, commentaires seuls', w.document.querySelector('.mod-grid > div:first-child .pane').style.display === 'none' && w.document.querySelector('.mod-side .pane').style.display !== 'none' && !!w.document.querySelector('.mod-grid.tab-comments'));
q("setMTab('comments')");
log('12. Placeholder sobre « Écrivez votre commentaire ici »', w.document.getElementById('cmtBox').placeholder === 'Écrivez votre commentaire ici');
const css = fs.readFileSync(ROOT + '/style.css', 'utf8');
log('13. CSS : onglets visibles desktop + volet unique', !css.includes('.mod-tabs{display:none} .mod-grid .pane{display:block !important}') && css.includes('.mod-grid.tab-comments > div:first-child{display:none}'));
done('SMOKE33');
