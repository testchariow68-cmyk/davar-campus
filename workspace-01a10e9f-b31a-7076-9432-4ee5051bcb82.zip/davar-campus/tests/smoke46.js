const { boot, log, done } = require('./_boot');
const { w, q } = boot();
const DAY = 86400000;
(async () => {
/* ---------- A. Règles de purge : la durée du compte (12 mois) y est comprise ---------- */
q("S.users.push({id:'u-t1',role:'student',name:'T1',email:'t1@davarcampus.co'})");
q("S.enrollments.push({userId:'u-t1',trainingId:'t-excel',at:Date.now()-400*" + DAY + "})"); /* accès expiré, non terminé */
q("S.users.push({id:'u-t2',role:'student',name:'T2',email:'t2@davarcampus.co'})");
q("S.enrollments.push({userId:'u-t2',trainingId:'t-excel',at:Date.now()-300*" + DAY + "})"); /* accès encore valide */
q("S.users.push({id:'u-t3',role:'student',name:'T3',email:'t3@davarcampus.co'})");
q("S.enrollments.push({userId:'u-t3',trainingId:'t-excel',at:Date.now()-400*" + DAY + ",completedAt:Date.now()-390*" + DAY + "})");
log('1. Accès 12 mois : achat de 300 j = service en cours ; 400 j = accès expiré',
  q("lcEntitlementInfo('u-t2').activeEnrollment") === true && q("lcEntitlementInfo('u-t1').activeEnrollment") === false);
q("S.purgePending=[];lcAccountLifecycle()");
log('2. Purge : accès expiré sans nouvelle acquisition → quarantaine (comme un terminé)',
  q("S.purgePending.some(p=>p.userId==='u-t1')") === true && q("S.purgePending.some(p=>p.userId==='u-t3')") === true);
log('3. Purge : accès encore valide → PAS de quarantaine', q("S.purgePending.some(p=>p.userId==='u-t2')") === false);
log('4. Matrice affichée : la durée du compte figure dans les règles', q("LIFECYCLE.classes.some(c=>c[0].includes('Accès formation acheté'))") === true);

/* ---------- B. Sécurité phase 1 : couches 1, 5, 7 + fenêtre éphémère ---------- */
const L1 = await import('../security/workers/layer1-zero-trust.mjs');
const L5 = await import('../security/workers/layer5-ssi.mjs');
const L7 = await import('../security/workers/layer7-botdetection.mjs');
const EW = await import('../security/workers/ephemeral-window.mjs');
const now = Date.now();
const mk = (exp, dom) => ({ exp: Math.floor((now + exp) / 1000), aud: 'app-a', type: 'app', email: 'yann@' + dom, sub: 'u-yann' });
log('5. Couche 1 : JWT expiré rejeté, domaine hors liste rejeté, valide accepté',
  L1.checkAccessClaims(mk(-1000, 'davarcampus.co'), { now, audience: 'app-a', allowedDomains: ['davarcampus.co'] }).ok === false &&
  L1.checkAccessClaims(mk(60000, 'gmail.com'), { now, audience: 'app-a', allowedDomains: ['davarcampus.co'] }).ok === false &&
  L1.checkAccessClaims(mk(60000, 'davarcampus.co'), { now, audience: 'app-a', allowedDomains: ['davarcampus.co'] }).ok === true);
const bot = Array.from({ length: 20 }, (_, i) => ({ t: i * 16, x: i * 10, y: 0, p: 0.5 }));       /* cadence parfaite, ligne droite */
const hum = Array.from({ length: 20 }, (_, i) => ({ t: i * 17 + (i % 3) * 7, x: i * 9 + (i % 4), y: Math.sin(i) * 3, p: 0.4 + (i % 5) / 20 }));
log('6. Couche 7 : automate détecté, humain accepté', L7.scoreTelemetry(bot).verdict === 'bot' && L7.scoreTelemetry(hum).verdict === 'human');
/* Ed25519 via node:crypto (adaptateur injecté, comme en production via WebCrypto) */
const c = require('crypto');
const kp = c.generateKeyPairSync('ed25519');
const pubB64 = kp.publicKey.export({ type: 'spki', format: 'der' }).slice(-32).toString('base64');
const fromRaw = b64 => c.createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), Buffer.from(b64, 'base64')]), format: 'der', type: 'spki' });
const ed = { sign: async d => new Uint8Array(c.sign(null, Buffer.from(d), kp.privateKey)), verify: async (b64, d, s) => c.verify(null, Buffer.from(d), fromRaw(b64), Buffer.from(s)) };
const did = L5.didFromPublicKey(pubB64);
const doc = await L5.issueCredential(ed, did, 'did:davar:u-awa', { role: 'student' });
const vOk = await L5.verifyCredential(doc, ed);
const tampered = JSON.parse(JSON.stringify(doc)); tampered.vc.credentialSubject.role = 'admin';
const vKo = await L5.verifyCredential(tampered, ed);
log('7. Couche 5 : credential vérifié, credential falsifié rejeté', vOk.ok === true && vKo.ok === false);
let t0 = now;
const win = new EW.EphemeralWindow({ verify: ed.verify, log: () => {}, now: () => t0 });
const sig = await ed.sign('n-123|' + t0);
const o1 = await win.open({ nonce: 'n-123', ts: t0, signature: sig }, pubB64);
const replay = await win.open({ nonce: 'n-123', ts: t0, signature: sig }, pubB64);
const act = win.authorize('purge_controle');
t0 += 6 * 60 * 1000;
const late = win.authorize('export');
log('8. Fenêtre éphémère : ouverture signée OK, anti-rejeu, action OK, expirée après 5 min', o1.ok === true && replay.ok === false && act.ok === true && late.ok === false);
done('SMOKE46');
})();
