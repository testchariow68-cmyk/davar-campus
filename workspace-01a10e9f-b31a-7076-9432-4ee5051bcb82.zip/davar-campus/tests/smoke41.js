const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
w.eval("__setSession({userId:'u-awa',token:'x'});");
// 1) vidéo principale 9:16 → cadre 9:16, contrôles dedans
w.eval("location.hash='#/formation/t-marketing/module/m2-1';render();");
log('1. Principale 9:16 : le cadre entier est vertical', !!w.document.querySelector('.card.fit-916') && w.document.getElementById('playerBox').classList.contains('r-916'));
log('2. Réglages + plein écran adaptés dans le cadre étroit', !!w.document.querySelector('.card.fit-916 .player-ui') && !!w.document.querySelector('.card.fit-916 .p-row'));
// 2) 16:9 → cadre large, rien de dur
w.eval("location.hash='#/formation/t-marketing/module/m1-1';render();");
log('3. Principale 16:9 : cadre large, aucune forme imposée', !w.document.querySelector('.card.fit-916') && !w.document.querySelector('.card.fit-43') && !w.document.querySelector('.card.fit-11'));
// 3) 4:3 puis 1:1 → le cadre suit
q("getTraining('t-marketing').chapters[0].modules[0].ratio='4:3';render();");
log('4. Principale 4:3 : cadre 4:3', !!w.document.querySelector('.card.fit-43'));
q("getTraining('t-marketing').chapters[0].modules[0].ratio='1:1';render();");
log('5. Principale 1:1 : cadre carré', !!w.document.querySelector('.card.fit-11'));
// 4) complémentaire d'un autre format → le cadre élastique change de forme
q("getTraining('t-marketing').chapters[0].modules[0].ratio='16:9';getTraining('t-marketing').chapters[0].modules[0].extraVideos=[{title:'Verticale',duration:'1:00',ratio:'9:16',url:'https://youtu.be/qqqqqqqqqqq'}];render();");
q("playExtra(0)");
log('6. Complémentaire 9:16 sur principale 16:9 : le cadre épouse la complémentaire', !!w.document.querySelector('.card.fit-916'));
q("backToMain()");
log('7. Retour : le cadre reprend la forme de la principale', !w.document.querySelector('.card.fit-916'));
done('SMOKE41');
