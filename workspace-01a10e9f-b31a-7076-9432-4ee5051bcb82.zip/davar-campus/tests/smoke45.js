const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const sleep = ms => new Promise(r => setTimeout(r, ms));
const TINY = '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AVN//2Q==';
(async () => {
w.eval("__setSession({userId:'u-awa',token:'x'});");
// 1. payMethodLabel : jamais le nom de passerelle
log('1. payMethodLabel : Wave / Carte bancaire, jamais la passerelle',
  q("payMethodLabel({method:'Money Fusion · Wave'})") === 'Wave' &&
  q("payMethodLabel({method:'Chariow'})") === 'Carte bancaire' &&
  q("payMethodLabel(null)") === 'Carte bancaire');
// 2. achat confirmé (Mobile Money) pour la facture
q("S.settings.flutterwave.enabled=false;location.hash='#/checkout/t-anglais';render();CHECKOUT.step=2;CHECKOUT.method='wave';render();payViaMoneyFusion('t-anglais')");
await sleep(2600);
const sale = q("S.sales.find(x=>x.userId==='u-awa'&&x.trainingId==='t-anglais'&&x.status==='confirmé')") ? true : false;
log('2. Achat Mobile Money confirmé + écran succès sans passerelle', sale && body().includes('confirmé par Wave') && !body().includes('Money Fusion'));
// 3. Facture texte (repli sans canvas) : mentions comptables + moyen de paiement
q("window.__origGet=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(){return null};window.__pdf=null;makeInvoicePDF(invoiceMeta(getUser('u-awa'),getTraining('t-anglais'),S.sales.find(x=>x.userId==='u-awa'&&x.trainingId==='t-anglais'&&x.status==='confirmé'))).then(u=>window.__pdf=u)");
await sleep(400);
const pdf = w.__pdf || '';
const dec = q("decodeURIComponent(escape(atob('" + pdf.split(',')[1] + "')))");
log('3. Facture = PDF valide avec Yopougon, Support, acquittée, Wave', pdf.startsWith('data:application/pdf;base64,') && dec.startsWith('%PDF-1.4') && dec.includes('Yopougon') && dec.includes('Support') && dec.includes('acces 12 mois') && dec.includes('FACTURE ACQUITTEE') && dec.includes('Wave'));
log('4. Facture : AUCUN nom de passerelle', !dec.includes('Money Fusion') && !dec.includes('Chariow'));
// 5. Chemin canvas A4 : image JPEG embarquée (vrai canvas si dispo, sinon stub)
q("HTMLCanvasElement.prototype.getContext=window.__origGet||function(){return window.__stub};window.__stub={fillStyle:'',font:'',textAlign:'',fillRect:function(){},fillText:function(){},drawImage:function(){},clearRect:function(){}};" +
  "HTMLCanvasElement.prototype.getContext=function(){return window.__stub};" +
  "HTMLCanvasElement.prototype.toDataURL=function(){return 'data:image/jpeg;base64," + TINY + "'};" +
  "window.__pdf2=null;makeInvoicePDF(invoiceMeta(getUser('u-awa'),getTraining('t-anglais'),S.sales.find(x=>x.userId==='u-awa'&&x.trainingId==='t-anglais'&&x.status==='confirmé'))).then(u=>window.__pdf2=u)");
await sleep(1200);
const pdf2 = w.__pdf2 || '';
const dec2 = q("atob('" + pdf2.split(',')[1] + "')");
log('5. Facture pro (canvas A4) : PDF avec image JPEG /DCTDecode embarquée', pdf2.startsWith('data:application/pdf;base64,') && dec2.startsWith('%PDF-1.4') && dec2.includes('/DCTDecode') && dec2.includes('%%EOF'));
// 6. Zéro info technique côté étudiant, TOUTES les pages rendues
const routes = ['#/', '#/catalogue', '#/formation/t-marketing', '#/parametres', '#/checkout/t-anglais'];
let all = '';
for (const r of routes) { q("location.hash='" + r + "';render();"); all += body() + ' '; }
q("render();CHECKOUT.step=2;CHECKOUT.method='wave';render();"); all += body() + ' ';
q("closeModal();");
const leaks = ['Chariow', 'Money Fusion', 'webhook', 'Webhook', 'Turso', 'stockage R2', 'Pulse', 'MF_RATE', 'chariow'].filter(t => all.toLowerCase().includes(t.toLowerCase()));
log('6. Dashboard étudiant : AUCUNE fuite technique sur toutes les pages (' + (leaks.length ? leaks.join(',') : 'aucune') + ')', leaks.length === 0);
// 7. Bouton de téléchargement facture présent, certificat toujours non téléchargeable
q("location.hash='#/checkout/t-anglais';render();CHECKOUT.step=3;render();");
log('7. Écran succès : bouton « Facture PDF » (téléchargement in-app)', body().includes('Facture PDF'));
done('SMOKE45');
})();
