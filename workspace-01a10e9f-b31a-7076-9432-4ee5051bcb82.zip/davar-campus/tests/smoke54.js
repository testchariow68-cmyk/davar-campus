const { boot, log, done } = require('./_boot');
const { w, q } = boot();

/* 1. Défaut = voie universelle : tous les achats dans l'app passent par Flutterwave */
log('1. Flutterwave universel par défaut — tous les achats dans l’app',
  q(`fwEnabled()`) === true && q(`S.settings.flutterwave.mode`) === 'all' &&
  q(`fwHandles('chariow')`) === true && q(`fwHandles('moneyfusion')`) === true);

/* 1b. Achat universel : « Obtenir » ouvre directement le paiement Flutterwave */
q(`__setSession({ userId: 'u-awa', role: 'student' })`);
const tidFb = q(`['t-orateur','t-anglais','t-entreprendre'].find(x => !enrolledIn('u-awa', x))`);
q(`startPurchase('${tidFb}')`);
const fwModal = w.document.body.textContent.includes('Paiement sécurisé Flutterwave');
q(`closeModal(); S.fwPayments.pop();`);
log('1b. Achat dans l’app → paiement Flutterwave (universel, quel que soit le pays)', fwModal);

/* 1c. Mode « alternative » : les boutons sont proposés dans Chariow + le checkout Money Fusion */
q(`S.settings.flutterwave.mode = 'fallback'`);
q(`openChariow('t-marketing')`);
const modalOk = w.document.body.textContent.includes('Alternative : Flutterwave');
q(`closeModal()`);
q(`CHECKOUT.tid = '${tidFb}'; CHECKOUT.step = 2; CHECKOUT.method = 'wave'`);
const ckOk = q(`vCheckout(getUser('u-awa'), '${tidFb}')`).includes('Ou payer via Flutterwave');
q(`S.settings.flutterwave.mode = 'all'`);
log('1c. Mode alternative : boutons dans la modale Chariow + le checkout Money Fusion', modalOk && ckOk);

/* 2. Les 3 modes routent correctement */
q(`S.settings.flutterwave.enabled = true`);
q(`S.settings.flutterwave.mode = 'cards'`);
const cardsOk = q(`fwHandles('chariow')`) === true && q(`fwHandles('moneyfusion')`) === false;
q(`S.settings.flutterwave.mode = 'all'`);
const allOk = q(`fwHandles('chariow')`) === true && q(`fwHandles('moneyfusion')`) === true;
q(`S.settings.flutterwave.mode = 'fallback'`);
const fbOk = q(`fwHandles('chariow')`) === false && q(`fwHandles('moneyfusion')`) === false;
log('2. Modes : cards = remplace Chariow, all = tout, fallback = simple alternative', cardsOk && allOk && fbOk);

(async () => {
/* 3. Worker : verifi-hash à temps constant, filtre charge.completed, clé de dédoublonnage */
const FW = await import('../security/workers/flutterwave-webhook.mjs');
const okHash = FW.verifyHash('SECRET-1', 'SECRET-1') === true && FW.verifyHash('SECRET-1', 'WRONG') === false && FW.verifyHash('', null) === false && FW.verifyHash('SECRET-1', 'SECRET-2') === false;
const okEv = (FW.payableData({ event: 'charge.completed', data: { status: 'successful', id: 7 } }) || {}).id === 7 &&
  FW.payableData({ event: 'charge.completed', data: { status: 'failed' } }) === null &&
  FW.payableData({ event: 'charge.failed', data: { status: 'successful' } }) === null;
const okKey = FW.dedupeKey({ id: 42 }) === '42' && FW.dedupeKey({ flw_ref: 'FLW-X' }) === 'FLW-X';
log('3. Worker : verifi-hash, filtre événement payable, clé de dédoublonnage', okHash && okEv && okKey);

/* 4. Bout en bout : initiation → webhook → formation débloquée + vente « Flutterwave » + e-mail support@ */
q(`S.settings.flutterwave.mode = 'all'`);
q(`__setSession({ userId: 'u-awa', role: 'student' })`);
const tid = q(`['t-orateur','t-anglais','t-excel','t-entreprendre'].find(x => !enrolledIn('u-awa', x))`);
const salesBefore = q(`S.sales.filter(s => s.userId === 'u-awa' && s.trainingId === '${tid}').length`);
q(`fwCreatePayment(getUser('u-awa'), getTraining('${tid}'), 'DAV-TEST-1')`);
q(`simulateFlutterwaveWebhook('${tid}')`);
const unlocked = q(`enrolledIn('u-awa', '${tid}')`) === true;
const sale = JSON.parse(q(`JSON.stringify(S.sales.find(s => s.userId === 'u-awa' && s.trainingId === '${tid}' && s.status === 'confirmé') || null)`));
const saleOk = !!sale && sale.method.indexOf('Flutterwave') === 0 && sale.txn.indexOf('FLW-') === 0;
const mail = JSON.parse(q(`JSON.stringify(S.auditLog.find(a => a.action === 'mail' && a.payload && a.payload.flow === 'purchase_ok') || null)`));
const mailOk = !!mail && mail.payload.from === 'support@davarcampus.co';
log('4. Achat Flutterwave : déblocage + vente + e-mail de confirmation support@', unlocked && saleOk && mailOk);

/* 5. Dédoublonnage : 2ᵉ webhook sur le même tx_ref ne crédite pas deux fois */
q(`fwWebhook({ event: 'charge.completed', data: { id: (S.fwPayments.find(p => p.tx_ref === 'DAV-TEST-1') || {}).id, tx_ref: 'DAV-TEST-1', flw_ref: 'FLW-DUP', status: 'successful', amount: 1000, currency: 'XOF' } }, { 'verifi-hash': 'DEMO-SECRET' })`);
const salesAfter = q(`S.sales.filter(s => s.userId === 'u-awa' && s.trainingId === '${tid}').length`);
log('5. Dédoublonnage tx_ref : 2ᵉ webhook = aucun double crédit', salesAfter === salesBefore + 1);

/* 6. verifi-hash invalide : rejet audité, aucun crédit */
q(`fwWebhook({ event: 'charge.completed', data: { id: 999999, tx_ref: 'DAV-TEST-1', flw_ref: 'FLW-PIRATE', status: 'successful', amount: 1000, currency: 'XOF' } }, { 'verifi-hash': 'MAUVAIS' })`);
const salesPirate = q(`S.sales.filter(s => s.userId === 'u-awa' && s.trainingId === '${tid}').length`);
const rejected = q(`S.auditLog.some(a => a.action === 'flutterwave_webhook' && a.payload && a.payload.rejected)`) === true;
log('6. verifi-hash invalide rejeté (audité), aucun crédit', salesPirate === salesBefore + 1 && rejected);

/* 7. La facture reste lisible : le client ne voit jamais la passerelle */
const lbl = q(`payMethodLabel({ method: 'Flutterwave · Mobile Money' }) + '|' + payMethodLabel({ method: 'Flutterwave · Carte' })`);
log('7. Facture : « Mobile Money » / « Carte bancaire » — passerelle invisible', lbl === 'Mobile Money|Carte bancaire');

done('SMOKE54');
})();
