const { log, done } = require('./_boot');
const fs = require('fs');
const ROOT = '/home/user/davar-campus';
const SITE = '/home/user/site';

const vit = fs.readFileSync(SITE + '/index.html', 'utf8');    /* site vitrine (domaine propre) */
const app = fs.readFileSync(ROOT + '/index.html', 'utf8');    /* application web (domaine propre) */
const CHARIOW_ORA = 'https://d-ueo.mychariow.co/prd_6wx1czzp/checkout'; /* « Devenir un excellent orateur » */

/* --- SITE VITRINE : référencement + achat Chariow, AUCUN accès à l'app --- */
log('1. Vitrine : titre + description + mots-clés art oratoire', vit.includes('<title>Davar Académie') && (vit.match(/name="description" content="([^"]+)"/) || [])[1]?.includes('art oratoire') && vit.includes('prise de parole en public'));
log('2. Vitrine : AUCUN lien vers l’application (plateforme privée)', !vit.includes('#/login') && !vit.includes('#/inscription') && !vit.includes('/app/') && !vit.includes('Se connecter'));
log('3. Vitrine : boutons d’achat → checkout Chariow de « Devenir un excellent orateur »', (vit.match(new RegExp(CHARIOW_ORA.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length >= 3 && vit.includes('Devenir un excellent orateur'));
log('4. Vitrine : SEO complet (canonical placeholder + JSON-LD + OG + prix de la formation)', vit.includes('rel="canonical" href="https://davar-academie.pages.dev/"') && vit.includes('"@type": "EducationalOrganization"') && vit.includes('"price": "45000"') && vit.includes('property="og:url"'));
log('5. Vitrine : explique l’accès par e-mail après paiement (Chariow gère)', vit.includes('par e-mail') && vit.includes('plateforme privée'));

/* --- APPLICATION : telle qu'elle était, rien de mélangé --- */
log('6. App intacte : SEO d’origine (index,follow + canonical davarcampus.co + JSON-LD)', app.includes('name="robots" content="index, follow"') && app.includes('rel="canonical" href="https://davarcampus.co/"') && app.includes('"@type": "EducationalOrganization"'));
log('7. App intacte : landing statique + retrait au rendu + robots/sitemap racine', app.includes('id="seo-landing"') && fs.readFileSync(ROOT + '/js/app.js', 'utf8').includes("getElementById('seo-landing')") && fs.existsSync(ROOT + '/robots.txt') && fs.readFileSync(ROOT + '/sitemap.xml', 'utf8').includes('davarcampus.co'));
log('8. App intacte : liens internes (aucun /app/), e-mails et paiements d’origine', !app.includes('davarcampus.co/app') && !fs.readFileSync(ROOT + '/js/emails.js', 'utf8').includes('MAIL_APP') && !fs.readFileSync(ROOT + '/js/views-student.js', 'utf8').includes('davarcampus.co/app/'));

done('SMOKE52');
