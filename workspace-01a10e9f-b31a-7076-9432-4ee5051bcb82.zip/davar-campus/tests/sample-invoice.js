/* Génère un vrai exemplaire de facture avec le code RÉEL de l'app (canvas + logos) */
const { JSDOM, VirtualConsole } = require('/home/user/node_modules/jsdom');
const fs = require('fs');
const ROOT = '/home/user/davar-campus';
const vc = new VirtualConsole(); /* silencieux */
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
const dom = new JSDOM(fs.readFileSync(ROOT + '/index.html', 'utf8'), {
  url: 'file://' + ROOT + '/index.html', runScripts: 'outside-only', pretendToBeVisual: true, resources: 'usable', virtualConsole: vc
});
const w = dom.window; w.scrollTo = () => {}; w.URL.createObjectURL = () => 'blob:x';
const files = ['js/icons.js','js/data.js','js/ui.js','js/lifecycle.js','js/views-student.js','js/rewards.js','js/views-campus.js','js/views-admin.js','js/app.js'];
w.eval(files.map(f => fs.readFileSync(ROOT + '/' + f, 'utf8')).join('\n;\n') + `\n;window.__q=expr=>eval(expr);window.__setSession=u=>{S.session=u};`);
const q = e => w.eval(`__q(${JSON.stringify(e)})`);
w.eval("__setSession({userId:'u-awa',token:'x'});");
/* achat réel Mobile Money (Wave) */
q("location.hash='#/checkout/t-anglais';render();CHECKOUT.step=2;CHECKOUT.method='wave';render();payViaMoneyFusion('t-anglais')");
await sleep(3000);
const saleId = q("S.sales.find(x=>x.userId==='u-awa'&&x.trainingId==='t-anglais'&&x.status==='confirmé').id");
console.log('vente confirmée :', saleId, '| méthode brute :', q("S.sales.find(x=>x.id==='" + saleId + "').method"), '| facture affichera :', q("payMethodLabel(S.sales.find(x=>x.id==='" + saleId + "'))"));
q("window.__pdf=null;makeInvoicePDF(invoiceMeta(getUser('u-awa'),getTraining('t-anglais'),S.sales.find(x=>x.id==='" + saleId + "'))).then(u=>window.__pdf=u).catch(e=>window.__pdf='ERR:'+e)");
await sleep(2500);
const pdf = w.__pdf;
if (!pdf || !String(pdf).startsWith('data:application/pdf')) { console.log('ECHEC :', String(pdf).slice(0, 300)); process.exit(1); }
const buf = Buffer.from(pdf.split(',')[1], 'base64');
fs.writeFileSync('/home/user/facture-exemple.pdf', buf);
console.log('facture-exemple.pdf écrit :', buf.length, 'octets | %PDF :', buf.slice(0, 5).toString(), '| DCTDecode :', buf.includes(Buffer.from('/DCTDecode')));
process.exit(0);
})();
