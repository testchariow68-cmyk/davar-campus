const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  w.eval("__setSession({userId:'u-awa',token:'x'});location.hash='#/';render();");
  log('1. Menu : « Notifications » retiré (cloche reste en haut)', !body().includes('Activités de vos formations et du campus'));
  q("openLogoZoom()");
  log('2. Clic logo : overlay grand logo + croix', !!w.document.getElementById('logoZoom') && !!w.document.querySelector('#logoZoom .lz-x') && !!w.document.querySelector('#logoZoom .lz-card img'));
  q("closeLogoZoom()");
  log('3. Croix / clic extérieur : overlay retiré', !w.document.getElementById('logoZoom'));
  w.eval("location.hash='#/certificats';render();");
  log('4. Certificats : plus de téléchargement depuis la plateforme', !w.document.querySelector('.cert-dl'));
  w.eval("location.hash='#/questions';render();");
  log('5. Mes questions : liste des conversations (question + réponse)', body().includes('fréquence de publication') && body().includes('Répondu ✓') && body().includes('Poser une question'));
  const exCid = q("getTraining('t-marketing').chapters.find(ch=>ch.exercise).id");
  w.eval(`location.hash='#/formation/t-marketing/exercice/${exCid}';render();`);
  w.eval("(function(){ document.querySelectorAll('#exform input').forEach(inp=>inp.checked=true); })()");
  q(`submitExercise('t-marketing','${exCid}')`);
  log('6. Vérifier → animation de chargement', !!w.document.querySelector('.quiz-load'));
  await sleep(2200);
  log('7. Correction teintée, sans carte résultat, 2 boutons bas', !!w.document.querySelector('.corr') && !body().includes('Résultat :') && w.document.getElementById('quizActions').textContent.includes('Recommencer l’exercice') && w.document.getElementById('quizActions').textContent.includes('Continuer la formation'));
  const evCid = q("getTraining('t-marketing').chapters.find(ch=>ch.assessment&&ch.assessment.type==='quiz').id");
  q("(function(){ const t=getTraining('t-marketing'); const ch=t.chapters.find(c=>c.assessment&&c.assessment.type==='quiz'); S.progress['u-awa']=S.progress['u-awa']||{}; ch.modules.forEach(m=>{S.progress['u-awa'][m.id]={viewed:true,pct:100}}); })()");
  w.eval(`location.hash='#/formation/t-marketing/evaluation/${evCid}';render();`);
  const nq = q("getTraining('t-marketing').chapters.find(ch=>ch.assessment&&ch.assessment.type==='quiz').assessment.questions.length");
  for (let i = 0; i < nq; i++) {
    const correct = q(`getTraining('t-marketing').chapters.find(ch=>ch.assessment&&ch.assessment.type==='quiz').assessment.questions[${i}].correct`);
    const wrong = correct === 0 ? 1 : 0;
    w.eval(`(function(){ const inp=document.querySelector('#evform input[name="q${i}"][value="${wrong}"]'); if(inp) inp.checked=true; })()`);
    q(`eqValidate('t-marketing','${evCid}')`);
    if (i < nq - 1) q("eqNext()"); else q(`eqFinish('t-marketing','${evCid}')`);
  }
  log('7b. Évaluation : question par question, verdict sans révéler les bonnes réponses', q("(S.evAttempts['u-awa']||{})[Object.keys(S.evAttempts['u-awa'])[0]]") !== undefined);
  q("(function(){ const b=S.resources.find(r=>r.id==='bk-ora'); b.pdf='data:application/pdf;base64,JVBERi0xLjQ='; })()");
  w.eval("location.hash='#/livre/bk-ora';render();");
  log('8. Livre : PDF affiché tel quel (iframe)' , !!w.document.querySelector('.rd-pdf iframe'));
  // audios pistes
  q("(function(){ const a=S.resources.find(r=>r.id==='au-ora'); a.tracks=[{name:'Intro',url:'data:audio/mpeg;base64,//AAQ'},{name:'Séance',url:'data:audio/mpeg;base64,//AAQ'}]; a.cover='data:image/png;base64,iVBOR'; })()");
  w.eval("location.hash='#/audios';render();");
  log('9a. Audio (cartes) : aucune piste préchargée — quota protégé', w.document.querySelectorAll('audio').length === 0 && !!w.document.querySelector('.au-cover .au-ov'));
  q("openAudioList()");
  log('9. Audios : pistes réelles dans l’ordre + cover (liste de lecture)', w.document.querySelectorAll('.au-item audio').length === 2 && !!w.document.querySelector('.au-cover img') && body().includes('Piste 1 · Intro'));
  // support large
  q("openSupport(true)"); q("openReport()");
  log('10. Report depuis Paramètres : formulaire large', !!w.document.querySelector('.sup-pop.wide'));
  q("closeSupPop()"); q("openSupport()");
  log('11. Support depuis un module : taille normale', !!w.document.querySelector('.sup-pop') && !w.document.querySelector('.sup-pop.wide'));
  done('SMOKE30');
})();
