/* SMOKE 62 — Batch 67 : fondateur jamais étudiant · rien sans « Enregistrer » · export envoyer = 1 fichier généré, 1 envoi, mort en quittant la page. */
const { boot, log, done } = require('./_boot');
const { q } = boot();

/* 1. Test de vue : Super Admin toujours · Manager sur activation · jamais le fondateur ni une vraie personne */
const btnAdmin = q("(function(){ S.session={userId:'u-yann',token:'x'}; location.hash='#/admin'; render(); return document.body.innerHTML })()");
log('1. Super Admin : bouton « Tester une vue » présent (toutes les vues)', btnAdmin.includes('Tester une vue'));
const listTxt = q("viewAsList().map(x=>x.lbl).join('|')");
log('1b. Liste des vues : étudiant + staff, JAMAIS le fondateur', listTxt.includes('Vue Étudiant') && !listTxt.includes('YAPO') && !listTxt.includes('u-yann'));
q("toggleViewMenu(); viewAs('u-test-etudiant');");
const asStu = q("S.session.userId + '|' + S.session.viewAsReal");
log('1c. Le Super Admin peut tester la vue étudiant (compte test, pas lui-même)', asStu === 'u-test-etudiant|u-yann');
q("quitViewAs();");
const refusedReal = q("(function(){ viewAs('u-awa'); return S.session.userId })()");
log('1d. Une vraie personne (Awa) est refusée — comptes test uniquement', refusedReal === 'u-yann');
const btnMgr0 = q("(function(){ S.settings.managerViewAs=false; S.session={userId:'u-test-manager',token:'x'}; location.hash='#/admin'; render(); return document.body.innerHTML.includes('Tester une vue') })()");
log('1e. Manager : pas de test de vue par défaut', btnMgr0 === false);
const blocked = q("(function(){ viewAs('u-test-coach'); return S.session.userId })()");
log('1f. Même forcé, le Manager sans activation est refusé', blocked === 'u-test-manager');
q("S.settings.managerViewAs=true; render();");
const btnMgr1 = q("document.body.innerHTML.includes('Tester une vue')");
q("viewAs('u-test-coach');");
const mgrOK = q("S.session.userId + '|' + S.session.viewAsReal");
q("quitViewAs(); S.settings.managerViewAs=false; save();");
log('1g. Activation en Configuration : le Manager voit toutes les vues SAUF le fondateur', btnMgr1 === true && mgrOK === 'u-test-coach|u-test-manager' && !listTxt.includes('YAPO'));

/* 2. Palette : RIEN sans « Enregistrer » */
q("S.session={userId:'u-yann',token:'x'}; location.hash='#/admin/parametres'; render();");
const p0 = q("String(S.palette)");
const a0 = q("String(document.documentElement.getAttribute('data-palette'))");
q("selectPal('ocean');");
const afterSel = q("String(S.palette) + '|' + String(document.documentElement.getAttribute('data-palette'))");
log('2. Palette sélectionnée mais NI appliquée NI sauvegardée avant « Enregistrer »', afterSel === p0 + '|' + a0);
const marked = q("document.body.textContent.includes('sélectionnée — non enregistrée')");
log('2b. La carte indique « sélectionnée — non enregistrée »', marked === true);
q("saveSettingsAll();");
const afterSave = q("S.palette + '|' + document.documentElement.getAttribute('data-palette')");
log('2c. « Enregistrer » applique et sauvegarde vraiment', afterSave === 'ocean|ocean');
/* Palette personnalisée : brouillon jusqu’à Enregistrer */
q("selectPal('custom'); const ins=document.querySelectorAll('.pal-picker input[type=\"color\"]'); ins[0].value='#123456'; savePalCustom();");
const customDraft = q("S.palette + '|' + JSON.stringify(S.paletteCustom || null)");
log('2d. Couleurs personnalisées : rien tant que « Enregistrer » n’est pas pressé', customDraft.startsWith('ocean'));
q("saveSettingsAll();");
const customSaved = q("S.palette + '|' + (S.paletteCustom || {}).p");
log('2e. « Enregistrer » applique la palette composée', customSaved === 'custom|#123456');
/* Quitter la page Configuration efface le brouillon */
q("selectPal('foret'); location.hash='#/admin'; render();");
const draftGone = q("PAL_DRAFT === null && S.palette");
log('2f. Quitter Configuration efface le brouillon (palette inchangée)', draftGone === 'custom');

/* 3. Exports : envoyer exige un fichier généré — une fois — et meurt en quittant la page */
q("location.hash='#/admin/exports'; render();");
const disabled0 = q("document.body.innerHTML.includes('disabled') && document.body.innerHTML.includes('Envoyer le CSV par e-mail')");
log('3. Bouton « Envoyer » désactivé tant qu’aucun fichier n’est généré', disabled0 === true);
const refused = q("(function(){ mailExport(); return EXPORT_READY === null })()");
log('3b. Envoi refusé sans fichier généré', refused === true);
q("document.getElementById('exData').value='etudiants'; document.getElementById('exPwd').value='DAVAR@2026'; runExport();");
const ready = q("EXPORT_READY !== null && !document.querySelector('[onclick=\"mailExport()\"]').disabled");
log('3c. Après « Générer le fichier CSV » : l’envoi s’active', ready === true);
q("document.getElementById('exMailTo').value='client@exemple.com'; document.getElementById('exPwd').value='DAVAR@2026'; mailExport();");
const consumed = q("EXPORT_READY === null && document.querySelector('[onclick=\"mailExport()\"]').disabled");
log('3d. Un seul envoi par fichier : après l’envoi, le bouton se désactive', consumed === true);
q("document.getElementById('exPwd').value='DAVAR@2026'; runExport(); location.hash='#/admin/ventes'; render();");
const leftDead = q("EXPORT_READY === null");
log('3e. Sortir de la page Exports annule le fichier généré — il faudra régénérer', leftDead === true);
q("location.hash='#/admin/exports'; render();");
const backDisabled = q("document.querySelector('[onclick=\"mailExport()\"]').disabled");
log('3f. Retour sur Exports : bouton d’envoi de nouveau désactivé', backDisabled === true);

done('SMOKE62');
