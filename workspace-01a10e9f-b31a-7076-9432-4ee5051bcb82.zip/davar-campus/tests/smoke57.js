/* SMOKE 57 — Dashboards personnalisés des membres du staff
   1) Chaque rôle voit SES KPI et SES tâches (aucune tâche non actionnable)
   2) Aucune donnée financière hors Super Admin / Manager
   3) Aucun lien mort : chaque lien du dashboard mène à une section autorisée */
const { boot, log, done } = require('./_boot.js');
const { q } = boot();

const overview = uid => q(`(function(){ S.session={userId:${JSON.stringify(uid)},token:'x'}; location.hash='#/admin'; render(); return document.getElementById('adPage').textContent })()`);
const pageLinks = uid => JSON.parse(q(`(function(){ S.session={userId:${JSON.stringify(uid)},token:'x'}; location.hash='#/admin'; render(); return JSON.stringify([...document.querySelectorAll('#adPage a[href^="#/admin/"], #adPage a[href="#/admin"]')].map(a => a.getAttribute('href').replace('#/admin/', '').replace('#/admin', '').split('/')[0])) })()`));
const accessOf = uid => JSON.parse(q(`JSON.stringify(staffAccess(getUser(${JSON.stringify(uid)})))`));
const noFinance = t => !t.includes('Ventes (30 j)') && !t.includes('Vente confirmée') && !t.includes('Vérifier :');
const linksOk = uid => pageLinks(uid).every(sec => accessOf(uid).includes(sec));

/* 1. Coach : ses questions + copies, zéro finance, liens autorisés */
const tCoach = overview('u-test-coach');
log('1. Coach : « Questions pour moi » + tâches conversation/évaluations, zéro finance, liens autorisés',
  tCoach.includes('Bonjour Coach') && tCoach.includes('Questions pour moi') && tCoach.includes('Étudiants suivis') &&
  noFinance(tCoach) && linksOk('u-test-coach'));

/* 2. Correcteur : ses copies à corriger */
const tCorr = overview('u-test-correcteur');
log('2. Correcteur : « Copies à corriger » / « Copies corrigées », zéro finance, liens autorisés',
  tCorr.includes('Copies à corriger') && tCorr.includes('Copies corrigées') &&
  noFinance(tCorr) && linksOk('u-test-correcteur'));

/* 3. Contenu : formations et brouillons */
const tCont = overview('u-test-contenu');
log('3. Contenu : « Formations publiées » + brouillons à finaliser, zéro finance, liens autorisés',
  tCont.includes('Formations publiées') && tCont.includes('Chapitres') &&
  noFinance(tCont) && linksOk('u-test-contenu'));

/* 4. Support : conversations ouvertes */
const tSup = overview('u-test-support');
log('4. Support : « Conversations ouvertes » / « Résolues », file de tickets, zéro finance, liens autorisés',
  tSup.includes('Conversations ouvertes') && tSup.includes('Résolues') && tSup.includes('Ma file de travail') &&
  noFinance(tSup) && linksOk('u-test-support'));

/* 5. Analyste : KPI pédagogiques (jamais de finances) */
const tAna = overview('u-test-analyste');
log('5. Analyste : complétion + note moyenne + accès analytics, zéro finance, liens autorisés',
  tAna.includes('Taux de complétion') && tAna.includes('Note moyenne') && tAna.includes('Ouvrir les analytics complets') &&
  noFinance(tAna) && linksOk('u-test-analyste'));

/* 6. Assistant : étudiants + travaux en attente */
const tAss = overview('u-test-assistant');
log('6. Assistant : « Étudiants » + « Travaux en attente », zéro finance, liens autorisés',
  tAss.includes('Travaux en attente') && tAss.includes('ce mois-ci') &&
  noFinance(tAss) && linksOk('u-test-assistant'));

/* 7. Manager : pilotage complet AVEC finances (autorisé) */
const tMgr = overview('u-test-manager');
log('7. Manager : pilotage complet — finances visibles (autorisé), tâches globales',
  tMgr.includes('Ventes (30 j)') && tMgr.includes('À traiter maintenant') && linksOk('u-test-manager'));

/* 8. Super Admin : tableau de bord inchangé */
const tAdm = overview('u-yann');
log('8. Super Admin : pilotage complet inchangé (stats + « À traiter maintenant » + activité)',
  tAdm.includes('Ventes (30 j)') && tAdm.includes('À traiter maintenant') && tAdm.includes('Activité récente'));

/* 9. Combo de rôles (coach+correcteur) : les deux espaces, sans doublon de tâche */
const tCombo = q(`(function(){ S.team.push({id:'tm-x',name:'Combo (test)',email:'combo.test@davarcampus.co',roles:['coach','correcteur']}); S.users.push({id:'u-x',name:'Combo Test',email:'combo.test@davarcampus.co',role:'staff',joined:Date.now()}); return (function(){ S.session={userId:'u-x',token:'x'}; location.hash='#/admin'; render(); return document.getElementById('adPage').textContent })() })()`);
const nPending = Number(q("S.submissions.filter(x=>x.status==='pending').length"));
log('9. Rôles combinés (coach+correcteur) : les deux KPI, chaque copie listée une seule fois',
  tCombo.includes('Questions pour moi') && tCombo.includes('Copies à corriger') &&
  (tCombo.match(/Corriger :/g) || []).length === nPending &&
  (tCombo.match(/Copies à corriger/g) || []).length === 1 && noFinance(tCombo));

done('SMOKE57');
