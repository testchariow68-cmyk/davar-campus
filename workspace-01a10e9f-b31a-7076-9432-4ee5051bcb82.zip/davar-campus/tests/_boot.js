const { JSDOM } = require('/home/user/node_modules/jsdom');
const fs = require('fs');
const ROOT = '/home/user/davar-campus';
function boot() {
  const dom = new JSDOM(fs.readFileSync(ROOT + '/index.html', 'utf8'), { url: 'http://localhost:8080/#/', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window; w.scrollTo = () => {}; w.URL.createObjectURL = () => 'blob:x';
  const files = ['js/icons.js','js/data.js','js/emails.js','js/ui.js','js/lifecycle.js','js/security-client.js','js/views-student.js','js/rewards.js','js/views-campus.js','js/views-admin.js','js/app.js'];
  w.eval(files.map(f => fs.readFileSync(ROOT + '/' + f, 'utf8')).join('\n;\n') + `\n;window.__q=expr=>eval(expr);window.__setSession=u=>{S.session=u};`);
  const q = e => w.eval(`__q(${JSON.stringify(e)})`);
  const body = () => w.document.body.textContent;
  return { w, q, body, fs, ROOT };
}
let p = 0, f = 0;
const log = (l, ok) => { console.log(ok ? 'OK  ' : 'FAIL', l); ok ? p++ : f++; };
const done = name => { console.log(`${name} : ${p} OK / ${f} FAIL`); process.exit(f ? 1 : 0); };
module.exports = { boot, log, done };
