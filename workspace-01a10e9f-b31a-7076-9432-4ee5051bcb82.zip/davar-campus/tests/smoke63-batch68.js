/* SMOKE 63 — Batch 68 : code secret avec confirmation obligatoire (identique sinon impossible) + activation du test de vue Manager en Configuration. */
const { boot, log, done } = require('./_boot');
const { q } = boot();

/* 1. Code secret : les deux champs doivent être identiques */
q("(function(){ S.session={userId:'u-awa',token:'x'}; location.hash='#/profil'; render(); return 1 })()");
const fields = q("!!document.getElementById('pfPwd') && !!document.getElementById('pfPwd2')");
log('1. Profil : deux champs — nouveau code secret + confirmation', fields === true);
const mismatch = q("(function(){ document.getElementById('pfPwd').value='CODE@123'; document.getElementById('pfPwd2').value='CODE@999'; saveProfile(); return getUser('u-awa').password })()");
log('1b. Codes différents : enregistrement IMPOSSIBLE, rien n’est sauvé', mismatch === undefined);
const half = q("(function(){ document.getElementById('pfPwd').value='CODE@123'; document.getElementById('pfPwd2').value=''; saveProfile(); return getUser('u-awa').password })()");
log('1c. Confirmation vide : refusée aussi', half === undefined);
const match = q("(function(){ document.getElementById('pfPwd').value='CODE@123'; document.getElementById('pfPwd2').value='CODE@123'; saveProfile(); return getUser('u-awa').password })()");
log('1d. Codes identiques : enregistré', match === 'CODE@123');
const dirtyOK = q("(function(){ location.hash='#/profil'; render(); document.getElementById('pfPwd2').value='X'; const d=pfDirty(); pfReset(); const clean=document.getElementById('pfPwd2').value==='' ; return d && clean })()");
log('1e. La confirmation compte comme modification (Home/Annuler) et se réinitialise', dirtyOK === true);

/* 2. Configuration : bouton d’activation du test de vue chez le Manager */
const cfg = q("(function(){ S.session={userId:'u-yann',token:'x'}; location.hash='#/admin/parametres'; render(); return document.body.innerHTML })()");
log('2. Configuration (Super Admin) : interrupteur « Test de vue chez le Manager »', cfg.includes('Test de vue chez le Manager') && cfg.includes('setManagerViewAs'));
q("setManagerViewAs(true);");
const on = q("S.settings.managerViewAs === true");
q("setManagerViewAs(false);");
const off = q("S.settings.managerViewAs === false");
log('2b. L’interrupteur active/désactive vraiment (persisté)', on === true && off === true);

/* 3. Le fondateur n’apparaît JAMAIS dans une liste de vues, même Manager activé */
q("setManagerViewAs(true);");
const lists = q("viewAsList().map(x=>x.id).join('|')");
log('3. Aucune liste de vues ne contient le fondateur (u-yann)', !lists.includes('u-yann') && lists.includes('u-test-etudiant'));
const htmlList = q("viewAsList().map(x=>x.lbl).join('|')");
log('3b. Aucun nom réel dans les libellés de vues', !htmlList.includes('YAPO') && htmlList.includes('Vue Étudiant — Étudiant (test)'));
q("setManagerViewAs(false);");

done('SMOKE63');
