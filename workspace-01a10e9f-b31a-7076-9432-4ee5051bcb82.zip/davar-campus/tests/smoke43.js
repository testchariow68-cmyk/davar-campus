const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
w.eval("__setSession({userId:'u-awa',token:'x'});");
log('1. Routage de repli historique : CI → Money Fusion ; France → Chariow', q("payRouteFor(getUser('u-awa'))") === 'moneyfusion' && q("(function(){const u=getUser('u-awa');const c=u.country;u.country='France';const r=payRouteFor(u);u.country=c;return r})()") === 'chariow');
/* Nouveau modèle : le 1er achat se fait HORS de l'app (Chariow, il donne accès à la plateforme).
   Dans l'app, tous les achats sont des achats supplémentaires → Flutterwave, voie universelle. */
q("location.hash='#/catalogue';render();startPurchase('t-anglais')");
log('2. Achat dans l’app : « Obtenir » ouvre le paiement Flutterwave (voie universelle)', w.document.body.innerHTML.includes('Paiement sécurisé Flutterwave'));
q("closeModal()");
q("(function(){getUser('u-awa').country='France'})()");
q("startPurchase('t-anglais')");
log('3. Compte France : même paiement Flutterwave — universel pour tout le monde', w.document.body.innerHTML.includes('Paiement sécurisé Flutterwave'));
q("closeModal();(function(){getUser('u-awa').country='Côte d’Ivoire'})()");
q("location.hash='#/checkout/t-anglais';CHECKOUT.tid='t-anglais';CHECKOUT.step=2;render();");
log('4. Checkout étape 2 : panneau universel (mobile money + carte internationale)', body().includes('voie universelle') && body().includes('cartes internationales'));
/* Admin désactive Flutterwave → repli historique Money Fusion / Chariow */
q("S.settings.flutterwave.enabled=false");
const ciHtml = q("(function(){CHECKOUT.tid='t-anglais';CHECKOUT.step=2;return vCheckout(getUser('u-awa'),'t-anglais')})()");
const frHtml = q("(function(){getUser('u-awa').country='France';CHECKOUT.tid='t-anglais';CHECKOUT.step=2;return vCheckout(getUser('u-awa'),'t-anglais')})()");
log('5. Flutterwave désactivé : repli → CI = Mobile Money, France = carte', ciHtml.includes('Paiement Mobile Money') && frHtml.includes('Payer par carte bancaire'));
q("S.settings.flutterwave.enabled=true;(function(){getUser('u-awa').country='Côte d’Ivoire'})()");
// facture PDF (flux Money Fusion conservé : repli + compatibilité des paiements en cours)
q("S.settings.flutterwave.enabled=false;CHECKOUT.tid='t-anglais';CHECKOUT.step=2;CHECKOUT.method='wave';location.hash='#/checkout/t-anglais';render();payViaMoneyFusion('t-anglais')");
await sleep(2600);
q("S.settings.flutterwave.enabled=true");
log('6. Achat confirmé (repli MF) → bouton Facture PDF sur l’écran de succès', body().includes('Facture PDF'));
const pdf = q("makeSmallPDF([['DAVAR ACADEMIE',14,1],['Facture test',11,1]])");
const dec = q("decodeURIComponent(escape(atob('" + pdf.split(',')[1] + "')))");
log('7. Facture = vrai PDF (en-tête %PDF + xref)', pdf.startsWith('data:application/pdf;base64,') && dec.startsWith('%PDF-1.4') && dec.includes('startxref'));
log('8. Contenu facture : total, méthode, pays', q("(()=>{const s=S.sales[0];return s.status==='confirmé'})()") === true && body().includes('confirmé par Wave') && !body().includes('Money Fusion'));
// 1er achat (hors app, Chariow) : le webhook crée l'accès avec les infos client
q("__setSession({userId:'u-jean-k',token:'x'});");
log('9. Jean (vente confirmée seed) : considéré ayant acheté', q("hasBought('u-jean-k')") === true);
q("(function(){delete getUser('u-jean-k').country; simulateChariowWebhook('t-marketing');})()");
log('10. Webhook Chariow (1er achat hors app) : pays + indicatif mémorisés', q("getUser('u-jean-k').country") === 'Côte d’Ivoire' && q("getUser('u-jean-k').paySource") === 'chariow');
// paramètre pays modifiable
q("location.hash='#/parametres';render();");
log('11. Paramètres : pays modifiable + indicatif visible', !!w.document.getElementById('setCountry') && body().includes('Côte d’Ivoire'));
done('SMOKE43');
})();
