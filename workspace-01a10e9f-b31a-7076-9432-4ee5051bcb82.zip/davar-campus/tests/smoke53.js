const { boot, log, done } = require('./_boot');
const { w, q, fs, ROOT } = boot();

/* Capture l'e-mail réellement envoyé en stubant sendMailSim (le vrai chemin sendFlow est exécuté) */
q(`window.__cap = null; window.__realMail = sendMailSim;
   sendMailSim = function (to, subject, opts) { window.__cap = { to, subject, from: opts && opts.from, body: opts && opts.body, flow: opts && opts.flow }; window.__realMail(to, subject, opts); };`);
const cap = () => w.eval('window.__cap');

/* 1. Mot de passe oublié → support@davarcampus.co */
q(`sendFlow('pwd_reset', 'etudiant@mail.ci', { email: 'etudiant@mail.ci' })`);
let m = cap();
log('1. Mot de passe oublié → support@davarcampus.co (flux audité)', m && m.from === 'support@davarcampus.co' && m.flow === 'pwd_reset' && m.to === 'etudiant@mail.ci' && /réinitialisation/i.test(m.subject));

/* 2. Bienvenue → infos@davarcampus.co : désinscription + rappel des droits (sans citer de loi) */
q(`sendFlow('welcome', 'awa@mail.ci', { name: 'Awa', userId: 'u-awa' })`);
m = cap();
log('2. Bienvenue → infos@davarcampus.co + droits & lien de désinscription', m && m.from === 'infos@davarcampus.co' && /désinscrire/i.test(m.body) && m.body.includes('vous avez des droits') && !/RGPD|CAN-SPAM|loi/i.test(m.body) && m.body.includes('desinscription?e=awa%40mail.ci') && m.body.includes('L’équipe Davar Académie'));

/* 3. Certificat → direction@davarcampus.co, signature solennelle */
q(`sendFlow('cert_ready', 'awa@mail.ci', { code: 'OR-2026-001' })`);
m = cap();
log('3. Certificat → direction@davarcampus.co, signature « La Direction »', m && m.from === 'direction@davarcampus.co' && m.body.includes('La Direction Davar Académie') && m.subject.includes('OR-2026-001') && !/désinscrire/i.test(m.body));

/* 4. Partenariat → contact@davarcampus.co (équipe commerciale) */
q(`sendFlow('partnership', 'contact@davarcampus.co', { name: 'Orange CI' })`);
m = cap();
log('4. Partenariat → contact@davarcampus.co, signature commerciale', m && m.from === 'contact@davarcampus.co' && m.body.includes('équipe Commerciale') && m.subject.includes('Orange CI'));

/* 5. Double canal infos@ : e-mail + web push (dual + pushEnabled) */
q(`S.settings.pushEnabled = true`);
const notifsBefore = q(`S.notifs.filter(n => n.userId === 'u-awa').length`);
q(`sendFlow('new_course', 'awa@mail.ci', { title: 'Gérer son trac', userId: 'u-awa' })`);
const notifsAfter = q(`S.notifs.filter(n => n.userId === 'u-awa').length`);
m = cap();
log('5. Double canal : e-mail infos@ + web push envoyés ensemble', m && m.from === 'infos@davarcampus.co' && notifsAfter === notifsBefore + 1);

/* 6. Confirmation d'achat → support@davarcampus.co, branchée sur les 3 webhooks (MF + Chariow + Flutterwave) */
q(`sendFlow('purchase_ok', 'awa@mail.ci', { title: 'Art oratoire : les fondamentaux' })`);
m = cap();
const hooks = fs.readFileSync(ROOT + '/js/views-student.js', 'utf8');
const nHooks = (hooks.match(/sendFlow\('purchase_ok'/g) || []).length;
log('6. Confirmation d’achat → support@ + branchée sur les 3 webhooks (MF + Chariow + Flutterwave)', m && m.from === 'support@davarcampus.co' && /confirmé/i.test(m.subject) && nHooks === 3);

/* 7. Les 18 flux routés existent tous avec un rôle valide */
const roles = q(`Object.keys(MAIL_FLOWS).map(k => MAIL_FLOWS[k].role).filter(r => !MAIL_SIGNS[r]).length`);
const nFlows = q(`Object.keys(MAIL_FLOWS).length`);
log('7. ' + nFlows + ' flux routés, tous avec signature de rôle valide', nFlows >= 18 && roles === 0);

done('SMOKE53');
