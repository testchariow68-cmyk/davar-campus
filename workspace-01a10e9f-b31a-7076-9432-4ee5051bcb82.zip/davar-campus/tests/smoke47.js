const { log, done } = require('./_boot');
(async () => {
const L2 = await import('../security/workers/layer2-pq-crypto.mjs');
const L3 = await import('../security/workers/layer3-ai-defense.mjs');
const L4 = await import('../security/workers/layer4-behavioral.mjs');
const c = require('crypto');

/* adaptateur X25519 node:crypto (même contrat que WebCrypto en production) */
const HDR = Buffer.from('302a300506032b656e032100', 'hex');
function nodeX25519() {
  const privs = new Map();
  return {
    async generate() { const { publicKey, privateKey } = c.generateKeyPairSync('x25519'); const pub = publicKey.export({ type: 'spki', format: 'der' }).slice(-32).toString('base64'); privs.set(pub, privateKey); return { priv: pub, pub }; },
    async derive(handle, pubB64) { const pubKey = c.createPublicKey({ key: Buffer.concat([HDR, Buffer.from(pubB64, 'base64')]), format: 'der', type: 'spki' }); return new Uint8Array(c.diffieHellman({ privateKey: privs.get(handle), publicKey: pubKey })); }
  };
}
const x = nodeX25519();
const alice = await x.generate(), bob = await x.generate();
const te = new TextEncoder();
const pqStub = {
  async encaps(pub) { const ct = 'ct-' + pub.slice(0, 6); return { ct, shared: te.encode(pub + ct) }; },
  async decaps(priv, ct) { return te.encode(priv + ct); }
};

const b1 = await L2.hybridEncrypt('secret étudiant', { x25519Pub: bob.pub }, { x25519: x });
const d1 = await L2.hybridDecrypt(b1, { priv: bob.priv }, { x25519: x });
log('1. Couche 2 : chiffrement X25519+AES-GCM, déchiffrement identique', d1 === 'secret étudiant' && b1.mode === 'classique-PQ-ready');

const b2 = await L2.hybridEncrypt('donnée sensible', { x25519Pub: bob.pub, pqPub: 'PQPUB' }, { x25519: x, pqKem: pqStub });
const d2 = await L2.hybridDecrypt(b2, { priv: bob.priv, pqPriv: 'PQPUB' }, { x25519: x, pqKem: pqStub });
log('2. Couche 2 : mode hybride PQ (slot ML-KEM) round-trip', d2 === 'donnée sensible' && b2.mode === 'hybride-PQ');

let threw = false;
try { const bad = { ...b1, ct: b1.ct.slice(0, b1.ct.length - 4) + 'AAAA' }; await L2.hybridDecrypt(bad, { priv: bob.priv }, { x25519: x }); } catch { threw = true; }
log('3. Couche 2 : toute altération du chiffré est rejetée (AES-GCM authentifié)', threw === true);

const now = Date.now();
log('4. Couche 3 : rotation des secrets à 24 h (règle 5)', L3.shouldRotateSecrets(now - 23 * 3600000, now) === false && L3.shouldRotateSecrets(now - 25 * 3600000, now) === true);
const burst = Array.from({ length: 90 }, (_, i) => ({ at: now - i * 500, type: 'req' }));
log('5. Couche 3 : rafale détectée, débit normal accepté', L3.rateAnomaly(burst, now).verdict === 'anomalie' && L3.rateAnomaly([], now).verdict === 'normal');
log('6. Couche 3 : classification sévérité (journal immuable)', L3.classifyEvent('purge') === 'critical' && L3.classifyEvent('login_failed') === 'warning');

const gen = (base, jitter) => Array.from({ length: 30 }, (_, i) => ({ t: i * base + Math.round(Math.random() * jitter), x: i * 5 + Math.random(), y: Math.sin(i) + Math.random() * 0.4, p: 0.5 + Math.random() * 0.1 }));
const pA1 = L4.buildProfile(gen(45, 9)), pA2 = L4.buildProfile(gen(45, 9)), pB = L4.buildProfile(gen(16, 1));
log('7. Couche 4 : même utilisateur = similarité haute, autre profil = basse', L4.similarity(pA1, pA2) > 0.9 && L4.similarity(pA1, pB) < 0.95);
log('8. Couche 4 : score de confiance progressif (jamais de saut brutal)', L4.trustUpdate(80, 0.95) === 84 && L4.trustUpdate(80, 0.85) === 81 && L4.trustUpdate(80, 0.7) === 74 && L4.trustUpdate(80, 0.3) === 55);
done('SMOKE47');
})();
