const { boot, log, done } = require('./_boot');
const { w, q, body } = boot();
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
/* Contexte repli (Flutterwave désactivé) : le contrat Money Fusion reste valide comme repli + paiements en cours */
w.eval("__setSession({userId:'u-awa',token:'x'});");
q("S.settings.flutterwave.enabled=false;location.hash='#/checkout/t-entreprendre';render();");
q("CHECKOUT.step=2;CHECKOUT.method='wave';render();");
log('1. Checkout Money Fusion (repli) : 4 opérateurs + frais 3,5 %', body().includes('Paiement Mobile Money') && body().includes('Moov Money') && body().includes('3,5 %'));
// --- contrat : demande de paiement ---
const res = q("(function(){ const u=getUser('u-awa'); const t=getTraining('t-entreprendre'); return mfCreatePayment(u, t, MF_METHODS[0], '0700000000', t.price + Math.round(t.price*0.035), Math.round(t.price*0.035), 'DAV-TEST'); })()");
const rec0 = q("S.mfPayments[S.mfPayments.length-1]");
log('2. Demande de paiement : champs officiels (totalPrice, article, numeroSend, nomclient, webhook_url)', rec0.payload.totalPrice > 0 && Array.isArray(rec0.payload.article) && rec0.payload.numeroSend === '0700000000' && rec0.payload.nomclient && rec0.payload.webhook_url.includes('/api/moneyfusion/webhook'));
log('3. Réponse officielle {statut, token, message, url payin.moneyfusion.net}', res.statut === true && !!res.token && res.message === 'paiement en cours' && res.url.includes('payin.moneyfusion.net/payment/'));
// --- vérification statut avant paiement ---
const chk0 = q("mfCheckPaymentStatus('" + res.token + "')");
log('4. GET paiementNotif : statut pending avant confirmation', chk0.statut === true && chk0.data.statut === 'pending');
// --- webhook pending répété puis completed ---
q("mfWebhook({event:'payin.session.pending',tokenPay:'" + res.token + "'})");
q("mfWebhook({event:'payin.session.pending',tokenPay:'" + res.token + "'})");
q("(function(){ const r=S.mfPayments[S.mfPayments.length-1]; r.gatewayPaid=true; r.numeroTransaction='TX-123456'; })()");
q("mfWebhook({event:'payin.session.completed',tokenPay:'" + res.token + "',Montant:" + rec0.amount + ",frais:" + rec0.fee + "})");
log('5. payin.session.completed + vérification paid → formation débloquée', q("enrolledIn('u-awa','t-entreprendre')") === true && q("S.mfPayments[S.mfPayments.length-1].statut") === 'paid');
log('6. Vente « Money Fusion · Wave » avec n° de transaction', q("S.sales[0].method") === 'Money Fusion · Wave' && q("S.sales[0].txn") === 'TX-123456');
const nSales = q("S.sales.filter(s=>s.ref==='DAV-TEST').length");
q("mfWebhook({event:'payin.session.completed',tokenPay:'" + res.token + "'})");
q("mfWebhook({event:'payin.session.pending',tokenPay:'" + res.token + "'})");
log('7. Notifications multiples : aucun doublon, statut jamais rétrogradé', q("S.sales.filter(s=>s.ref==='DAV-TEST').length") === nSales && q("S.mfPayments[S.mfPayments.length-1].event") === 'completed');
q("mfWebhook({event:'payin.session.completed',tokenPay:'TOKEN_INCONNU'})");
log('8. tokenPay inconnu rejeté sans crash', true);
// --- annulation ---
q("(function(){ const u=getUser('u-awa'); const t=getTraining('t-anglais'); mfCreatePayment(u, t, MF_METHODS[1], '0700000000', 1000, 35, 'DAV-ANN'); })()");
const tkA = q("S.mfPayments[S.mfPayments.length-1].tokenPay");
q("mfWebhook({event:'payin.session.cancelled',tokenPay:'" + tkA + "'})");
log('9. payin.session.cancelled : pas de déblocage + étudiant notifié', q("enrolledIn('u-awa','t-anglais')") === false && q("S.mfPayments[S.mfPayments.length-1].statut") === 'failure' && q("(S.notifs||[]).some(n=>n.title==='Paiement annulé')"));
// --- flux complet via bouton ---
q("payViaMoneyFusion('t-entreprendre')");
await sleep(2600);
log('10. Bouton Payer → pending → completed → confirmation', q("CHECKOUT.step") === 3 && body().includes('Achat confirmé'));
done('SMOKE42');
})();
