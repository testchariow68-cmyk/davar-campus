-- ============================================================================
-- DAVAR ACADÉMIE CAMPUS — Schéma Supabase (PostgreSQL)
-- À exécuter dans : Supabase Dashboard → SQL Editor
-- ============================================================================
create extension if not exists "pgcrypto";

-- ============================================================
-- 1. UTILISATEURS & RÔLES (rôles cumulables)
-- ============================================================
create table public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  full_name  text not null,
  email      text not null unique,
  phone      text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create type public.team_role as enum
  ('coach','correcteur','assistant','contenu','support','analyste','admin');

create table public.team_members (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  roles      public.team_role[] not null default '{}',
  active     boolean not null default true,
  created_at timestamptz not null default now()
);

-- Fonctions de permission (security definer pour éviter la récursion RLS)
create or replace function public.has_role(r public.team_role)
returns boolean language sql stable security definer as $$
  select exists (
    select 1 from public.team_members
    where profile_id = auth.uid() and active and r = any(roles)
  );
$$;

create or replace function public.is_staff()
returns boolean language sql stable security definer as $$
  select exists (
    select 1 from public.team_members
    where profile_id = auth.uid() and active and cardinality(roles) > 0
  );
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer as $$
  select exists (
    select 1 from public.team_members
    where profile_id = auth.uid() and active and 'admin' = any(roles)
  );
$$;

-- Création automatique du profil à l'inscription
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name, email, phone)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
          new.email, new.raw_user_meta_data->>'phone')
  on conflict (id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- 2. FORMATIONS : Formation → Chapitres → Modules → Contenus
-- ============================================================
create table public.trainings (
  id          uuid primary key default gen_random_uuid(),
  code        text unique,
  title       text not null,
  slug        text unique,
  description text,
  long_description text,
  level       text default 'Débutant',
  hours       int default 0,
  price_xof   int not null default 0,
  published   boolean not null default false,
  hue         int default 268,             -- identité visuelle de la couverture
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.chapters (
  id          uuid primary key default gen_random_uuid(),
  training_id uuid not null references public.trainings(id) on delete cascade,
  title       text not null,
  position    int not null default 0
);

create table public.modules (
  id          uuid primary key default gen_random_uuid(),
  chapter_id  uuid not null references public.chapters(id) on delete cascade,
  title       text not null,
  position    int not null default 0,
  video_key   text,                        -- clé d'objet dans R2 (jamais d'URL publique)
  video_ratio text default '16:9',         -- 16:9 | 9:16 | 4:3 | 1:1
  video_duration_sec int,
  body_text   text                         -- contenu principal écrit
);

-- Ressources complémentaires (séparées du contenu principal)
create table public.module_resources (
  id        uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.modules(id) on delete cascade,
  name      text not null,
  kind      text not null default 'pdf',   -- pdf | doc | img | other
  file_key  text not null,                 -- objet R2 privé
  size_bytes bigint
);

-- Vidéos complémentaires (section distincte)
create table public.module_extra_videos (
  id        uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.modules(id) on delete cascade,
  title     text not null,
  video_key text not null,
  ratio     text default '16:9',
  duration_sec int,
  position  int not null default 0
);

-- ============================================================
-- 3. INSCRIPTIONS & PROGRESSION (strictement individuelle)
-- ============================================================
create table public.enrollments (
  user_id    uuid not null references public.profiles(id) on delete cascade,
  training_id uuid not null references public.trainings(id) on delete cascade,
  enrolled_at timestamptz not null default now(),
  primary key (user_id, training_id)      -- unicité : jamais de doublon
);

create table public.progress (
  user_id   uuid not null references public.profiles(id) on delete cascade,
  module_id uuid not null references public.modules(id) on delete cascade,
  watched_pct int not null default 0 check (watched_pct between 0 and 100),
  viewed    boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, module_id)
);

-- ============================================================
-- 4. EXERCICES (non bloquants) & ÉVALUATIONS (bloquantes)
-- ============================================================
create table public.exercises (
  id         uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  title      text not null,
  intro      text
);
create table public.exercise_questions (
  id          uuid primary key default gen_random_uuid(),
  exercise_id uuid not null references public.exercises(id) on delete cascade,
  position    int not null default 0,
  qtype       text not null check (qtype in ('single','multi')),
  question    text not null,
  options     jsonb not null,              -- ["option A","option B",…]
  correct     jsonb not null,              -- 2 (index) ou [0,2]
  explanation text
);
create table public.exercise_attempts (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  exercise_id uuid not null references public.exercises(id) on delete cascade,
  score       int not null, total int not null,
  answers     jsonb not null,
  created_at  timestamptz not null default now()
);

create table public.assessments (
  id         uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  title      text not null,
  intro      text,
  atype      text not null check (atype in ('quiz','submission')),
  min_score  int check (min_score between 1 and 100),   -- requis pour quiz
  accepts    text                                        -- formats autorisés (soumission)
);
-- Quiz d'évaluation = mêmes questions que les exercices
create table public.assessment_questions (
  id            uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  position      int not null default 0,
  qtype         text not null check (qtype in ('single','multi')),
  question      text not null,
  options       jsonb not null,
  correct       jsonb not null,
  explanation   text
);
create table public.assessment_attempts (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  score int, total int, pct int,
  passed boolean not null default false,
  answers jsonb,
  created_at timestamptz not null default now()
);

create table public.submissions (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  file_key      text not null,             -- dépôt privé (R2/Storage)
  file_name     text not null,
  size_bytes    bigint,
  note          text,
  status        text not null default 'pending'
                check (status in ('pending','approved','rejected','retry')),
  feedback      text,                      -- OBLIGATOIRE pour rejected/retry (contrôlé côté app)
  decided_by    uuid references public.profiles(id),
  decided_at    timestamptz,
  created_at    timestamptz not null default now()
);

-- ============================================================
-- 5. CONVERSATIONS (Coach + Assistant IA, supervisées)
-- ============================================================
create table public.threads (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  training_id uuid not null references public.trainings(id) on delete cascade,
  module_id   uuid references public.modules(id) on delete set null,
  ai_validated boolean not null default false,
  resolved    boolean not null default false,
  created_at  timestamptz not null default now()
);
create table public.thread_messages (
  id         uuid primary key default gen_random_uuid(),
  thread_id  uuid not null references public.threads(id) on delete cascade,
  author     text not null check (author in ('student','ai','coach','sys')),
  author_id  uuid references public.profiles(id),   -- null pour 'ai' et 'sys'
  body       text not null,
  routed_to_coach boolean not null default false,
  created_at timestamptz not null default now()
);

-- ============================================================
-- 6. ASSISTANT IA (indépendant du fournisseur)
-- ============================================================
create table public.ai_config (
  id           int primary key default 1 check (id = 1),  -- singleton
  provider     text not null default 'openai',            -- openai|anthropic|mistral|custom
  model        text,
  api_key_ref  text,          -- référence secret (jamais la clé en clair ici)
  display_name text,          -- NULL = nom par défaut du système IA
  temperature  numeric(2,1) default 0.4,
  updated_at   timestamptz not null default now()
);
insert into public.ai_config (provider) values ('openai');

-- Base de connaissances : namespace SÉPARÉ par formation
create table public.ai_knowledge (
  training_id uuid primary key references public.trainings(id) on delete cascade,
  enabled     boolean not null default true,
  namespace   text generated always as ('kb_' || training_id) stored
);

-- ============================================================
-- 7. NOTIFICATIONS (Push Web VAPID) — anti-doublons
-- ============================================================
create table public.push_subscriptions (
  id        uuid primary key default gen_random_uuid(),
  user_id   uuid not null references public.profiles(id) on delete cascade,
  endpoint  text not null unique,
  p256dh    text not null, auth_key text not null,
  created_at timestamptz not null default now()
);
create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id) on delete cascade,
  ntype      text not null,               -- coach|ai|exercise|eval|cert|sale|info
  title      text not null,
  body       text,
  dedupe_key text,                        -- évite les doublons d'événements
  read       boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, dedupe_key)
);

-- ============================================================
-- 8. CERTIFICATIONS (système existant intégré)
-- ============================================================
create table public.certificates (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique,       -- ex. CERT-2026-0147
  user_id     uuid not null references public.profiles(id) on delete cascade,
  training_id uuid not null references public.trainings(id) on delete cascade,
  issued_at   timestamptz not null default now(),
  status      text not null default 'actif' check (status in ('actif','révoqué')),
  unique (user_id, training_id)
);

-- ============================================================
-- 9. VENTES (événements reçus du système de paiement)
-- ============================================================
create table public.sales (
  id            uuid primary key default gen_random_uuid(),
  external_ref  text unique,              -- référence CinetPay (idempotence webhook)
  user_id       uuid references public.profiles(id),
  email         text not null,
  training_id   uuid not null references public.trainings(id),
  amount_xof    int not null,             -- prix net de la formation
  fee_xof       int not null default 0,   -- frais de transaction
  fee_borne_by  text not null default 'student' check (fee_borne_by in ('student','davar')),
  zone          text default 'af',        -- af (mobile money) | int (cartes Europe/international)
  method        text not null,            -- wave|orange_money|mtn_momo|moov|card (via CinetPay)
  status        text not null default 'confirmed',
  created_at    timestamptz not null default now()
);

-- Journal d'audit du Centre de contrôle
create table public.audit_log (
  id        bigint generated always as identity primary key,
  actor_id  uuid references public.profiles(id),
  action    text not null,
  payload   jsonb,
  created_at timestamptz not null default now()
);

create index idx_sales_user on public.sales(user_id);
create index idx_notifs_user on public.notifications(user_id, read);
create index idx_progress_user on public.progress(user_id);

-- ============================================================
-- 10. ATTRIBUTION D'UNE VENTE (cœur de la règle métier)
-- achat confirmé → compte identifié → formation attribuée
-- Appelée par l'Edge Function webhook (service role).
-- ============================================================
create or replace function public.assign_training_from_sale(
  p_email text, p_training uuid, p_amount int, p_method text, p_ref text
) returns void language plpgsql security definer as $$
declare v_user uuid;
begin
  select id into v_user from public.profiles where lower(email) = lower(p_email);
  if v_user is null then
    raise exception 'compte introuvable : créer le profil via Edge Function (service role)';
  end if;
  insert into public.sales (external_ref, user_id, email, training_id, amount_xof, method)
  values (p_ref, v_user, p_email, p_training, p_amount, p_method)
  on conflict (external_ref) do nothing;            -- idempotent
  insert into public.enrollments (user_id, training_id)
  values (v_user, p_training)
  on conflict (user_id, training_id) do nothing;    -- JAMAIS de doublon de compte
  insert into public.notifications (user_id, ntype, title, body, dedupe_key)
  values (v_user, 'sale', 'Achat confirmé ✓',
          'Votre formation a été ajoutée à votre compte.', 'sale_' || p_ref);
end $$;

-- ============================================================
-- 11. ROW LEVEL SECURITY — isolation stricte des étudiants
-- ============================================================
alter table public.profiles            enable row level security;
alter table public.team_members        enable row level security;
alter table public.trainings           enable row level security;
alter table public.chapters            enable row level security;
alter table public.modules             enable row level security;
alter table public.module_resources    enable row level security;
alter table public.module_extra_videos enable row level security;
alter table public.enrollments         enable row level security;
alter table public.progress            enable row level security;
alter table public.exercises           enable row level security;
alter table public.exercise_questions  enable row level security;
alter table public.exercise_attempts   enable row level security;
alter table public.assessments         enable row level security;
alter table public.assessment_questions enable row level security;
alter table public.assessment_attempts enable row level security;
alter table public.submissions         enable row level security;
alter table public.threads             enable row level security;
alter table public.thread_messages     enable row level security;
alter table public.notifications       enable row level security;
alter table public.push_subscriptions  enable row level security;
alter table public.certificates        enable row level security;
alter table public.sales               enable row level security;
alter table public.audit_log           enable row level security;
alter table public.ai_config           enable row level security;

-- Profils : chacun lit le sien ; l'équipe lit tout
create policy "own profile" on public.profiles for select using (id = auth.uid());
create policy "staff reads profiles" on public.profiles for select using (public.is_staff());
create policy "staff manages profiles" on public.profiles for update using (public.is_staff());

-- Contenu pédagogique : visible si publié + inscrit, ou si équipe
create policy "read published enrolled" on public.trainings for select using (
  (published and exists (select 1 from public.enrollments e
    where e.training_id = trainings.id and e.user_id = auth.uid()))
  or public.is_staff());
create policy "catalog preview" on public.trainings for select using (published);
create policy "staff writes trainings" on public.trainings for all using (public.has_role('contenu') or public.is_admin());
create policy "staff writes chapters" on public.chapters for all using (public.has_role('contenu') or public.is_admin());
create policy "staff writes modules" on public.modules for all using (public.has_role('contenu') or public.is_admin());

-- PROGRESSION : un étudiant ne lit JAMAIS celle d'un autre
create policy "own progress" on public.progress for all using (user_id = auth.uid());
create policy "own enrollments" on public.enrollments for select using (user_id = auth.uid());
create policy "staff reads enrollments" on public.enrollments for select using (public.is_staff());

create policy "own attempts ex" on public.exercise_attempts for all using (user_id = auth.uid());
create policy "own attempts ev" on public.assessment_attempts for all using (user_id = auth.uid());
create policy "own submissions" on public.submissions for select using (user_id = auth.uid());
create policy "own submissions insert" on public.submissions for insert with check (user_id = auth.uid());
create policy "staff corrects submissions" on public.submissions for select using (public.has_role('correcteur') or public.is_staff());
create policy "staff updates submissions" on public.submissions for update using (public.has_role('correcteur') or public.is_staff());

-- Conversations : l'étudiant lit les siennes ; coach/admin supervisent tout
create policy "own threads" on public.threads for select using (user_id = auth.uid());
create policy "own threads insert" on public.threads for insert with check (user_id = auth.uid());
create policy "own messages" on public.thread_messages for select using (
  exists (select 1 from public.threads t where t.id = thread_id and t.user_id = auth.uid()));
create policy "own messages insert" on public.thread_messages for insert with check (
  exists (select 1 from public.threads t where t.id = thread_id and t.user_id = auth.uid())
  and author = 'student');
create policy "staff sees all threads" on public.threads for select using (public.is_staff());
create policy "staff sees all messages" on public.thread_messages for select using (public.is_staff());
create policy "staff posts as coach" on public.thread_messages for insert with check (public.is_staff());
create policy "staff updates threads" on public.threads for update using (public.is_staff());

create policy "own notifications" on public.notifications for select using (user_id = auth.uid());
create policy "own notifications update" on public.notifications for update using (user_id = auth.uid());
create policy "own push subs" on public.push_subscriptions for all using (user_id = auth.uid());

create policy "own certs" on public.certificates for select using (user_id = auth.uid() or public.is_staff());
create policy "staff manages certs" on public.certificates for all using (public.is_admin());
create policy "staff reads sales" on public.sales for select using (public.is_staff());
create policy "staff reads audit" on public.audit_log for select using (public.is_admin());
create policy "admin reads ai config" on public.ai_config for select using (public.is_staff());
create policy "admin writes ai config" on public.ai_config for update using (public.is_admin());

-- ============================================================
-- 12. STOCKAGE (buckets privés — vidéos via URLs signées R2)
-- ============================================================
insert into storage.buckets (id, name, public) values
  ('module-resources', 'module-resources', false),
  ('submissions',      'submissions',      false)
on conflict (id) do nothing;
-- NB : les vidéos de formation vivent dans Cloudflare R2 (bucket privé),
-- servies exclusivement via URLs signées générées par l'Edge Function
-- `video-url` après vérification enrollment + étape débloquée.

-- Dépôts étudiants : chacun écrit uniquement dans submissions/{son id}/
create policy "students upload own submission"
on storage.objects for insert to authenticated
with check (bucket_id = 'submissions'
            and storage.foldername(name)[1] = auth.uid()::text);
-- Lecture des dépôts : correcteurs & admins seulement
create policy "staff reads submissions"
on storage.objects for select to authenticated
using (bucket_id = 'submissions' and public.is_staff());
-- Ressources de modules : lecture si inscrit à la formation
create policy "enrolled reads resources"
on storage.objects for select to authenticated
using (bucket_id = 'module-resources'
       and exists (
         select 1 from public.module_resources r
         join public.modules m on m.id = r.module_id
         join public.chapters c on c.id = m.chapter_id
         join public.enrollments e on e.training_id = c.training_id
         where r.file_key = name and e.user_id = auth.uid()));

-- ============================================================================
-- EDGE FUNCTIONS À CRÉER (Supabase CLI) :
--  • video-url       → vérifie enrollment + déblocage → URL signée R2 (TTL court)
--  • sales-webhook   → reçoit l'événement paiement signé → assign_training_from_sale()
--  • push            → envoi Push Web (VAPID) sur événements (dédoublonné)
--  • ai-complete     → adapte l'appel au fournisseur configuré (ai_config),
--                      contexte = base de connaissances de LA formation uniquement
-- ============================================================================
