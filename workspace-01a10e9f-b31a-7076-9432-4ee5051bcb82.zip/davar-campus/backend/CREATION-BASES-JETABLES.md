# ARCHIVÉ / NE PAS SUIVRE — guide ancien de création de bases jetables

**Décision ultérieure du propriétaire : aucune nouvelle base.** Ce guide est conservé pour historique uniquement. Ne lancez aucune des commandes de création qui suivent ; suivre `MIGRATIONS-STAGING-PREPARATION.md` pour le plan actualisé sur les bases staging existantes.

**But :** créer trois cibles vides pour les futurs essais de migration, sans toucher aux schémas de staging actuels. À ce stade, on ne lance **aucune migration**, aucun fichier `.sql`, aucun nouveau Worker et aucun test avec donnée réelle. Ne partagez aucun mot de passe, jeton, chaîne PostgreSQL, capture montrant des secrets ou URL signée.

## Avant de commencer : coûts et isolation

Vérifiez le solde/les limites de chaque fournisseur et arrêtez-vous si l'écran vous propose d'activer une facturation, d'augmenter le plafond, ou si les quotas ne vous conviennent pas. Même une base vide ou les essais ultérieurs peuvent utiliser des ressources. L'option CockroachDB ci-dessous crée une **nouvelle base logique dans le cluster staging existant**, pas un nouveau cluster : les données sont séparées mais **les quotas du cluster sont partagés**. Si vous exigez un cluster physiquement distinct, arrêtez-vous et demandez un autre plan avant de le créer : certains comptes ne peuvent pas ouvrir un deuxième cluster Basic sans informations de facturation.

Noms proposés (si déjà pris, **arrêtez-vous** et choisissez un autre nom sans toucher à l'existant) :

- D1 : `davar-campus-lab-20261002`
- Turso : `davar-campus-lab-20261002`
- CockroachDB : `davar_campus_lab_20261002` (base distincte de `defaultdb` dans le cluster Cockroach staging actuel)

## 1. Cloudflare D1 (interface, pas PowerShell)

1. Ouvrez le **même compte Cloudflare** que celui du Worker staging. Dans le tableau de bord, ouvrez **D1 SQL database** > **Create Database**.
2. Nommez la base `davar-campus-lab-20261002`. Choisissez une localisation adéquate si l'interface le demande ; ne modifiez pas la D1 `davar-campus-staging` déjà liée au Worker.
3. Validez **Create**. Vérifiez que vous voyez la **nouvelle** base dans la liste. **Ne l'ajoutez pas au binding `D1` du Worker staging**, ne modifiez pas `wrangler.staging.jsonc` et ne créez pas de token pour le moment.
4. La présence éventuelle de `_cf_KV` est normale : c'est une table interne, pas une table à effacer.

Guide officiel : https://developers.cloudflare.com/d1/get-started/#2-create-a-database

## 2. Turso (interface, sans clonage)

1. Dans la même organisation Turso que `davar-campus-staging`, vérifiez d'abord quotas et facturation. Ouvrez **Databases** > **Create database** (libellé susceptible de varier).
2. Nommez-la `davar-campus-lab-20261002`. Choisissez le moteur **libSQL** (comme la connexion staging `libsql://…`), le groupe/région adapté ; **ne sélectionnez aucune option de copie/seed depuis staging**, ni source fichier/dump.
3. Créez la nouvelle base. Vérifiez son nom et qu'elle est distincte de `davar-campus-staging`. **Ne créez pas de jeton d'écriture pour le Worker de diagnostic**, ne remplacez pas `TURSO_AUTH_TOKEN`.

La CLI Turso documente la création sans l'option `--tursodb` pour libSQL et avertit que, s'il existe plusieurs groupes, il faut choisir le groupe. Vous n'avez **pas besoin de lancer la CLI** pour ces étapes. Références : https://docs.turso.tech/quickstart et https://docs.turso.tech/cli/db/create

## 3. CockroachDB (base logique séparée, même cluster)

1. Sur CockroachDB Cloud, sélectionnez **le cluster staging existant** (celui que vous avez déjà validé). Vérifiez l'usage et les limites RU/stockage ; une base supplémentaire **partage ses quotas** avec les autres bases de ce cluster. Si l'isolation des coûts vous paraît insuffisante, **arrêtez ici**.
2. Ouvrez **SQL Shell** de ce cluster, si votre compte y a accès. Vérifiez en haut de l'écran le nom du cluster ; exécutez seulement `SELECT current_database();` pour voir quelle base est sélectionnée actuellement.
3. Créez une **base séparée**, sans l'option `IF NOT EXISTS` afin qu'une collision de nom fasse échouer l'opération au lieu de réutiliser une base existante :

```sql
CREATE DATABASE davar_campus_lab_20261002;
```

4. Rafraîchissez la page SQL Shell pour voir la nouvelle base dans le menu. **N'y créez aucune table et n'exécutez aucune migration.** Ne changez ni la configuration du cluster, ni la connexion Hyperdrive existante. Si vous n'avez pas accès au SQL Shell ou si le nom existe déjà, arrêtez-vous et dites-le-moi ; ne cherchez pas à contourner les autorisations.

CockroachDB documente SQL Shell et la sélection de la base active : https://docs.cockroachlabs.com/docs/cockroachcloud/sql-shell . Selon le compte, un second cluster Basic peut exiger l'ajout d'informations de facturation : https://docs.cockroachlabs.com/docs/cockroachcloud/create-a-basic-cluster .

## Réponse attendue

Communiquez uniquement : **D1 créée : oui/non ; Turso créée : oui/non ; Cockroach base séparée créée : oui/non ; blocage éventuel : texte sans secret.** Les noms ci-dessus sont déjà convenus, donc aucun identifiant technique supplémentaire n'est nécessaire. Ne partagez pas de captures avec une URL de connexion ou un mot de passe. Nous préparerons ensuite l'accès opérateur *sur ces cibles uniquement* et un essai limité à la migration 0 ; rien ne sera appliqué aux bases de staging existantes sans validation distincte.
