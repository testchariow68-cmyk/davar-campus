# HISTORIQUE — migrations communes sur trois bases (mises en pause)

**Décision actuelle : Turso seule base applicative cible.** Suspendre la migration version 0 précédemment envisagée sur Turso, CockroachDB et D1 ; l'accord de principe antérieur ne vaut pas validation du nouveau périmètre Turso seul. Aucun des fichiers SQL ci-dessous ne doit être appliqué tel quel. Voir `../TURSO-SEUL-PLAN.md` pour le plan courant. Aucun fichier ni base n'est supprimé.

## Préparation antérieure — aucune écriture distante exécutée

État au 2 octobre 2026. **Ce document n'est pas un ordre de lancer `wrangler d1 execute --file`, `migrations apply` ou les scripts SQL.** Les bases concernées sont exclusivement les trois ressources *staging* déjà identifiées dans `STAGING.md`. Le Worker public/diagnostic et le campus public ne doivent pas devenir des outils d'administration.

## Résultat du préflight en lecture déjà obtenu

- Turso : aucune table visible dans l'inventaire exécuté par le propriétaire.
- CockroachDB : aucune table `public` visible dans l'inventaire exécuté par le propriétaire ; il ne prouve rien sur d'autres schémas ni sur les privilèges de migration.
- D1 : `_cf_KV` seule table retournée par `sqlite_master`. C'est une table **interne réservée** de D1, à ne jamais lire, exporter manuellement, supprimer, modifier ni recréer. Documentation fournisseur : https://developers.cloudflare.com/d1/best-practices/import-export-data/ . Dans la réponse actuelle du Worker v3, elle explique `otherTableCount:1`.
- Cet inventaire est un **instantané**, pas une garantie au moment d'une future écriture.

## Périmètre envisagé (sous réserve de validation séparée)

| Version | Fichiers SQL dans `sql/` | Objets qui seraient créés sur **chaque** base staging | Données insérées |
|---|---|---|---|
| 0 | `staging.sqlite.sql` / `staging.postgres.sql` | `schema_migrations`, `replication_checkpoint`, `operation_receipts`, 1 index | 1 reçu de version par base (technique), **aucun utilisateur** |
| 1 | `001_domain.sqlite.sql` / `001_domain.postgres.sql` | 7 tables `campus_*`, 3 index | 1 reçu de version, **aucun compte ni vente** |
| 2 | `002_sandbox_replication.sqlite.sql` / `002_sandbox_replication.postgres.sql` | `sandbox_records`, `operation_outbox` | 1 reçu de version, **aucun événement fictif tant qu'un test distinct n'est pas autorisé** |

Il s'agit de **12 tables et 4 index par base**, plus la table système `_cf_KV` propre à D1 et non gérée par nous. L'application n'utilise pas encore ces tables. Le schéma métier de 7 tables est un noyau d'essai, **pas** une modélisation complète du campus.

## Barrières obligatoires avant toute application distante

1. Confirmer une autorisation explicite couvrant seulement le staging, les versions souhaitées (0, 0–1 ou 0–2), la création de tables/index et des reçus techniques ; **pas** de purge, transfert de données réelles, ni changement du campus public. Les données fictives exigent une autorisation distincte.
2. Utiliser une **procédure d'opérateur séparée** du Worker de diagnostic : authentification locale de l'opérateur et privilèges minimum nécessaires ; ne pas remplacer son jeton Turso lecture seule par un jeton en écriture. Ne jamais coller de secrets dans le chat, le dépôt, une capture ou une ligne de commande archivée.
3. Reconfirmer que chaque identifiant cible est bien une base *staging*, et inspecter à nouveau tables **et index**, toutes les versions/checksums préexistants et les schémas Cockroach concernés, immédiatement avant toute action. Toute table/index inattendu, même `campus_*` sans reçu de migration, doit arrêter l'opération. Seul D1 peut ignorer **exactement** `_cf_KV` dans ce contrôle ; ne pas ignorer des noms arbitraires ou `d1_migrations` sans vérification.
4. Préparer un point de restauration propre à **chaque fournisseur** et en vérifier la procédure de restauration sur un environnement jetable. Pas de suppression automatique en cas d'échec ; inspecter d'abord le schéma et les reçus. Évaluer les quotas/coûts avant de lancer les opérations.
5. **Sans bases jetables, les essais réels sur les fournisseurs ne peuvent pas précéder la première migration staging.** Examiner la compatibilité Cockroach du dialecte PostgreSQL et la documentation des transactions/DDL Turso et D1 ; identifier les points non vérifiables en lecture seule et les accepter explicitement avant écriture. La première application de la version 0 sur staging sera elle-même un essai risqué, limité et suivi de contrôles immédiats. **SQLite local ne démontre pas ces propriétés distantes.** Documenter la méthode transactionnelle de chaque opérateur et les conditions d'échec/reprise ; ne jamais simuler qu'un rollback distant a été validé.
6. Avant chaque migration, vérifier empreinte du fichier SQL et reçu précédent, version continue, absence de collisions et absence d'une autre instance opératrice en cours. Créer DDL et reçu dans la **même unité atomique**, si et seulement si cela a été démontré pour le fournisseur. Si ce n'est pas garanti, ne pas exécuter la migration à distance : concevoir un protocole de reprise sûr, puis le retester.
7. Après chaque version appliquée : vérification en lecture seule des noms et définitions des objets, empreinte et version du reçu, contraintes et absence de lignes métier. Une erreur dans un des trois fournisseurs = **arrêt** ; ne pas déclarer les trois schémas synchrones. Aucun branchement de la réplication ou du frontend tant que la validation technique n'est pas complète.

## État du logiciel de préparation

Le runner `migration_runner.py` ne se connecte **à aucun** service distant. En SQLite **local**, il vérifie désormais les versions/checksums, refuse tout objet préexistant inconnu ou sans reçu et compare le DDL exact enregistré des tables/index à un schéma de référence reconstruit à partir des scripts ; en mode de simulation `provider='d1'`, il tolère seulement le nom exact `_cf_KV` sans le modifier. Cette comparaison stricte a été testée avec une colonne et un index altérés ; elle peut aussi refuser un schéma équivalent créé manuellement, par prudence. **Elle ne s'applique pas aux trois bases hébergées.**

`plan_migration.py` construit uniquement **hors réseau** un JSON de revue : noms des objets et empreintes SHA-256 des fichiers par fournisseur/versions. Sa version par défaut est 0 et il **n'a pas d'option `--apply`**. Exemples sans secret et sans requête distante : `python3 plan_migration.py --provider d1 --through 0`, puis `--provider turso` ou `--provider cockroach`. Ce contrôle des noms n'analyse pas tout le SQL et ne prouve pas que CockroachDB accepte le DDL.

**Vérification actuelle : 28 tests Python + 16 tests Node réussis localement.** Aucun de ces outils n'est encore un opérateur connecté à une base distante. Les tests sont des simulations ; l'inventaire du Worker v3 ne regarde que les noms de tables et n'est **pas** un préflight suffisant pour une écriture.

**Décision du propriétaire : ne créer AUCUNE nouvelle base.** Utiliser uniquement les trois bases staging existantes déjà inventoriées. Le guide `CREATION-BASES-JETABLES.md` est **abandonné**, pas à exécuter. Les essais de compatibilité et de rollback sur de vraies ressources jetables ne seront donc pas disponibles : cette limite augmente le risque des premières écritures sur staging. Ne pas présenter les tests SQLite locaux comme validation hébergée. Progresser d'abord par préflight en lecture seule, contrôle des coûts, point de restauration et opérateur distinct du Worker de diagnostic, puis présenter pour approbation un lot **minimal de migration version 0** sur chaque base staging, avec arrêt au premier écart et vérification après chaque fournisseur. Ne pas créer de tables temporaires de test ni purger quoi que ce soit par défaut.

**Point d'arrêt actuel :** le propriétaire a donné son accord de principe pour **version 0 technique sur les trois bases staging**, mais a demandé à revoir contrôles finaux et commandes avant exécution. Ni opérateur distant transactionnel, ni restauration vérifiée, ni validation réelle Cockroach/D1/Turso ne sont prêts. Le préflight v0 en lecture seule de l'archive Worker v4 (`PREFLIGHT-STAGING-V0-READONLY.md`) a répondu `inspected:true/clear:false` : Turso et D1 `clear:true`, Cockroach `clear:false/otherObjectCount:1`. Le propriétaire a identifié ce dernier dans `defaultdb` : **schéma système préinstallé `pg_extension`**, non une table utilisateur (https://www.cockroachlabs.com/docs/stable/system-catalogs). Les tables/index/vues `public` n'étaient pas retournés. La correction du filtre est testée localement mais pas déployée. **Ne pas supprimer ou modifier `pg_extension` et ne pas présenter cette inspection comme une sauvegarde ou l'autorisation de migrer.** Aucune commande de migration distante n'est fournie dans ce document pour éviter toute application prématurée. Ne demander aucun mot de passe ou jeton dans le chat.

Documentation technique à utiliser lors de la conception de l'opérateur : transactions batch D1 https://developers.cloudflare.com/d1/worker-api/d1-database/ ; transactions batch Turso https://docs.turso.tech/sdk/ts/reference . Il faut **tester** les garanties sur des bases jetables ; la documentation ne suffit pas à prouver le fonctionnement de notre schéma chez ces fournisseurs.
