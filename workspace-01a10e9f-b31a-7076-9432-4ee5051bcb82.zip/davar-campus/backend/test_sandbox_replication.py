"""Tests sans connexion internet ni credentials, avec SQLite en mémoire uniquement."""
import sqlite3
import unittest
from sandbox_replication import DemoGroup, UnsafePromotion, _atomic_apply, _digest, _chain, checkpoint


class SandboxReplicationTest(unittest.TestCase):
    def setUp(self):
        self.g = DemoGroup()

    def tearDown(self):
        self.g.close()

    def test_three_empty_databases_same_schema_and_foreign_keys(self):
        for db in self.g.db.values():
            self.assertEqual(checkpoint(db),0)
            self.assertEqual(db.execute('PRAGMA foreign_keys').fetchone()[0],1)
            for table in ('campus_users','campus_trainings','campus_sales',
                          'campus_certificates','sandbox_records','operation_outbox'):
                self.assertIsNotNone(db.execute('SELECT name FROM sqlite_master WHERE name=?',
                                                (table,)).fetchone())

    def test_domain_invariants_no_real_seed(self):
        db=self.g.db['turso']
        self.assertEqual(db.execute('SELECT COUNT(*) FROM campus_users').fetchone()[0],0)
        db.execute("INSERT INTO campus_users(id,email_normalized,display_name,password_hash,"
                   "role,created_at_ms) VALUES('test-1','test@example.invalid','Test','fake-hash','student',1)")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO campus_users(id,email_normalized,display_name,password_hash,"
                       "role,created_at_ms) VALUES('test-2','test@example.invalid','Test','fake-hash','student',1)")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO campus_staff_roles(user_id,role) VALUES('absent','manager')")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO campus_trainings(id,title,price_cfa) VALUES('t','Test',-1)")

    def test_one_active_reads_writes_technically_replicated_to_inactive(self):
        self.assertEqual(self.g.write('op-a','sandbox-a','demo:alpha',expected_epoch=1),1)
        self.assertEqual(self.g.read('sandbox-a'),('demo:alpha',))
        self.assertIsNone(self.g.db['d1'].execute('SELECT value FROM sandbox_records').fetchone())
        self.assertEqual(self.g.replicate_to('cockroach'),1)
        self.assertEqual(self.g.replicate_to('d1'),1)
        self.assertEqual([checkpoint(db) for db in self.g.db.values()],[1,1,1])

    def test_idempotency_and_conflicting_duplicate(self):
        self.g.write('op-a','sandbox-a','demo:alpha',expected_epoch=1)
        self.assertEqual(self.g.write('op-a','sandbox-a','demo:alpha',expected_epoch=1),1)
        with self.assertRaises(ValueError):
            self.g.write('op-a','sandbox-a','demo:changed',expected_epoch=1)
        self.assertEqual(self.g.committed_seq,1)

    def test_out_of_order_and_modified_event_refused(self):
        db=self.g.db['d1']; digest=_digest('sandbox-b','demo:beta')
        event=(2,'op-b','sandbox-b','demo:beta',digest,2,'GENESIS',_chain('GENESIS',2,'op-b',digest))
        with self.assertRaises(UnsafePromotion): _atomic_apply(db,event)
        with self.assertRaises(ValueError):
            _atomic_apply(db,(1,'op-b','sandbox-b','demo:beta','bad-hash',1,'GENESIS','fake'))
        self.assertEqual(checkpoint(db),0)

    def test_crash_rolls_back_all_tables(self):
        db=self.g.db['turso']; digest=_digest('sandbox-b','demo:beta')
        event=(1,'op-b','sandbox-b','demo:beta',digest,1,'GENESIS',_chain('GENESIS',1,'op-b',digest))
        with self.assertRaises(RuntimeError): _atomic_apply(db,event,fail_after_record=True)
        for table in ('sandbox_records','operation_outbox','operation_receipts'):
            self.assertEqual(db.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0],0)
        self.assertEqual(checkpoint(db),0)

    def test_stale_replica_cannot_be_promoted_even_if_primary_down(self):
        self.g.write('op-a','sandbox-a','demo:alpha',expected_epoch=1)
        self.g.up['turso']=False
        with self.assertRaises(UnsafePromotion): self.g.promote('cockroach')
        with self.assertRaises(ConnectionError): self.g.write('op-b','sandbox-b','demo:beta',expected_epoch=1)
        self.assertEqual(self.g.active,'turso')

    def test_failover_failback_fencing_and_rejoin(self):
        self.g.write('op-a','sandbox-a','demo:alpha',expected_epoch=1)
        self.g.replicate_to('cockroach');self.g.replicate_to('d1')
        self.g.up['turso']=False
        self.assertEqual(self.g.promote('cockroach'),2)
        with self.assertRaises(UnsafePromotion):
            self.g.write('op-old','sandbox-old','demo:stale',expected_epoch=1)
        self.g.write('op-b','sandbox-a','demo:beta',expected_epoch=2)
        self.g.replicate_to('d1')
        self.g.up['turso']=True
        with self.assertRaises(UnsafePromotion): self.g.promote('turso')
        self.g.replicate_to('turso')
        self.assertEqual(self.g.promote('turso'),3)
        self.assertEqual(self.g.read('sandbox-a'),('demo:beta',))
        self.assertEqual([checkpoint(db) for db in self.g.db.values()],[2,2,2])

    def test_matching_sequence_but_divergent_chain_refused(self):
        self.g.write('op-a','sandbox-a','demo:alpha',expected_epoch=1)
        self.g.replicate_to('d1')
        # Même séquence affichée, mais empreinte différente : promotion interdite.
        self.g.db['d1'].execute("UPDATE replication_checkpoint SET last_hash='modified' WHERE stream='sandbox'")
        with self.assertRaises(UnsafePromotion): self.g.promote('d1')

    def test_mismatched_previous_hash_refused_during_replay(self):
        digest=_digest('sandbox-a','demo:alpha')
        event=(1,'op-a','sandbox-a','demo:alpha',digest,1,'wrong',_chain('wrong',1,'op-a',digest))
        with self.assertRaises(UnsafePromotion): _atomic_apply(self.g.db['d1'],event)
        self.assertEqual(checkpoint(self.g.db['d1']),0)

    def test_reject_non_synthetic_content(self):
        with self.assertRaises(ValueError):
            self.g.write('op-a','sandbox-a','email@example.com',expected_epoch=1)
        with self.assertRaises(ValueError):
            self.g.write('op-a','user-id','demo:alpha',expected_epoch=1)


if __name__ == '__main__': unittest.main()
