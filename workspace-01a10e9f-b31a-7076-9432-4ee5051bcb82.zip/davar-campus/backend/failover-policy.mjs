/**
 * Politique de sélection TESTABLE, non branchée à l'app / aux fournisseurs.
 * Le backend de production DOIT fournir un verrou distribué persistant (promote)
 * et un contrôle de révision durable (caughtUp). Ce module n'est pas un verrou.
 */
export const ORDER = Object.freeze(['turso', 'cockroach', 'd1']);
export function createFailoverPolicy({ probe, caughtUp, promote, timeoutMs = 2000, failAfter = 3, recoverAfter = 3, initial = 'turso' }) {
  if (![...ORDER, 'local'].includes(initial)) throw new Error('source inconnue');
  if (![probe, caughtUp, promote].every(fn => typeof fn === 'function')) throw new Error('adaptateurs manquants');
  let active = initial, failures = 0, healthy = Object.fromEntries(ORDER.map(n => [n, 0]));
  let inTick = false;
  const doProbe = async name => {
    const controller = new AbortController();
    let timer;
    try { return !!(await Promise.race([
      Promise.resolve().then(() => probe(name, controller.signal)),
      new Promise((_, reject) => { timer = setTimeout(() => {
        controller.abort(); reject(new Error('timeout'));
      }, timeoutMs); })
    ])); } catch { return false; } finally { clearTimeout(timer); }
  };
  async function tick() {
    if (inTick) return active; // pas de sondages concurrents
    inTick = true;
    try {
      // Une boucle côté serveur seulement, jamais dans chaque onglet/client.
      const checks = await Promise.all(ORDER.map(async n => [n, await doProbe(n)]));
      const status = Object.fromEntries(checks);
      for (const n of ORDER) healthy[n] = status[n] ? healthy[n] + 1 : 0;
      if (active !== 'local') failures = status[active] ? 0 : failures + 1;
      const broken = active === 'local' || failures >= failAfter;
      const target = ORDER.find(n => status[n] &&
        (broken || ORDER.indexOf(n) < ORDER.indexOf(active)) &&
        healthy[n] >= (broken && n !== active ? 1 : recoverAfter));
      let switched = false;
      if (target && target !== active) {
        // Ne PAS promouvoir une source à la traîne. Révision vérifiée côté service.
        if (await caughtUp(target)) {
          // promote doit drainer/fencer l'ancienne source et être atomique/persistant.
          await promote(active, target);
          active = target; failures = 0; switched = true;
        }
      }
      if (!switched && active !== 'local' && failures >= failAfter) {
        // Aucun secours sain / à jour : n'inventer aucune donnée.
        const candidates = ORDER.filter(n => n !== active && status[n]);
        let found = false;
        for (const n of candidates) {
          if (await caughtUp(n)) {
            await promote(active, n); active = n; failures = 0; found = true; break;
          }
        }
        if (!found) { await promote(active, 'local'); active = 'local'; failures = 0; }
      }
      return active;
    } finally { inTick = false; }
  }
  return { tick, get active() { return active; }, get failures() { return failures; } };
}
