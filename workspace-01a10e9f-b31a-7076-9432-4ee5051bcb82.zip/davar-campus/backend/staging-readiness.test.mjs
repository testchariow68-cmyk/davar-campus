import test from 'node:test';
import assert from 'node:assert/strict';
import handler, {summarizeCockroachPreflight} from './src/staging-readiness.mjs';
const request=(path,token)=>new Request('https://staging.example.com'+path,{headers:token?{authorization:`Bearer ${token}`}:{}});
const env={ENVIRONMENT:'staging',ADMIN_HEALTH_TOKEN:'test-secret-not-real'};
test('seule la route interne existe',async()=>{
  assert.equal((await handler.fetch(request('/api/users'),env)).status,404);
});
test('une sonde anonyme ne révèle aucun identifiant ni état',async()=>{
  const r=await handler.fetch(request('/_internal/readiness'),env);
  assert.equal(r.status,401);assert.deepEqual(await r.json(),{error:'unauthorized'});
});
test('sans secret serveur la sonde reste inaccessible',async()=>{
  const r=await handler.fetch(request('/_internal/readiness'),{ENVIRONMENT:'staging'});
  assert.equal(r.status,503);
});
test('sans accès fournisseurs, réponse honnête et sans écriture',async()=>{
  const r=await handler.fetch(request('/_internal/readiness',env.ADMIN_HEALTH_TOKEN),env);
  assert.equal(r.status,503);assert.deepEqual((await r.json()).providers,
    {turso:'unconfigured',cockroach:'unconfigured',d1:'unconfigured'});
});
test('D1 sous test peut répondre, Turso et Cockroach restent non configurés',async()=>{
  const query=[];
  const d={prepare:(sql)=>{query.push(sql);return {first:async()=>({ok:1})}}};
  const r=await handler.fetch(request('/_internal/readiness',env.ADMIN_HEALTH_TOKEN),{...env,D1:d});
  assert.equal(r.status,503);assert.deepEqual(query,['SELECT 1 AS ok']);
});

test('inventaire privé : pas de contenu, seulement les noms attendus et un compte des autres',async()=>{
  const data={D1:{prepare:()=>({all:async()=>({results:[
    {name:'campus_users'},{name:'sandbox_records'},{name:'unrelated_table'}]})})}};
  const r=await handler.fetch(request('/_internal/inventory',env.ADMIN_HEALTH_TOKEN),{...env,...data});
  assert.equal(r.status,503);
  const body=await r.json();
  assert.deepEqual(body.inventory.d1,{status:'ok',known:['campus_users','sandbox_records'],otherTableCount:1});
  assert.equal(JSON.stringify(body).includes('unrelated_table'),false);
});
test('inventaire refusé sans autorisation',async()=>{
  const r=await handler.fetch(request('/_internal/inventory'),env);
  assert.equal(r.status,401);
});

test('préflight v0 privé : _cf_KV D1 ignorée, aucun contenu ni écriture',async()=>{
  const queries=[];
  const D1={prepare:(sql)=>{queries.push(sql);return {all:async()=>({results:[{type:'table',name:'_cf_KV'}]})}}};
  const r=await handler.fetch(request('/_internal/preflight-v0',env.ADMIN_HEALTH_TOKEN),{...env,D1});
  assert.equal(r.status,503);
  const body=await r.json();
  assert.deepEqual(body.preflight.d1,{status:'ok',clear:true,otherObjectCount:0});
  assert.equal(body.clear,false); // deux autres fournisseurs non configurés
  assert.equal(body.mode,'read_only');
  assert.deepEqual(queries,["SELECT type,name FROM sqlite_master WHERE type IN ('table','index','view','trigger') AND name NOT LIKE 'sqlite_%'"]);
});
test('préflight v0 : un index D1 étranger bloque, sans divulguer son nom',async()=>{
  const D1={prepare:()=>({all:async()=>({results:[
    {type:'table',name:'_cf_KV'}, {type:'index',name:'foreign_index'}]})})};
  const r=await handler.fetch(request('/_internal/preflight-v0',env.ADMIN_HEALTH_TOKEN),{...env,D1});
  const body=await r.json();
  assert.deepEqual(body.preflight.d1,{status:'ok',clear:false,otherObjectCount:1});
  assert.equal(JSON.stringify(body).includes('foreign_index'),false);
});
test('préflight Cockroach : pg_extension est un schéma système, un autre schéma bloque',()=>{
  const builtin=['public','pg_catalog','information_schema','crdb_internal','pg_extension'].map(schema_name=>({schema_name}));
  assert.deepEqual(summarizeCockroachPreflight([],[],builtin),
    {status:'ok',clear:true,otherObjectCount:0});
  assert.deepEqual(summarizeCockroachPreflight([],[],[...builtin,{schema_name:'unknown_app_schema'}]),
    {status:'ok',clear:false,otherObjectCount:1});
  assert.deepEqual(summarizeCockroachPreflight([{table_name:'unknown'}],[],builtin),
    {status:'ok',clear:false,otherObjectCount:1});
});
test('préflight v0 refusé sans secret',async()=>{
  const r=await handler.fetch(request('/_internal/preflight-v0'),env);
  assert.equal(r.status,401);
});
