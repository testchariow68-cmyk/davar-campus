/**
 * Diagnostic STAGING uniquement : sondes SELECT 1, jamais une écriture applicative.
 * N'est pas le routeur de production, ni un service de failover autonome.
 * Ne crée PAS de données, ne publie aucun secret / identifiant dans les réponses.
 */
import { createClient } from '@libsql/client/web';
import pg from 'pg';

async function limited(task, ms = 2000) {
  let timer;
  try {
    return await Promise.race([
      Promise.resolve().then(task),
      new Promise((_, reject) => { timer = setTimeout(() => reject(Error('timeout')), ms); })
    ]);
  } finally { clearTimeout(timer); }
}

async function turso(env) {
  if (!env.TURSO_DATABASE_URL || !env.TURSO_AUTH_TOKEN) return 'unconfigured';
  const client = createClient({url: env.TURSO_DATABASE_URL, authToken: env.TURSO_AUTH_TOKEN});
  try { await limited(() => client.execute('SELECT 1 AS ok')); return 'ok'; }
  catch { return 'unavailable'; }
  finally { client.close(); }
}

async function cockroach(env) {
  if (!env.HYPERDRIVE?.connectionString) return 'unconfigured';
  const client = new pg.Client({connectionString: env.HYPERDRIVE.connectionString,
    connectionTimeoutMillis: 1800, query_timeout: 1800});
  try { await limited(async () => { await client.connect(); await client.query('SELECT 1 AS ok'); }); return 'ok'; }
  catch { return 'unavailable'; }
  finally { try { await limited(() => client.end(), 300); } catch { /* closed/timeout */ } }
}

async function d1(env) {
  if (!env.D1) return 'unconfigured';
  try { await limited(() => env.D1.prepare('SELECT 1 AS ok').first()); return 'ok'; }
  catch { return 'unavailable'; }
}

// Inventaire limité aux NOMS des tables de staging ; aucun contenu de table exposé.
const knownTables = new Set(['schema_migrations','replication_checkpoint','operation_receipts',
  'campus_users','campus_staff_roles','campus_sessions','campus_trainings',
  'campus_enrollments','campus_sales','campus_certificates',
  'sandbox_records','operation_outbox']);
function inventoryResult(names) {
  const list = names.filter(x => typeof x === 'string');
  return { known: list.filter(x => knownTables.has(x)).sort(),
    otherTableCount: list.filter(x => !knownTables.has(x)).length };
}
async function inventoryTurso(env) {
  if (!env.TURSO_DATABASE_URL || !env.TURSO_AUTH_TOKEN) return {status:'unconfigured'};
  const client=createClient({url:env.TURSO_DATABASE_URL,authToken:env.TURSO_AUTH_TOKEN});
  try {
    const result=await limited(() => client.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"));
    return {status:'ok',...inventoryResult(result.rows.map(r=>r.name))};
  } catch { return {status:'unavailable'}; } finally { client.close(); }
}
async function inventoryCockroach(env) {
  if (!env.HYPERDRIVE?.connectionString) return {status:'unconfigured'};
  const client=new pg.Client({connectionString:env.HYPERDRIVE.connectionString,
    connectionTimeoutMillis:1800,query_timeout:1800});
  try {
    const result=await limited(async()=>{
      await client.connect();
      return client.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'");
    });
    return {status:'ok',...inventoryResult(result.rows.map(r=>r.table_name))};
  } catch { return {status:'unavailable'}; }
  finally { try { await limited(()=>client.end(),300); } catch { /* timeout/closed */ } }
}
async function inventoryD1(env) {
  if (!env.D1) return {status:'unconfigured'};
  try {
    const result=await limited(()=>env.D1.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all());
    return {status:'ok',...inventoryResult(result.results.map(r=>r.name))};
  } catch { return {status:'unavailable'}; }
}

// Préflight manuel de version 0 : MÉTADONNÉES uniquement, aucune ligne métier.
// 'clear' signifie seulement « aucun objet utilisateur visible par cette sonde ».
// Les définitions/permissions/sauvegardes/quotas restent à vérifier séparément.
function preflightObjects(rows, provider) {
  const rest=rows.filter(r => !(provider==='d1' && r.type==='table' && r.name==='_cf_KV'));
  return {status:'ok', clear:rest.length===0, otherObjectCount:rest.length};
}
const sqliteObjects="SELECT type,name FROM sqlite_master WHERE type IN ('table','index','view','trigger') AND name NOT LIKE 'sqlite_%'";
async function preflightTurso(env) {
  if (!env.TURSO_DATABASE_URL || !env.TURSO_AUTH_TOKEN) return {status:'unconfigured'};
  const client=createClient({url:env.TURSO_DATABASE_URL,authToken:env.TURSO_AUTH_TOKEN});
  try {
    const result=await limited(()=>client.execute(sqliteObjects));
    return preflightObjects(result.rows,'turso');
  } catch { return {status:'unavailable'}; } finally { client.close(); }
}
const builtinCockroachSchemas = new Set(['public','pg_catalog','information_schema','crdb_internal','pg_extension']);
export function summarizeCockroachPreflight(tables, indexes, schemas) {
  // Les cinq catalogues standards n'appartiennent pas à l'application.
  // Ne jamais ignorer les schémas utilisateurs inconnus.
  const otherSchemas = schemas.filter(row => !builtinCockroachSchemas.has(row.schema_name));
  const count = tables.length + indexes.length + otherSchemas.length;
  return {status:'ok',clear:count===0,otherObjectCount:count};
}
async function preflightCockroach(env) {
  if (!env.HYPERDRIVE?.connectionString) return {status:'unconfigured'};
  const client=new pg.Client({connectionString:env.HYPERDRIVE.connectionString,
    connectionTimeoutMillis:1800,query_timeout:1800});
  try {
    const result=await limited(async()=>{
      await client.connect();
      const tables=await client.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public'");
      const indexes=await client.query("SELECT DISTINCT index_name FROM information_schema.statistics WHERE table_schema='public'");
      const schemas=await client.query('SELECT schema_name FROM information_schema.schemata');
      return {tables:tables.rows,indexes:indexes.rows,schemas:schemas.rows};
    });
    return summarizeCockroachPreflight(result.tables,result.indexes,result.schemas);
  } catch { return {status:'unavailable'}; }
  finally { try { await limited(()=>client.end(),300); } catch { /* closed/timeout */ } }
}
async function preflightD1(env) {
  if (!env.D1) return {status:'unconfigured'};
  try {
    const result=await limited(()=>env.D1.prepare(sqliteObjects).all());
    return preflightObjects(result.results,'d1');
  } catch { return {status:'unavailable'}; }
}

function equal(a, b) {
  // Égalité de longueur constante pour éviter un arrêt à la première différence.
  const bytes = new TextEncoder(), x = bytes.encode(a), y = bytes.encode(b);
  let diff = x.length ^ y.length;
  for (let i=0; i<Math.max(x.length,y.length); i++) diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}
function response(body, status) {
  return new Response(JSON.stringify(body), {status,
    headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!['/_internal/readiness','/_internal/inventory','/_internal/preflight-v0'].includes(url.pathname) || request.method !== 'GET')
      return response({error:'not_found'},404);
    if (env.ENVIRONMENT !== 'staging' || !env.ADMIN_HEALTH_TOKEN) return response({error:'not_ready'},503);
    if (!equal(request.headers.get('authorization') || '', `Bearer ${env.ADMIN_HEALTH_TOKEN}`))
      return response({error:'unauthorized'},401);
    // Manuel et protégé ; ne pas appeler depuis chaque onglet utilisateur.
    if (url.pathname === '/_internal/preflight-v0') {
      const [a,b,c]=await Promise.all([preflightTurso(env),preflightCockroach(env),preflightD1(env)]);
      const inspected=[a,b,c].every(x=>x.status==='ok');
      // Le résultat « clear » n'autorise PAS une migration : voir procédure de sauvegarde.
      return response({environment:'staging',mode:'read_only',preflight:{turso:a,cockroach:b,d1:c},
        inspected,clear:inspected && [a,b,c].every(x=>x.clear)},inspected?200:503);
    }
    if (url.pathname === '/_internal/inventory') {
      const [a,b,c] = await Promise.all([inventoryTurso(env),inventoryCockroach(env),inventoryD1(env)]);
      const ready=[a,b,c].every(x=>x.status==='ok');
      return response({environment:'staging',inventory:{turso:a,cockroach:b,d1:c},ready},ready?200:503);
    }
    const [a,b,c] = await Promise.all([turso(env),cockroach(env),d1(env)]);
    return response({environment:'staging', providers:{turso:a,cockroach:b,d1:c},
      ready:[a,b,c].every(x=>x==='ok')}, [a,b,c].every(x=>x==='ok') ? 200 : 503);
  }
};
