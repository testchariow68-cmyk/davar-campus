"""Banc d'essai LOCAL, uniquement données synthétiques.

NE PAS importer dans un Worker ni brancher au campus. Les trois bases simulées sont
SQLite en mémoire ; Cockroach y est simulé et non testé en SQL réel.
Aucune migration ou requête n'est envoyée à Turso, Cockroach ou D1.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from pathlib import Path
from migration_runner import apply_local_sqlite

BASE = Path(__file__).parent / 'sql'
SOURCES = ('turso', 'cockroach', 'd1')
STREAM = 'sandbox'


class UnsafePromotion(RuntimeError):
    """La copie demandée n'a pas rattrapé le dernier commit."""


def _assert_demo(operation_id: str, record_id: str, value: str):
    if not all(isinstance(v, str) for v in (operation_id, record_id, value)):
        raise ValueError('chaînes synthétiques requises')
    if not (re.fullmatch(r'op-[a-z0-9-]{1,40}', operation_id)
            and re.fullmatch(r'sandbox-[a-z0-9-]{1,40}', record_id)
            and re.fullmatch(r'demo:[a-z0-9-]{1,80}', value)):
        raise ValueError('identifiants et valeurs de démonstration uniquement')


def _digest(record_id: str, value: str) -> str:
    raw = json.dumps({'record_id': record_id, 'value': value}, sort_keys=True,
                     ensure_ascii=False, separators=(',', ':')).encode()
    return hashlib.sha256(raw).hexdigest()


def memory_db() -> sqlite3.Connection:
    db = sqlite3.connect(':memory:', isolation_level=None)
    apply_local_sqlite(db)
    db.execute('INSERT INTO replication_checkpoint(stream,applied_seq,updated_at) VALUES(?,?,?)',
               (STREAM, 0, 0))
    return db


def checkpoint(db):
    return db.execute('SELECT applied_seq FROM replication_checkpoint WHERE stream=?',
                      (STREAM,)).fetchone()[0]


def _chain(previous: str, seq: int, operation_id: str, digest: str) -> str:
    return hashlib.sha256(f'{previous}|{seq}|{operation_id}|{digest}'.encode()).hexdigest()


def _atomic_apply(db, event, *, fail_after_record=False):
    """Réception atomique : donnée, journal, reçu idempotent, checkpoint.

    Un échec après le changement de la donnée annule TOUTE l'opération.
    """
    seq, op_id, record_id, value, digest, at, prev_hash, entry_hash = event
    _assert_demo(op_id, record_id, value)
    if digest != _digest(record_id, value):
        raise ValueError('empreinte différente du contenu')
    if _chain(prev_hash, seq, op_id, digest) != entry_hash:
        raise ValueError('chaîne du journal invalide')
    db.execute('BEGIN IMMEDIATE')
    try:
        seen = db.execute('SELECT sequence_number,payload_sha256 FROM operation_receipts '
                          'WHERE operation_id=?', (op_id,)).fetchone()
        if seen:
            if seen != (seq, digest):
                raise ValueError('réutilisation conflictuelle de operation_id')
            db.execute('COMMIT')
            return seq
        cp = db.execute('SELECT applied_seq,last_hash FROM replication_checkpoint WHERE stream=?',
                        (STREAM,)).fetchone()
        if seq != cp[0] + 1 or prev_hash != cp[1]:
            raise UnsafePromotion('trou ou divergence dans le journal')
        db.execute('INSERT INTO sandbox_records(id,value,updated_seq) VALUES(?,?,?) '
                   'ON CONFLICT(id) DO UPDATE SET value=excluded.value, '
                   'updated_seq=excluded.updated_seq', (record_id,value,seq))
        if fail_after_record:
            raise RuntimeError('panne artificielle après écriture de la donnée')
        db.execute('INSERT INTO operation_outbox(seq,operation_id,kind,record_id,value,'
                   'payload_sha256,prev_hash,entry_hash,created_at_ms) '
                   "VALUES(?,?,'sandbox.put',?,?,?,?,?,?)",
                   (seq,op_id,record_id,value,digest,prev_hash,entry_hash,at))
        db.execute('INSERT INTO operation_receipts(operation_id,stream,sequence_number,'
                   'payload_sha256,committed_at) VALUES(?,?,?,?,?)',
                   (op_id,STREAM,seq,digest,at))
        db.execute('UPDATE replication_checkpoint SET applied_seq=?,last_hash=?, updated_at=? '
                   'WHERE stream=? AND applied_seq=?', (seq,entry_hash,at,STREAM,seq-1))
        db.execute('COMMIT')
        return seq
    except Exception:
        db.execute('ROLLBACK')
        raise


class DemoGroup:
    """Modèle de cohérence pour tests locaux, PAS un verrou distribué réel."""
    def __init__(self):
        self.db = {name: memory_db() for name in SOURCES}
        self.up = {name: True for name in SOURCES}
        self.active = 'turso'
        self.epoch = 1
        self.committed_seq = 0   # En production : état DURABLE du coordinateur (pas RAM).
        self.committed_hash = 'GENESIS'

    def write(self, operation_id, record_id, value, *, expected_epoch):
        if expected_epoch != self.epoch:
            raise UnsafePromotion('époque obsolète : ancienne base interdite')
        if not self.up[self.active]:
            raise ConnectionError('base active indisponible ; aucune écriture ailleurs')
        _assert_demo(operation_id,record_id,value)
        db = self.db[self.active]
        digest = _digest(record_id,value)
        seen = db.execute('SELECT sequence_number,payload_sha256 FROM operation_receipts '
                          'WHERE operation_id=?',(operation_id,)).fetchone()
        if seen:
            if seen[1] != digest:
                raise ValueError('operation_id déjà utilisé pour un contenu différent')
            return seen[0]
        seq = self.committed_seq + 1
        entry_hash = _chain(self.committed_hash,seq,operation_id,digest)
        _atomic_apply(db,(seq,operation_id,record_id,value,digest,seq,
                          self.committed_hash,entry_hash))
        self.committed_hash = entry_hash
        self.committed_seq = seq  # DOIT être transactionnel avec commit dans système réel.
        return seq

    def replicate_to(self, target, *, max_events=25):
        if target not in self.db or target == self.active:
            raise ValueError('cible inactive requise')
        if not self.up[self.active] or not self.up[target]:
            raise ConnectionError('source ou secours indisponible')
        if not 1 <= max_events <= 100:
            raise ValueError('batch hors limites')
        source = self.db[self.active]
        next_seq = checkpoint(self.db[target])
        events = source.execute('SELECT seq,operation_id,record_id,value,payload_sha256,'
                                'created_at_ms,prev_hash,entry_hash FROM operation_outbox WHERE seq>? '
                                'ORDER BY seq LIMIT ?', (next_seq,max_events)).fetchall()
        for event in events:
            # L'ordre des colonnes de l'outbox diffère de celui du message canonique.
            seq,op_id,record_id,value,digest,at,prev_hash,entry_hash=event
            _atomic_apply(self.db[target],(seq,op_id,record_id,value,digest,at,prev_hash,entry_hash))
        return checkpoint(self.db[target])

    def promote(self, target):
        if target not in self.db or not self.up[target]:
            raise ConnectionError('secours non joignable')
        state = self.db[target].execute('SELECT applied_seq,last_hash FROM replication_checkpoint '
                                        'WHERE stream=?',(STREAM,)).fetchone()
        if state != (self.committed_seq,self.committed_hash):
            raise UnsafePromotion('secours en retard ou journal divergent : refuser bascule')
        if target != self.active:
            self.active = target
            self.epoch += 1
        return self.epoch

    def read(self, record_id):
        if not self.up[self.active]:
            raise ConnectionError('aucune lecture distante disponible')
        return self.db[self.active].execute('SELECT value FROM sandbox_records WHERE id=?',
                                             (record_id,)).fetchone()

    def close(self):
        for db in self.db.values():
            db.close()
