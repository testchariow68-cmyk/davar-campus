# Préflight version 0 sur bases staging EXISTANTES — aucune écriture SQL

**Attention PowerShell :** copier uniquement les lignes de commande situées dans les blocs `powershell` ; ne jamais copier l'invite `PS C:\...>` ni les lignes de résultat (`⛅`, `🌀`, tableaux, JSON, etc.). `PS` est interprété comme `Get-Process` et provoque des erreurs sans lancer la commande attendue. Commencer dans le dossier **v4**, et non dans l'ancien dossier v3. Ne pas relancer l'ancien inventaire D1 : son résultat `_cf_KV` a déjà été analysé.

**Décision du propriétaire : ne créer aucune nouvelle base.** Le code v4 ajoute une route protégée de lecture des **métadonnées seulement** : `GET /_internal/preflight-v0`. Elle inspecte les tables, index, vues et déclencheurs visibles sur Turso/D1 et les tables/vues/index visibles dans `public` ainsi que les autres schémas visibles sur CockroachDB. Elle renvoie seulement un statut, un booléen `clear` et un nombre d'objets ; jamais de noms inconnus, de définitions SQL, de contenus de table ou de secrets. Sur D1 seulement, `_cf_KV` est ignorée dans le compte, sans y accéder.

**Attention :** `clear:true` n'est **pas** une autorisation ni une garantie de sûreté ; cela ne prouve ni les droits d'écriture, ni la validité du SQL sur CockroachDB, ni la restauration, ni l'absence d'objets invisibles aux droits de lecture, ni la maîtrise des coûts. Si `clear:false`, `unavailable` ou `unconfigured`, **arrêt** et analyse ; ne pas migrer.

## Déploiement de la sonde lecture seule (si vous souhaitez poursuivre cette vérification)

L'archive de préparation **v4** est destinée au même Worker `davar-campus-api-staging`, sans modifier ses bindings/secrets existants. Elle ne contient ni données de compte ni jeton. N'exécutez pas `d1 execute --file`, `migrations apply` ou un fichier SQL. Sur Windows, depuis le `backend` **de l'archive v4**, après décompression dans un **nouveau dossier** :

```powershell
npm ci
npm run check
npm run build:staging
npm run deploy:staging
```

Le déploiement met à jour **le Worker diagnostic staging**, pas le campus public ; vérifiez impérativement le nom affiché `davar-campus-api-staging`. Si la compilation ou les 19 tests échouent, **n'exécutez pas** le déploiement. Node.js 22+ est requis. Aucune réinstallation de secrets, reconnexion ou nouvelle base n'est requise si vos accès actuels fonctionnent.

## Appeler la route privée sans divulguer le jeton

Utilisez **votre valeur existante** de `ADMIN_HEALTH_TOKEN` localement dans PowerShell, sans me la transmettre. Saisissez d'abord cette ligne seule (saisie masquée) :

```powershell
$secret = Read-Host "ADMIN_HEALTH_TOKEN déjà configuré" -AsSecureString
```

Puis collez :

```powershell
$p = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
$token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($p)
$uri = 'https://' + 'davar-campus-api-staging.davaracademie.workers.dev/_internal/preflight-v0'
try {
    (Invoke-WebRequest -UseBasicParsing -Uri $uri -Headers @{Authorization = "Bearer $token"}).Content
} catch {
    if ($_.ErrorDetails.Message) { $_.ErrorDetails.Message }
    else { $_.Exception.Message }
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)
    Remove-Variable token, secret, p, uri -ErrorAction SilentlyContinue
}
```

Communiquez **uniquement le JSON de réponse**, jamais le jeton ni une capture. La route peut renvoyer `inspected:true` et `clear:true` si aucun objet inattendu visible n'est trouvé : cela permet seulement de préparer le contrôle de restauration et la revue d'une migration 0 **ultérieure**. Elle ne crée aucune table.
