import test from 'node:test';
import assert from 'node:assert/strict';
import { createFailoverPolicy } from './failover-policy.mjs';
function setup(){
  const up = {turso:true,cockroach:true,d1:true};
  const sync={turso:true,cockroach:true,d1:true};
  const transitions=[];
  const policy=createFailoverPolicy({probe:async n=>up[n],caughtUp:async n=>sync[n],promote:async(a,b)=>transitions.push([a,b])});
  return {up,sync,transitions,policy};
}
test('3 échecs seulement : Turso -> Cockroach ; toujours une seule cible',async()=>{
  const s=setup();s.up.turso=false;
  assert.equal(await s.policy.tick(),'turso');assert.equal(await s.policy.tick(),'turso');
  assert.equal(await s.policy.tick(),'cockroach');
  assert.deepEqual(s.transitions,[['turso','cockroach']]);
});
test('Cockroach échoue aussi -> D1, puis secours désynchronisés -> local',async()=>{
  const s=setup();s.up.turso=false;s.up.cockroach=false;
  for(let i=0;i<3;i++)await s.policy.tick();assert.equal(s.policy.active,'d1');
  s.up.d1=false;for(let i=0;i<3;i++)await s.policy.tick();assert.equal(s.policy.active,'local');
});
test('ne promouvoir jamais une base en retard',async()=>{
  const s=setup();s.up.turso=false;s.sync.cockroach=false;s.sync.d1=false;
  for(let i=0;i<3;i++)await s.policy.tick();assert.equal(s.policy.active,'local');
  assert.deepEqual(s.transitions,[['turso','local']]);
});
test('retour automatique à la primaire après 3 succès et rattrapage',async()=>{
  const s=setup();s.up.turso=false;for(let i=0;i<3;i++)await s.policy.tick();
  s.up.turso=true;s.sync.turso=false;for(let i=0;i<4;i++)await s.policy.tick();
  assert.equal(s.policy.active,'cockroach');
  s.sync.turso=true;await s.policy.tick();assert.equal(s.policy.active,'turso');
});
test('la promotion refusée ne change pas la source active',async()=>{
  const s=setup();s.up.turso=false;
  const p=createFailoverPolicy({probe:async n=>s.up[n],caughtUp:async()=>true,promote:async()=>{throw Error('fence indisponible')}});
  await p.tick();await p.tick();await assert.rejects(p.tick(),/fence indisponible/);
  assert.equal(p.active,'turso');
});
test('timeout d’une sonde comptabilisé comme échec',async()=>{
  const p=createFailoverPolicy({probe:async n=>n==='turso'?new Promise(()=>{}):true,caughtUp:async()=>true,promote:async()=>{},timeoutMs:5});
  for(let i=0;i<3;i++)await p.tick();assert.equal(p.active,'cockroach');
});
