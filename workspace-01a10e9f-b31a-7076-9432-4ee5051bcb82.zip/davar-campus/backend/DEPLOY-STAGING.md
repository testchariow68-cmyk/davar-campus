# ARCHIVE HISTORIQUE — installation initiale du Worker de diagnostic staging

**Pour l'étape actuelle**, suivre `PREFLIGHT-STAGING-V0-READONLY.md` avec l'archive v4. Le Worker et ses secrets existent déjà : ne pas répéter login, injection de secrets ou création de bases. Ce document est conservé pour historique.

## Installation initiale (déjà effectuée)

Ce Worker n'est **pas** le backend de production. Il n'expose aucune écriture de données : une seule route protégée teste `SELECT 1` sur trois bases. Ne jamais saisir de secrets dans ce chat, dans une capture, dans `wrangler.staging.jsonc` ou dans un fichier ajouté au projet.

## Depuis un ordinateur Windows (PowerShell)

1. Téléchargez l'archive `davar-campus-staging-worker.zip` et décompressez-la. Dans PowerShell, placez-vous dans le dossier `backend` extrait. Vérifiez que **Node.js 22 ou plus** et npm sont disponibles (`node --version`, `npm --version`). Si Node est absent ou en version 20, installez une version LTS récente depuis https://nodejs.org/, puis **fermez et rouvrez PowerShell**.
2. Installer et vérifier localement, sans toucher au Cloudflare :

   ```powershell
   npm ci
   npm run check
   npm run build:staging
   ```

3. Connectez Wrangler à **votre** compte Cloudflare par code d’appareil (pas de redirection vers `localhost:8976`) :

   ```powershell
   npx wrangler login --device
   npx wrangler whoami
   ```

   Wrangler affiche un **nouveau code court** : ouvrez l’URL de vérification sur votre navigateur, saisissez ce code, confirmez sur le bon compte Cloudflare. Ne collez ni le code ni l’URL d’autorisation dans ce chat. `whoami` doit indiquer le compte connecté avant l’étape suivante.

4. Après validation des tests et de la connexion, déployez le **Worker de diagnostic staging**, `davar-campus-api-staging` :

   ```powershell
   npm run deploy:staging
   ```

   Il est normal que son diagnostic réponde d'abord HTTP 503 : aucun secret n'a encore été ajouté. Ne reliez PAS ce Worker au domaine public du campus et n'appliquez PAS les migrations à ce stade.

5. Dans Turso, générer **un jeton lecture seule temporaire** pour `davar-campus-staging`. La CLI Turso fournit `turso db tokens create davar-campus-staging --read-only --expiration 7d` ; le tableau de bord peut proposer les mêmes options. Le jeton ne doit jamais être affiché en capture ou envoyé ici. Injectez-le dans le Worker au prompt interactif :

   ```powershell
   npx wrangler secret put TURSO_AUTH_TOKEN --config wrangler.staging.jsonc
   ```

6. Générez via votre gestionnaire de mots de passe une autre valeur aléatoire (32 caractères ou plus), distincte du jeton Turso. Injectez-la au prompt :

   ```powershell
   npx wrangler secret put ADMIN_HEALTH_TOKEN --config wrangler.staging.jsonc
   ```

   Wrangler redéploie le Worker staging lors de l'ajout d'un secret. Le token admin reste chez vous ; sa valeur sera nécessaire pour tester la route privée. Ne pas le mettre dans le code client. Garder aussi la date d'expiration du jeton Turso pour le renouveler avant test futur.

7. Vérifiez **les noms uniquement** (la commande ne doit pas afficher les valeurs) :

   ```powershell
   npx wrangler secret list --config wrangler.staging.jsonc
   ```

8. Dites-moi uniquement : « Worker staging déployé », son adresse `...workers.dev` si elle existe, et « les deux secrets sont configurés ». **Ne copiez ni mot de passe, ni jeton, ni chaîne PostgreSQL.** Je vous guiderai pour une sonde privée ; si elle échoue, partagez seulement les statuts `ok`/`unconfigured`/`unavailable`, sans entêtes HTTP.

Documentation fournisseur : https://developers.cloudflare.com/workers/configuration/secrets/ et https://docs.turso.tech/sdk/authorization/tokens

## Si vous avez téléchargé l'ancienne archive (Wrangler 4.86)

Ce paquet a été initialement livré avec Wrangler 4.86, qui **ne prend pas en charge** `login --device`. En cas d’erreur `ECONNRESET` / `Received query string parameter doesn't match` dans le navigateur :

1. N'utilisez plus l'ancien lien OAuth. Installez Node.js 22+ depuis https://nodejs.org/, rouvrez PowerShell et vérifiez `node --version`.
2. Dans le dossier `backend` déjà extrait, exécutez `npm install -D wrangler@latest`.
3. Exécutez `npx wrangler login --device`, approuvez le code **fraîchement affiché**, puis `npx wrangler whoami`. Reprenez `npm run deploy:staging` si le Worker n’existe pas encore, et ensuite la commande `secret put`.
4. Si le flux par appareil échoue encore avec `ECONNRESET`, vérifiez l’accès réseau sans jeton avec `Test-NetConnection api.cloudflare.com -Port 443`. Une réponse TCP bloquée évoque proxy/pare-feu/VPN/inspection HTTPS ; ne désactivez pas la sécurité TLS. Envoyez seulement le message d'erreur **en masquant tout jeton, code ou URL OAuth**.

`login --device` est disponible à partir de Wrangler 4.119 (https://developers.cloudflare.com/changelog/post/2026-08-04-wrangler-login-device-flow/) et Wrangler récent nécessite Node.js 22+.
