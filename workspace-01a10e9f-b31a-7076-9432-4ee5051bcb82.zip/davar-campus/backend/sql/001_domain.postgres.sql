-- Migration STAGING 001 (CockroachDB / PostgreSQL).
-- Préparation locale uniquement ; NE PAS lancer sur des bases réelles sans inventaire.
-- Aucun compte ou jeu de démonstration n'est importé par ce script.
CREATE TABLE IF NOT EXISTS campus_users (
  id TEXT PRIMARY KEY,
  email_normalized TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('student','staff','admin')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at_ms BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS campus_staff_roles (
  user_id TEXT NOT NULL REFERENCES campus_users(id),
  role TEXT NOT NULL CHECK (role IN ('manager','coach','correcteur','assistant','contenu','support','analyste')),
  PRIMARY KEY (user_id,role)
);
CREATE TABLE IF NOT EXISTS campus_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES campus_users(id),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at_ms BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_campus_sessions_expires ON campus_sessions(expires_at_ms);
CREATE TABLE IF NOT EXISTS campus_trainings (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  price_cfa BIGINT NOT NULL CHECK(price_cfa >= 0),
  published SMALLINT NOT NULL DEFAULT 0 CHECK(published IN (0,1))
);
CREATE TABLE IF NOT EXISTS campus_enrollments (
  user_id TEXT NOT NULL REFERENCES campus_users(id),
  training_id TEXT NOT NULL REFERENCES campus_trainings(id),
  acquired_at_ms BIGINT NOT NULL,
  source TEXT NOT NULL,
  PRIMARY KEY(user_id,training_id)
);
CREATE TABLE IF NOT EXISTS campus_sales (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES campus_users(id),
  training_id TEXT REFERENCES campus_trainings(id),
  amount_cfa BIGINT NOT NULL CHECK(amount_cfa >= 0),
  provider TEXT NOT NULL,
  external_ref TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL CHECK(status IN ('pending','confirmed','failed','refunded')),
  created_at_ms BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_campus_sales_user ON campus_sales(user_id,created_at_ms);
CREATE TABLE IF NOT EXISTS campus_certificates (
  code TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES campus_users(id),
  training_id TEXT NOT NULL REFERENCES campus_trainings(id),
  holder_name TEXT NOT NULL,
  issued_at_ms BIGINT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('issued','revoked'))
);
CREATE INDEX IF NOT EXISTS idx_campus_cert_user ON campus_certificates(user_id);
