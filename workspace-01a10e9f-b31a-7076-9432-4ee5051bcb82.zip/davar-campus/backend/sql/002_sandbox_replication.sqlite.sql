-- Migration STAGING 002 : banc d'essai de réplication, données STRICTEMENT fictives.
-- Jamais de PII / jeton / vente / droit d'accès dans sandbox_records ou operation_outbox.
CREATE TABLE IF NOT EXISTS sandbox_records (
  id TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_seq INTEGER NOT NULL CHECK(updated_seq > 0)
);
CREATE TABLE IF NOT EXISTS operation_outbox (
  seq INTEGER PRIMARY KEY CHECK(seq > 0),
  operation_id TEXT NOT NULL UNIQUE,
  kind TEXT NOT NULL CHECK(kind = 'sandbox.put'),
  record_id TEXT NOT NULL,
  value TEXT NOT NULL,
  payload_sha256 TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  entry_hash TEXT NOT NULL,
  created_at_ms INTEGER NOT NULL
);
