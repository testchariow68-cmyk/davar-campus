-- TEST / PRÉPARATION : équivalent Postgres (CockroachDB).
-- Ne crée aucun compte, paiement, certificat ou donnée pédagogique.
CREATE TABLE IF NOT EXISTS schema_migrations (
  version BIGINT PRIMARY KEY,
  checksum TEXT NOT NULL,
  installed_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS replication_checkpoint (
  stream TEXT PRIMARY KEY,
  applied_seq BIGINT NOT NULL DEFAULT 0 CHECK (applied_seq >= 0),
  last_hash TEXT NOT NULL DEFAULT 'GENESIS',
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS operation_receipts (
  operation_id TEXT PRIMARY KEY,
  stream TEXT NOT NULL,
  sequence_number BIGINT NOT NULL CHECK (sequence_number > 0),
  payload_sha256 TEXT NOT NULL,
  committed_at BIGINT NOT NULL,
  UNIQUE (stream, sequence_number)
);
CREATE INDEX IF NOT EXISTS idx_receipts_committed ON operation_receipts(committed_at);
