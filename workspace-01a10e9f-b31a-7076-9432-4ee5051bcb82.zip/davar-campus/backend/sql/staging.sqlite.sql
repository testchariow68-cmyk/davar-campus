-- TEST / PRÉPARATION : même migration libSQL (Turso) et D1 (SQLite).
-- Ne crée aucun compte, paiement, certificat ou donnée pédagogique.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  checksum TEXT NOT NULL,
  installed_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS replication_checkpoint (
  stream TEXT PRIMARY KEY,
  applied_seq INTEGER NOT NULL DEFAULT 0 CHECK (applied_seq >= 0),
  last_hash TEXT NOT NULL DEFAULT 'GENESIS',
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS operation_receipts (
  operation_id TEXT PRIMARY KEY,
  stream TEXT NOT NULL,
  sequence_number INTEGER NOT NULL CHECK (sequence_number > 0),
  payload_sha256 TEXT NOT NULL,
  committed_at INTEGER NOT NULL,
  UNIQUE (stream, sequence_number)
);
CREATE INDEX IF NOT EXISTS idx_receipts_committed ON operation_receipts(committed_at);
