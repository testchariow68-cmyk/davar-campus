import test from 'node:test';
import assert from 'node:assert/strict';
import {assessD1DailyQuota} from './quota-policy.mjs';
const now=new Date('2026-10-02T11:00:00Z');
const usage=(rowsWritten,rowsRead=0)=>assessD1DailyQuota({utcDay:'2026-10-02',rowsRead,rowsWritten},now);
test('seuils 80/95/100 % sur les écritures',()=>{
  assert.equal(usage(79999).level,'normal');
  assert.deepEqual([usage(80000).level,usage(95000).level,usage(100000).level],
    ['warning','critical','exhausted']);
  assert.equal(usage(100000).essentialWrites,false);
  assert.equal(usage(80000).optionalWrites,false);
});
test('les lectures peuvent devenir le goulot',()=>{
  assert.equal(usage(0,4_000_000).level,'warning');
  assert.equal(usage(0,5_000_000).level,'exhausted');
});
test('métriques absentes, négatives ou journée périmée => inconnu, sans faux feu vert',()=>{
  for(const input of [{utcDay:'2026-10-01',rowsRead:0,rowsWritten:0},
    {utcDay:'2026-10-02',rowsRead:0},
    {utcDay:'2026-10-02',rowsRead:0,rowsWritten:-1}]) {
    const state=assessD1DailyQuota(input,now);
    assert.equal(state.level,'unknown');assert.equal(state.optionalWrites,false);
  }
});
