"""Versions/checksums des migrations *locales SQLite* de staging.

Aucune connexion réseau ni application automatique aux bases Turso/D1/Cockroach.
Les fichiers .postgres.sql sont des équivalents à examiner avant exécution réelle.
Le préflight contrôle les collisions et les versions connues, PAS le DDL réel distant.
"""
import hashlib
import sqlite3
from contextlib import closing
from pathlib import Path

SQL = Path(__file__).parent / 'sql'
SQLITE_MIGRATIONS = (
    (0, 'staging.sqlite.sql'),
    (1, '001_domain.sqlite.sql'),
    (2, '002_sandbox_replication.sqlite.sql'),
)

# Manifest explicite : si une migration change de nom de table/index, revoir ce contrat.
OBJECTS_BY_VERSION = {
    0: {('schema_migrations', 'table'), ('replication_checkpoint', 'table'),
        ('operation_receipts', 'table'), ('idx_receipts_committed', 'index')},
    1: {('campus_users', 'table'), ('campus_staff_roles', 'table'),
        ('campus_sessions', 'table'), ('campus_trainings', 'table'),
        ('campus_enrollments', 'table'), ('campus_sales', 'table'),
        ('campus_certificates', 'table'), ('idx_campus_sessions_expires', 'index'),
        ('idx_campus_sales_user', 'index'), ('idx_campus_cert_user', 'index')},
    2: {('sandbox_records', 'table'), ('operation_outbox', 'table')},
}


def _preflight(db: sqlite3.Connection, provider: str):
    if provider not in ('sqlite', 'd1'):
        raise ValueError('fournisseur local invalide')
    actual_ddl = {(name, kind): ddl for name, kind, ddl in db.execute(
        "SELECT name,type,sql FROM sqlite_master WHERE type IN ('table','index','view','trigger') "
        "AND name NOT LIKE 'sqlite_%'"
    )}
    # Réservé à la plateforme D1 : ne jamais interroger, recréer ou supprimer _cf_KV.
    if provider == 'd1':
        actual_ddl.pop(('_cf_KV', 'table'), None)
    objects = set(actual_ddl)

    tracked = ('schema_migrations', 'table') in objects
    recorded = list(db.execute('SELECT version,checksum FROM schema_migrations ORDER BY version')) if tracked else []
    versions = [version for version, _ in recorded]
    expected_versions = list(range(len(versions)))
    if versions != expected_versions or any(v not in OBJECTS_BY_VERSION for v in versions):
        raise RuntimeError('versions de migration incohérentes ou inconnues : arrêt')
    for version, checksum in recorded:
        filename = dict(SQLITE_MIGRATIONS)[version]
        digest = hashlib.sha256((SQL / filename).read_bytes()).hexdigest()
        if checksum != digest:
            raise RuntimeError(f'migration {version} modifiée : arrêt avant toute écriture')
    expected_objects = set().union(*(OBJECTS_BY_VERSION[v] for v in versions))
    if objects != expected_objects:
        missing = sorted(expected_objects - objects)
        unexpected = sorted(objects - expected_objects)
        raise RuntimeError(f'schéma local incompatible : objets manquants={missing}, inattendus={unexpected}')
    if versions:
        # Reconstruit le schéma attendu sans réseau ni données réelles. Un nom de table
        # correct ne suffit pas : une colonne, contrainte ou définition d'index altérée
        # doit aussi empêcher le prochain passage. Comparaison volontairement stricte.
        with closing(sqlite3.connect(':memory:')) as reference:
            for version in versions:
                reference.executescript((SQL / dict(SQLITE_MIGRATIONS)[version]).read_text(encoding='utf-8'))
            expected_ddl = {(name, kind): ddl for name, kind, ddl in reference.execute(
                "SELECT name,type,sql FROM sqlite_master WHERE type IN ('table','index','view','trigger') "
                "AND name NOT LIKE 'sqlite_%'"
            )}
        if actual_ddl != expected_ddl:
            raise RuntimeError('définition SQL locale altérée ou incompatible : arrêt avant toute écriture')
    return versions


def apply_local_sqlite(db: sqlite3.Connection, *, provider: str = 'sqlite'):
    """Migration de démonstration locale ; provider='d1' simule son objet réservé.

    Le préflight précède TOUTE écriture. Ceci n'est PAS un runner D1/Turso distant.
    """
    if db.in_transaction:
        raise RuntimeError('ne jamais migrer à l’intérieur d’une autre transaction')
    versions = _preflight(db, provider)
    db.execute('PRAGMA foreign_keys=ON')
    for version, filename in SQLITE_MIGRATIONS:
        if version in versions:
            continue
        sql = (SQL / filename).read_text(encoding='utf-8')
        digest = hashlib.sha256(sql.encode()).hexdigest()
        # PRAGMA must be set before BEGIN; DDL + checksum in ONE local transaction.
        body = sql.replace('PRAGMA foreign_keys = ON;', '')
        script = (f'BEGIN IMMEDIATE;\n{body}\n'
                  f"INSERT INTO schema_migrations(version,checksum,installed_at) VALUES "
                  f"({version},'{digest}',0);\nCOMMIT;")
        try:
            db.executescript(script)
        except Exception:
            db.rollback()
            raise
    return tuple(v for v, in db.execute('SELECT version FROM schema_migrations ORDER BY version'))
