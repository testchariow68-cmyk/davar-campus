# Inventaire des schémas de staging sans écriture — effectué le 2 octobre 2026

Le Worker staging **v3 est déployé** : sa route privée `/_internal/inventory` lit uniquement les noms des tables. Elle ne lance **aucune migration** et ne lit aucun contenu des tables. Le propriétaire a vérifié dans D1 que l'unique table signalée comme « autre » est `_cf_KV`, table interne réservée de Cloudflare ; Turso et CockroachDB n'ont signalé aucune table. Ne pas supprimer ni modifier `_cf_KV` ; ne pas diffuser les jetons, mots de passe ni URL OAuth. Les étapes ci-dessous documentent ce qui a déjà été fait ; **ne pas les répéter** simplement pour confirmer ce résultat.

## Depuis votre PowerShell Windows (Node.js 22+ requis)

1. Téléchargez `davar-campus-staging-worker-v3.zip` et décompressez-le dans Téléchargements **dans un nouveau dossier**, sans écraser votre ancien dossier. Puis :

```powershell
cd "$env:USERPROFILE\Downloads\davar-campus-staging-worker-v3\backend"
npm ci
npm run check
npm run deploy:staging
```

Si Windows a choisi un autre nom de dossier, ouvrez le dossier contenant `package.json` et `wrangler.staging.jsonc`, puis cliquez dans la barre d'adresse de l'Explorateur, copiez son chemin et exécutez `cd "CHEMIN_COPIÉ"` dans PowerShell.

2. Confirmez que Wrangler affiche `davar-campus-api-staging...workers.dev`. **Les deux secrets installés sur ce Worker restent côté Cloudflare ; l'archive ne les contient pas.** Vous ne devez pas créer un Worker portant un autre nom.

3. Pour appeler l'inventaire privé, saisissez **d'abord cette ligne seule** (elle demande le secret en masquant la saisie) :

```powershell
$secret = Read-Host "Collez ADMIN_HEALTH_TOKEN" -AsSecureString
```

4. Une fois le jeton saisi, collez ce bloc. Il affiche seulement un JSON avec les noms de **nos** tables connues et le *nombre* des autres tables, jamais les données :

```powershell
$p = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
$token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($p)
$uri = 'https://' + 'davar-campus-api-staging.davaracademie.workers.dev/_internal/inventory'
try {
    (Invoke-WebRequest -UseBasicParsing -Uri $uri -Headers @{Authorization = "Bearer $token"}).Content
} catch {
    if ($_.ErrorDetails.Message) { $_.ErrorDetails.Message }
    else { $_.Exception.Message }
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)
    Remove-Variable token, secret, p, uri -ErrorAction SilentlyContinue
}
```

5. Vous pouvez partager uniquement le **résultat JSON**. Ne partagez ni capture avec le jeton, ni valeur de `ADMIN_HEALTH_TOKEN`. Si l'une des bases retourne `unavailable` ou `unconfigured`, nous n'exécutons **aucune** migration. Même si toutes répondent `ok`, un inventaire de tables ne constitue pas l'autorisation d'écraser des données préexistantes.
