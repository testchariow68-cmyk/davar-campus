"""Plan de migrations HORS RÉSEAU pour revue humaine, jamais un exécuteur distant.

Usage : python3 plan_migration.py --provider d1 --through 0
Aucune option d'application, import de driver, lecture de secret ou requête réseau.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

from migration_runner import OBJECTS_BY_VERSION

SQL = Path(__file__).resolve().parent / 'sql'
FILENAMES = {0: 'staging', 1: '001_domain', 2: '002_sandbox_replication'}
PROVIDERS = {'d1': 'sqlite', 'turso': 'sqlite', 'cockroach': 'postgres'}


def build_plan(provider: str, through: int, *, sql_dir: Path = SQL):
    if provider not in PROVIDERS or through not in FILENAMES:
        raise ValueError('fournisseur ou version inconnu : arrêt')
    dialect = PROVIDERS[provider]
    migrations = []
    for version in range(through + 1):
        name = f'{FILENAMES[version]}.{dialect}.sql'
        data = (sql_dir / name).read_bytes()
        # Garde statique limitée aux noms d'objets. La syntaxe SQL/transactions
        # doit être vérifiée sur une vraie base jetable avant toute application.
        sql = data.decode('utf-8')
        actual = {(obj, kind.lower()) for kind, obj in re.findall(
            r'^CREATE\s+(TABLE|INDEX)\s+IF\s+NOT\s+EXISTS\s+([A-Za-z][A-Za-z_0-9]*)\b',
            sql, re.MULTILINE | re.IGNORECASE
        )}
        expected = OBJECTS_BY_VERSION[version]
        if actual != expected:
            raise ValueError(f'migration {version} : objets SQL inattendus : arrêt')
        migrations.append({
            'version': version,
            'file': f'sql/{name}',
            'sha256': hashlib.sha256(data).hexdigest(),
            'tables': sorted(obj for obj, kind in actual if kind == 'table'),
            'indexes': sorted(obj for obj, kind in actual if kind == 'index'),
        })
    return {'mode': 'OFFLINE_PLAN_ONLY', 'provider': provider,
            'through': through, 'remote_write_enabled': False,
            'note': 'Ne constitue ni un préflight distant ni une autorisation de migration.',
            'migrations': migrations}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--provider', choices=tuple(PROVIDERS), required=True)
    parser.add_argument('--through', type=int, choices=tuple(FILENAMES), default=0)
    args = parser.parse_args(argv)
    print(json.dumps(build_plan(args.provider, args.through), indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
