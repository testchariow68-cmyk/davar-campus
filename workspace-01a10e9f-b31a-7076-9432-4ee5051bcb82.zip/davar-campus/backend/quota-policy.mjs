/** Simulation de garde budgétaire D1 Free.
 * Ne devine jamais des métriques : ne pas activer sans compteurs réels fournisseur.
 * Un seuil n'autorise JAMAIS à promouvoir une copie obsolète.
 */
export const D1_FREE_DAILY = Object.freeze({ rowsRead: 5_000_000, rowsWritten: 100_000 });
export function assessD1DailyQuota({ utcDay, rowsRead, rowsWritten }, now = new Date()) {
  const today = now.toISOString().slice(0,10);
  if (utcDay !== today || !Number.isSafeInteger(rowsRead) || rowsRead < 0 ||
      !Number.isSafeInteger(rowsWritten) || rowsWritten < 0) {
    return { level:'unknown', optionalWrites:false, essentialWrites:false };
  }
  const ratio = Math.max(rowsRead / D1_FREE_DAILY.rowsRead,
                         rowsWritten / D1_FREE_DAILY.rowsWritten);
  const level = ratio >= 1 ? 'exhausted' : ratio >= .95 ? 'critical' :
    ratio >= .8 ? 'warning' : 'normal';
  return { level, optionalWrites:level === 'normal',
    essentialWrites:level !== 'exhausted',
    ratio, remainingRowsWritten:Math.max(0,D1_FREE_DAILY.rowsWritten-rowsWritten) };
}
