import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from plan_migration import build_plan, SQL


class PlanMigrationTest(unittest.TestCase):
    def test_all_dialects_reconcile_sql_names_and_expected_manifest(self):
        for provider in ('d1', 'turso', 'cockroach'):
            with self.subTest(provider=provider):
                plan = build_plan(provider, 2)
                self.assertEqual(plan['mode'], 'OFFLINE_PLAN_ONLY')
                self.assertFalse(plan['remote_write_enabled'])
                self.assertEqual([x['version'] for x in plan['migrations']], [0, 1, 2])
                self.assertEqual(sum(len(x['tables']) for x in plan['migrations']), 12)
                self.assertEqual(sum(len(x['indexes']) for x in plan['migrations']), 4)
                for migration in plan['migrations']:
                    self.assertEqual(len(migration['sha256']), 64)

    def test_version_zero_only_by_default(self):
        result = subprocess.run([sys.executable, 'plan_migration.py', '--provider', 'd1'],
                                cwd=Path(__file__).parent, capture_output=True, text=True, check=True)
        plan = json.loads(result.stdout)
        self.assertEqual(plan['through'], 0)
        self.assertEqual(len(plan['migrations']), 1)
        self.assertNotIn('_cf_KV', json.dumps(plan))

    def test_no_apply_option_is_available(self):
        result = subprocess.run([sys.executable, 'plan_migration.py', '--provider', 'd1', '--apply'],
                                cwd=Path(__file__).parent, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('unrecognized arguments', result.stderr)

    def test_modified_manifest_or_missing_sql_blocks_plan(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            source = SQL / 'staging.sqlite.sql'
            (path / source.name).write_bytes(source.read_bytes().replace(
                b'CREATE TABLE IF NOT EXISTS operation_receipts',
                b'CREATE TABLE IF NOT EXISTS foreign_data'))
            with self.assertRaisesRegex(ValueError, 'inattendus'):
                build_plan('d1', 0, sql_dir=path)
            with self.assertRaises(FileNotFoundError):
                build_plan('cockroach', 0, sql_dir=path)

    def test_unknown_provider_or_version_refused(self):
        for provider, version in (('sqlite', 0), ('d1', 4)):
            with self.assertRaises(ValueError):
                build_plan(provider, version)


if __name__ == '__main__':
    unittest.main()
