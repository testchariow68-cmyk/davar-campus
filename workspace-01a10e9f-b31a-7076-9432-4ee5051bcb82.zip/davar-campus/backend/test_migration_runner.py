import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from migration_runner import apply_local_sqlite

class MigrationRunnerTest(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:',isolation_level=None)
    def tearDown(self):
        self.db.close()
    def test_all_versions_applied_only_once_and_no_seed(self):
        self.assertEqual(apply_local_sqlite(self.db),(0,1,2))
        self.assertEqual(apply_local_sqlite(self.db),(0,1,2))
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM schema_migrations').fetchone()[0],3)
        for table in ('campus_users','campus_sales','sandbox_records'):
            self.assertEqual(self.db.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0],0)
    def test_modified_applied_migration_blocks_before_writing(self):
        apply_local_sqlite(self.db)
        self.db.execute("UPDATE schema_migrations SET checksum='corrupt' WHERE version=1")
        with self.assertRaisesRegex(RuntimeError,'modifiée'):
            apply_local_sqlite(self.db)
    def test_failure_rolls_back_ddl_and_checkpoint(self):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder)/'broken.sql').write_text('''
                CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY,checksum TEXT NOT NULL,installed_at INTEGER NOT NULL);
                CREATE TABLE tentative(x TEXT);
                INSERT INTO does_not_exist VALUES(1);
            ''')
            with patch('migration_runner.SQL',Path(folder)), patch('migration_runner.SQLITE_MIGRATIONS',((0,'broken.sql'),)):
                with self.assertRaises(sqlite3.OperationalError): apply_local_sqlite(self.db)
        for name in ('schema_migrations','tentative'):
            self.assertIsNone(self.db.execute("SELECT 1 FROM sqlite_master WHERE name=?",(name,)).fetchone())
    def test_existing_transaction_is_refused(self):
        self.db.execute('BEGIN')
        with self.assertRaises(RuntimeError): apply_local_sqlite(self.db)
        self.db.rollback()

    def test_unknown_table_refused_before_any_write(self):
        self.db.execute('CREATE TABLE somebody_elses_data (id TEXT PRIMARY KEY)')
        with self.assertRaisesRegex(RuntimeError, 'inattendus'):
            apply_local_sqlite(self.db)
        self.assertIsNone(self.db.execute("SELECT 1 FROM sqlite_master WHERE name='schema_migrations'").fetchone())
        self.assertIsNotNone(self.db.execute("SELECT 1 FROM sqlite_master WHERE name='somebody_elses_data'").fetchone())

    def test_known_table_without_migration_receipt_is_also_refused(self):
        self.db.execute('CREATE TABLE campus_users (id TEXT PRIMARY KEY)')
        with self.assertRaisesRegex(RuntimeError, 'inattendus'):
            apply_local_sqlite(self.db)
        self.assertIsNone(self.db.execute("SELECT 1 FROM sqlite_master WHERE name='schema_migrations'").fetchone())

    def test_d1_reserved_table_ignored_only_for_d1_simulation(self):
        self.db.execute('CREATE TABLE _cf_KV (key TEXT PRIMARY KEY, value BLOB)')
        with self.assertRaisesRegex(RuntimeError, 'inattendus'):
            apply_local_sqlite(self.db)
        self.assertEqual(apply_local_sqlite(self.db, provider='d1'), (0, 1, 2))
        self.assertEqual(apply_local_sqlite(self.db, provider='d1'), (0, 1, 2))
        self.assertIsNotNone(self.db.execute("SELECT 1 FROM sqlite_master WHERE name='_cf_KV'").fetchone())

    def test_missing_table_in_recorded_version_refused_before_write(self):
        apply_local_sqlite(self.db)
        self.db.execute('DROP TABLE sandbox_records')
        with self.assertRaisesRegex(RuntimeError, 'manquants'):
            apply_local_sqlite(self.db)

    def test_untracked_index_refused_before_write(self):
        apply_local_sqlite(self.db)
        self.db.execute('CREATE INDEX somebody_elses_index ON campus_users(display_name)')
        with self.assertRaisesRegex(RuntimeError, 'inattendus'):
            apply_local_sqlite(self.db)

    def test_unknown_version_refused_before_write(self):
        apply_local_sqlite(self.db)
        self.db.execute("INSERT INTO schema_migrations VALUES (3,'not-known',0)")
        with self.assertRaisesRegex(RuntimeError, 'inconnues'):
            apply_local_sqlite(self.db)

    def test_same_table_name_but_altered_ddl_is_refused(self):
        apply_local_sqlite(self.db)
        self.db.execute('ALTER TABLE campus_users ADD COLUMN injected TEXT')
        with self.assertRaisesRegex(RuntimeError, 'définition SQL'):
            apply_local_sqlite(self.db)

    def test_same_index_name_but_altered_ddl_is_refused(self):
        apply_local_sqlite(self.db)
        self.db.execute('DROP INDEX idx_campus_sessions_expires')
        self.db.execute('CREATE INDEX idx_campus_sessions_expires ON campus_sessions(user_id)')
        with self.assertRaisesRegex(RuntimeError, 'définition SQL'):
            apply_local_sqlite(self.db)

if __name__=='__main__': unittest.main()
