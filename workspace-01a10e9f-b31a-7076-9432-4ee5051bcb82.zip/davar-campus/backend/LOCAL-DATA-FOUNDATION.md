# DAVAR Campus — socle de données et réplication (essais locaux historiques)

> **Décision actuelle :** Turso seule base applicative cible (`../TURSO-SEUL-PLAN.md`) ; réplication à trois fournisseurs mise en pause. Ces scripts/tests restent conservés mais **ne doivent pas être appliqués** aux bases staging. Aucun script local ne prouve que le campus utilise déjà Turso.

**Statut au 2 octobre 2026 : développé et testé EN LOCAL. Non appliqué aux trois bases hébergées.** La seule partie en ligne est le Worker de diagnostic staging, qui a répondu `ok` à `SELECT 1` sur Turso, CockroachDB et D1 selon le test effectué par le propriétaire. L’application utilisateur demeure sur `localStorage` ; les trois bases ne servent encore ni comptes ni paiements.

## Fichiers livrés

| Fichier | Rôle |
|---|---|
| `sql/staging.sqlite.sql`, `sql/staging.postgres.sql` | Versionnement, checkpoint et reçus d’idempotence (version 0 locale). |
| `sql/001_domain.sqlite.sql`, `sql/001_domain.postgres.sql` | **Noyau** des données : utilisateurs (hash de mot de passe uniquement), rôles staff, sessions (hash de jeton uniquement), formations, inscriptions, ventes, registre des certificats. Ce n’est **pas** encore le schéma exhaustif de tous les écrans du campus. |
| `sql/002_sandbox_replication.sqlite.sql`, `sql/002_sandbox_replication.postgres.sql` | Banc d’essai isolé `sandbox_*` + outbox séquencée ; accepte uniquement des valeurs fictives `demo:…`. Jamais de donnée personnelle ou financière dans cet outbox de démonstration. |
| `migration_runner.py` | Applique les 3 versions **sur SQLite local seulement** ; empreinte SHA-256, ordre imposé, transaction par migration ; refuse les objets sans reçu, les définitions DDL locales altérées et les migrations modifiées. En simulation D1 seulement, ignore le nom réservé `_cf_KV` sans le toucher. Aucun accès distant. |
| `plan_migration.py` | Produit hors réseau un plan JSON des objets et checksums par fournisseur, par défaut version 0. N'a **aucune option d'écriture distante** ; la vérification statique des noms ne valide pas la syntaxe SQL ni CockroachDB réel. |
| `sandbox_replication.py` | Simulation de 3 bases SQLite en mémoire, un seul primaire pour les lectures/écritures applicatives ; répliques synchronisées par opérations techniques, reçus idempotents, empreinte du payload et chaîne de hash, rollback de transaction, promotion impossible si retard/divergence. |
| `quota-policy.mjs` | Garde budgétaire D1 *pure* : seuils à 80/95/100 % ; métriques du fournisseur absentes/périmées = « unknown », sans faux feu vert. **Non branchée aux métriques réelles**. |

## Tests exécutés

- `python3 -m unittest -v test_migration_runner.py test_sandbox_replication.py test_plan_migration.py` → **28 tests/0 échec** : schéma vide, contraintes, versions, altération d’une migration, rollback, préflight des collisions/manques et définitions de tables/index, exception `_cf_KV` propre à D1, plans statiques SQLite/PostgreSQL, journal ordonné, idempotence et bascule simulée.
- `node --test failover-policy.test.mjs quota-policy.test.mjs staging-readiness.test.mjs` → **20 tests/0 échec** : politique de health check simulée, routes de diagnostic protégées, préflight v0 déployé en v4 et correction locale du faux positif Cockroach `pg_extension` (correction non déployée), budgets simulés.
- `src/staging-readiness.mjs` a une route privée `/_internal/inventory` **déployée en staging v3** : inventaire limité des noms de tables, sans lecture de données ni écriture. Le résultat de lecture du 2 octobre 2026 montre seulement la table interne D1 `_cf_KV` (elle compte parmi les « autres » tables) ; Turso et Cockroach ne montrent aucune table. Ne jamais appeler cette route avec un secret dans l’URL ou le chat.
- Les trois scripts `*.postgres.sql` ont été **parsés** comme syntaxe PostgreSQL ; cela **ne remplace pas une exécution réelle dans CockroachDB**.
- Les tables portent les mêmes noms logiques dans les deux dialectes. Aucun compte réel, aucune donnée de démonstration du campus, aucune requête d’écriture sur les fournisseurs distants.

## Risques restants — interdiction d’appeler cela de la haute disponibilité en production

1. `DemoGroup` conserve son époque et sa dernière révision **en mémoire**. Un vrai coordinateur Durable Object persistant, avec fencing inter-instances et gestion des crashes entre commit et accusé, doit être construit et audité. Un hash de journal détecte la divergence accidentelle ; il n’est pas une preuve cryptographique contre un administrateur ayant accès aux trois bases.
2. Les adaptateurs de réplication Turso↔Cockroach↔D1 ne sont **pas encore écrits** ; la simulation utilise trois SQLite locales. Aucun résultat ne démontre que les commandes SQL passent sur CockroachDB ou D1 hébergés, ni qu’un secours peut être promu sans perte.
3. L’outbox de démo n’est **pas** une politique de réplication des données sensibles : il faudra un modèle d’événements autorisés, des données minimisées/chiffrées selon besoin, un contrôle des droits, un contrat d’idempotence côté webhook et des tests de restauration.
4. Le jeton Turso actuellement configuré pour `SELECT 1` est **lecture seule** (si créé comme recommandé). Ne pas le remplacer dans le Worker de diagnostic par un jeton d’administration. Les migrations de staging nécessitent une procédure privée séparée avec droits limités, sauvegarde et vérification de l’inventaire préalable.
5. Les coûts réels restent inconnus : index, écritures techniques, RU Cockroach, SQL Hyperdrive et opérations D1 doivent être mesurés dans les métriques officielles avant lancement. La garde budgétaire locale n’interrompt encore aucune requête distante.

## Prochaine phase sûre

L'inventaire initial **en lecture seule** des trois bases est terminé ; refaire le préflight juste avant toute intervention. Les vérifications de noms, versions, checksums et DDL sont préparées **en local SQLite**, pas pour les bases distantes ; le plan hors réseau est dans `plan_migration.py`. Voir `MIGRATIONS-STAGING-PREPARATION.md` pour les barrières à franchir. Concevoir un opérateur distant qui refuse une table préexistante incompatible, vérifie les définitions, et reconnaît `_cf_KV` **uniquement sur D1** comme table interne à ne pas toucher. Le propriétaire ne veut **aucune nouvelle base jetable** : après préflight et point de restauration, seule une autorisation distincte pourrait permettre un essai minimal version 0 sur les ressources staging existantes via un opérateur séparé. Sans base jetable, ce test ne sera pas précédé d'une preuve de compatibilité réelle. Ensuite seulement, et après validation distincte d'une opération d'écriture staging, tester quelques événements **strictement fictifs**, mesurer les lignes écrites/RU et développer le coordinateur durable. Ne migrer ni clients, ni staff, ni ventes et ne lancer aucune purge sans autorisation expresse.
